﻿namespace GenAI.Web.Core.Models.TokenAuth
{
    public class ForgotDto
    {
        public string Email { get; set; }
    }
}
