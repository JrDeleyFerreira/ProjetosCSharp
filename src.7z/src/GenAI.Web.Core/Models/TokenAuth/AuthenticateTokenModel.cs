﻿using System.ComponentModel.DataAnnotations;

namespace GenAI.Web.Core.Models.TokenAuth
{
    public class AuthenticateTokenModel
    {
        [Required]
        public string Token { get; set; }
    }
}