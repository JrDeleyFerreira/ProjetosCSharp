﻿using Abp.AspNetCore;
using Abp.AspNetCore.Configuration;
using Abp.AspNetCore.SignalR;
using Abp.Configuration;
using Abp.Configuration.Startup;
using Abp.Modules;
using Abp.Reflection.Extensions;
using Abp.Zero.Configuration;
using Castle.MicroKernel.Registration;
using GenAI.Application;
using GenAI.Core.Contracts.Services.TwoFactor.Mail;
using GenAI.Core.Impl.Services.TwoFactor.Mail;
using GenAI.Crosscutting.Infra.Settings;
using GenAI.Repositories.EntityFrameworkCore;
using GenAI.Web.Core.Authentication.JwtBearer;
using GenAI.Web.Core.Configuration;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.ApplicationParts;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Linq;
using System.Text;

namespace GenAI.Web.Core
{
    [DependsOn(
        typeof(GenAIApplicationModule),
        typeof(GenAIEntityFrameworkModule),
        typeof(AbpAspNetCoreModule),
        typeof(AbpAspNetCoreSignalRModule)
    )]
    public class GenAIWebCoreModule : AbpModule
    {
        private readonly IConfigurationRoot _appConfiguration;
        private readonly IWebHostEnvironment _env;

        public GenAIWebCoreModule(IWebHostEnvironment env)
        {
            _env = env;
            _appConfiguration = env.GetAppConfiguration();
        }

        public override void PreInitialize()
        {
            Configuration.DefaultNameOrConnectionString = GenAISettings.ConnectionStringsDefault;

            // Use database for language management
            Configuration.Modules.Zero().LanguageManagement.EnableDbLocalization();

            Configuration.Modules.AbpAspNetCore()
                 .CreateControllersForAppServices(
                     typeof(GenAIApplicationModule).GetAssembly()
                 );
            ConfigureTokenAuth();


            Configuration.Modules.AbpWebCommon().SendAllExceptionsToClients = GenAISettings.SendAllExceptionsToClient;
            //Configuration.Modules.Zero().UserManagement.ExternalAuthenticationSources.Add<>();

            IocManager.IocContainer.Register(
                Component
                    .For<IMailDomainService>()
                    .UsingFactoryMethod(kernel =>
                    {
                        var settingManager = kernel.Resolve<ISettingManager>();
                        var settings = settingManager.GetAllSettingValues().Where(x => x.Name.StartsWith("Abp.Net.Mail.Smtp."));
                        var host = settings.FirstOrDefault(x => x.Name == "Abp.Net.Mail.Smtp.Host")?.Value ?? "";
                        var port = Convert.ToInt32(settings.FirstOrDefault(x => x.Name == "Abp.Net.Mail.Smtp.Port")?.Value ?? "25");
                        var username = settings.FirstOrDefault(x => x.Name == "Abp.Net.Mail.Smtp.UserName")?.Value ?? "";
                        var password = settings.FirstOrDefault(x => x.Name == "Abp.Net.Mail.Smtp.Password")?.Value ?? "";

                        return new MailDomainService(host, port, username, password);
                    })
                    .LifestyleTransient()
            );
        }

        private void ConfigureTokenAuth()
        {
            IocManager.Register<TokenAuthConfiguration>();
            var tokenAuthConfig = IocManager.Resolve<TokenAuthConfiguration>();

            tokenAuthConfig.SecurityKey =
                new SymmetricSecurityKey(
                    Encoding.ASCII.GetBytes(GenAISettings.JwtBearerSecurityKey));
            tokenAuthConfig.Issuer = _appConfiguration["Authentication:JwtBearer:Issuer"];
            tokenAuthConfig.Audience = _appConfiguration["Authentication:JwtBearer:Audience"];
            tokenAuthConfig.SigningCredentials =
                new SigningCredentials(tokenAuthConfig.SecurityKey, SecurityAlgorithms.HmacSha256);
            tokenAuthConfig.Expiration = TimeSpan.FromDays(1);

            //IocManager.Register<GenAI.Crosscutting.Entities.Dto.Maturity.GuestUserTokens.TokenAuthConfiguration>();
            //var tokenAuthConfig1 = IocManager.Resolve<GenAI.Crosscutting.Entities.Dto.Maturity.GuestUserTokens.TokenAuthConfiguration>();

            //tokenAuthConfig1.SecurityKey =
            //    new SymmetricSecurityKey(
            //        Encoding.ASCII.GetBytes(GenAISettings.JwtBearerSecurityKey));
            //tokenAuthConfig1.Issuer = _appConfiguration["Authentication:JwtBearer:Issuer"];
            //tokenAuthConfig1.Audience = _appConfiguration["Authentication:JwtBearer:Audience"];
            //tokenAuthConfig1.SigningCredentials =
            //    new SigningCredentials(tokenAuthConfig1.SecurityKey, SecurityAlgorithms.HmacSha256);
            //tokenAuthConfig1.Expiration = TimeSpan.FromDays(1);

        }

        public override void Initialize()
        {
            IocManager.RegisterAssemblyByConvention(typeof(GenAIWebCoreModule).GetAssembly());
        }
        public override void PostInitialize()
        {
            IocManager.Resolve<ApplicationPartManager>()
                .AddApplicationPartsIfNotAddedBefore(typeof(GenAIWebCoreModule).Assembly);
        }
    }
}

