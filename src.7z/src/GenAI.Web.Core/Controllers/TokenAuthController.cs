﻿using Abp.Authorization;
using Abp.Authorization.Users;
using Abp.MultiTenancy;
using Abp.Runtime.Security;
using Abp.UI;
using GenAI.Application;
using GenAI.Application.Authorization;
using GenAI.Core.Contracts.Services.ApiKey;
using GenAI.Core.Contracts.Services.TwoFactor;
using GenAI.Core.Impl.Services.Authorization;
using GenAI.Core.Impl.Services.Users;
using GenAI.Core.Validation;
using GenAI.Crosscutting.Entities.Dto.ApiKeys;
using GenAI.Crosscutting.Infra.Extensions;
using GenAI.Crosscutting.Infra.Settings;
using GenAI.Domain.Entities;
using GenAI.Web.Core.Authentication.External;
using GenAI.Web.Core.Authentication.JwtBearer;
using GenAI.Web.Core.Configuration;
using GenAI.Web.Core.Models.TokenAuth;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Protocols;
using Microsoft.IdentityModel.Protocols.OpenIdConnect;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace GenAI.Web.Core.Controllers
{
    [Route("api/[controller]/[action]")]
    public class TokenAuthController : GenAIControllerBase
    {
        private readonly LogInManager _LogInManager;
        private readonly UserManager _UserManager;
        private readonly ITenantCache _TenantCache;
        private readonly AbpLoginResultTypeHelper _AbpLoginResultTypeHelper;
        private readonly TokenAuthConfiguration _Configuration;
        private readonly IExternalAuthConfiguration _ExternalAuthConfiguration;
        private readonly IExternalAuthManager _ExternalAuthManager;
        private readonly UserRegistrationManager _UserRegistrationManager;
        private readonly AbpUserClaimsPrincipalFactory<User, Role> _ClaimsPrincipalFactory;
        private readonly IWebHostEnvironment _Env;
        private readonly IConfigurationRoot _appConfiguration;
        private readonly IUserApiKeyDomainService _UserApiKeyDomainService;
        private readonly ITwoFactorDomainService _TwoFactorDomainService;
        
        public TokenAuthController(
            LogInManager logInManager,
            UserManager userManager,
            ITenantCache tenantCache,
            AbpLoginResultTypeHelper abpLoginResultTypeHelper,
            TokenAuthConfiguration configuration,
            IExternalAuthConfiguration externalAuthConfiguration,
            IExternalAuthManager externalAuthManager,
            UserRegistrationManager userRegistrationManager, AbpUserClaimsPrincipalFactory<User, Role> claimsPrincipalFactory,
            IWebHostEnvironment env, IUserApiKeyDomainService userApiKeyDomainService,
            ITwoFactorDomainService twoFactorDomainService)
        {
            _UserManager = userManager;
            _LogInManager = logInManager;
            _TenantCache = tenantCache;
            _AbpLoginResultTypeHelper = abpLoginResultTypeHelper;
            _Configuration = configuration;
            _ExternalAuthConfiguration = externalAuthConfiguration;
            _ExternalAuthManager = externalAuthManager;
            _UserRegistrationManager = userRegistrationManager;
            _ClaimsPrincipalFactory = claimsPrincipalFactory;
            LocalizationSourceName = "Messages";
            _Env = env;
            _UserApiKeyDomainService = userApiKeyDomainService;
            _appConfiguration = env.GetAppConfiguration();
            _TwoFactorDomainService = twoFactorDomainService;
        }
        [HttpPost]
        [AbpAllowAnonymous]

        public async Task<AuthenticateResultModel> ValidateToken([FromBody] string token)
        {
            try
            {
                var claims = await ValidateExternalToken(token);
                var email = claims.Identities
                      .FirstOrDefault()
                      .Claims
                      .FirstOrDefault(m => m.Type == GenAISettings.ClaimType)
                      .Value;

                return await AuthenticateTokenAsync(email);
            }
            catch (UserFriendlyException)
            {
                throw;
            }
            catch (Exception)
            {
                throw new UserFriendlyException(L("CouldNotValidateExternalUser"));
            }
        }

        [HttpPost]
        [AbpAuthorize]
        public async Task<UserApiKeyDto> CreateApiKey([FromBody] CreateUserApiKeyDto entity)
        {
            UserApiKeyDto userApiKey = await _UserApiKeyDomainService.CreateUserApiKey(entity);
            return userApiKey;
        }
        [HttpPost]
        [AbpAllowAnonymous]

        public async Task<ResponseUserApiKeyDto> ValidateApiKey([FromBody] string apikey)
        {
            try
            {
                UserApiKeyDto userApiKey = await _UserApiKeyDomainService.GetUserApiKeyByKey(apikey);
                User user = await _UserManager.GetUserByIdAsync(userApiKey.UserId);

                return await AuthenticateApiKeyAsync(user);
            }
            catch (UserFriendlyException)
            {
                throw;
            }
            catch (Exception)
            {
                throw new UserFriendlyException(L("CouldNotValidateExternalUser"));
            }
        }


        private async Task<AuthenticateResultModel> AuthenticateTokenAsync(string email)
        {

            User user = await _UserManager.FindByEmailAsync(email);

            if (user == null) throw new UserFriendlyException(L("USER_NOT_FOUND"));
            //await ValidateTenantUser(user.Id);
            if (user.IsActive == false) throw new UserFriendlyException(L("USER_LOCKED"));

            ClaimsPrincipal principal = await _ClaimsPrincipalFactory.CreateAsync(user);

            string accessToken = CreateAccessToken(CreateJwtClaims(principal.Identity as ClaimsIdentity));

            return new AuthenticateResultModel
            {
                AccessToken = accessToken,
                EncryptedAccessToken = GetEncrpyedAccessToken(accessToken),
                ExpireInSeconds = (int)_Configuration.Expiration.TotalSeconds,
                UserId = user.Id
            };

        }
        private async Task<ResponseUserApiKeyDto> AuthenticateApiKeyAsync(User user)
        {
            if (user == null) throw new UserFriendlyException(L("USER_NOT_FOUND"));
            //await ValidateTenantUser(user.Id);
            if (user.IsActive == false) throw new UserFriendlyException(L("USER_LOCKED"));

            ClaimsPrincipal principal = await _ClaimsPrincipalFactory.CreateAsync(user);

            string accessToken = CreateAccessToken(CreateJwtClaims(principal.Identity as ClaimsIdentity));

            return new ResponseUserApiKeyDto
            {
                AccessToken = accessToken,
                EncryptedAccessToken = GetEncrpyedAccessToken(accessToken),
                ExpireInSeconds = (int)_Configuration.Expiration.TotalSeconds,
                UserId = user.Id
            };

        }
        private async Task<ClaimsPrincipal> ValidateExternalToken(string token)
        {
            string stsDiscoveryEndpoint = GenAISettings.DiscoveryEndpoint;
            var configManager = new ConfigurationManager<OpenIdConnectConfiguration>(stsDiscoveryEndpoint, new OpenIdConnectConfigurationRetriever());

            OpenIdConnectConfiguration config = await configManager.GetConfigurationAsync();
            TokenValidationParameters validationParameters = new TokenValidationParameters
            {
                ValidateIssuer = false,
                ValidAudience = GenAISettings.AzureAdClientId,
                ValidateAudience = true,
                IssuerSigningKeys = config.SigningKeys,
                ValidateLifetime = true,
            };

            JwtSecurityTokenHandler tokendHandler = new JwtSecurityTokenHandler();

            SecurityToken jwt;

            var result = tokendHandler.ValidateToken(token, validationParameters, out jwt);

            return result;

        }
        [HttpPost]
        public async Task<AuthenticateResultModel> AuthenticateToken([FromBody] AuthenticateTokenModel model)
        {
            UserLogin userLogin = await _LogInManager.AuthenticateToken(model.Token);

            if (userLogin == null) throw new UserFriendlyException(L("INVALID_TOKEN"));

            User user = await _UserManager.GetUserByIdAsync(userLogin.UserId);
            var roles = await _UserManager.GetRolesAsync(user);

            ClaimsPrincipal principal = await _ClaimsPrincipalFactory.CreateAsync(user);

            string accessToken = CreateAccessToken(CreateJwtClaims(principal.Identity as ClaimsIdentity));

            return new AuthenticateResultModel
            {
                AccessToken = accessToken,
                EncryptedAccessToken = GetEncrpyedAccessToken(accessToken),
                ExpireInSeconds = (int)_Configuration.Expiration.TotalSeconds,
                UserId = user.Id,
                Login = user.UserName,
                UserName = user.Name,
                Email = user.EmailAddress,
                Roles = roles.ToList()
            };

        }
        [HttpPost]
        public async Task<AuthenticateResultModel> Authenticate([FromBody] AuthenticateModel model)
        {
            AbpLoginResult<Tenant, User> loginResult = await GetLoginResultAsync(
                model.UserNameOrEmailAddress,
                model.Password,
                GetTenancyNameOrNull()
            );

            //await ValidateTenantUser(loginResult.User.Id);

            string accessToken = CreateAccessToken(CreateJwtClaims(loginResult.Identity));

            var roles = await _UserManager.GetRolesAsync(loginResult.User);

            return new AuthenticateResultModel
            {
                AccessToken = accessToken,
                EncryptedAccessToken = GetEncrpyedAccessToken(accessToken),
                ExpireInSeconds = (int)_Configuration.Expiration.TotalSeconds,
                UserId = loginResult.User.Id,
                Login = loginResult.User.UserName,
                UserName = loginResult.User.Name,
                Email = loginResult.User.EmailAddress,
                Roles = roles.ToList()
            };
        }

        [HttpGet]
        public List<ExternalLoginProviderInfoModel> GetExternalAuthenticationProviders()
        {
            return ObjectMapper.Map<List<ExternalLoginProviderInfoModel>>(_ExternalAuthConfiguration.Providers);
        }

        [HttpPost]
        public async Task<ExternalAuthenticateResultModel> ExternalAuthenticate([FromBody] ExternalAuthenticateModel model)
        {
            ExternalAuthUserInfo externalUser = await GetExternalUserInfo(model);

            AbpLoginResult<Tenant, User> loginResult = await _LogInManager.LoginAsync(new UserLoginInfo(model.AuthProvider, model.ProviderKey, model.AuthProvider), GetTenancyNameOrNull());

            switch (loginResult.Result)
            {
                case AbpLoginResultType.Success:
                    {
                        string accessToken = CreateAccessToken(CreateJwtClaims(loginResult.Identity));
                        return new ExternalAuthenticateResultModel
                        {
                            AccessToken = accessToken,
                            EncryptedAccessToken = GetEncrpyedAccessToken(accessToken),
                            ExpireInSeconds = (int)_Configuration.Expiration.TotalSeconds
                        };
                    }
                case AbpLoginResultType.UnknownExternalLogin:
                    {
                        User newUser = await RegisterExternalUserAsync(externalUser);
                        if (!newUser.IsActive)
                        {
                            return new ExternalAuthenticateResultModel
                            {
                                WaitingForActivation = true
                            };
                        }

                        // Try to login again with newly registered user!
                        loginResult = await _LogInManager.LoginAsync(new UserLoginInfo(model.AuthProvider, model.ProviderKey, model.AuthProvider), GetTenancyNameOrNull());
                        if (loginResult.Result != AbpLoginResultType.Success)
                        {
                            throw _AbpLoginResultTypeHelper.CreateExceptionForFailedLoginAttempt(
                                loginResult.Result,
                                model.ProviderKey,
                                GetTenancyNameOrNull()
                            );
                        }

                        return new ExternalAuthenticateResultModel
                        {
                            AccessToken = CreateAccessToken(CreateJwtClaims(loginResult.Identity)),
                            ExpireInSeconds = (int)_Configuration.Expiration.TotalSeconds
                        };
                    }
                default:
                    {
                        throw _AbpLoginResultTypeHelper.CreateExceptionForFailedLoginAttempt(
                            loginResult.Result,
                            model.ProviderKey,
                            GetTenancyNameOrNull()
                        );
                    }
            }
        }

        private async Task<User> RegisterExternalUserAsync(ExternalAuthUserInfo externalUser)
        {
            User user = await _UserRegistrationManager.RegisterAsync(
                externalUser.Name,
                externalUser.Surname,
                externalUser.EmailAddress,
                externalUser.EmailAddress,
                Domain.Entities.User.CreateRandomPassword(),
                true
            );

            user.Logins = new List<UserLogin>
            {
                new UserLogin
                {
                    LoginProvider = externalUser.Provider,
                    ProviderKey = externalUser.ProviderKey,
                    TenantId = user.TenantId
                }
            };

            await CurrentUnitOfWork.SaveChangesAsync();

            return user;
        }

        private async Task<ExternalAuthUserInfo> GetExternalUserInfo(ExternalAuthenticateModel model)
        {
            ExternalAuthUserInfo userInfo = await _ExternalAuthManager.GetUserInfo(model.AuthProvider, model.ProviderAccessCode);
            if (userInfo.ProviderKey != model.ProviderKey)
            {
                throw new UserFriendlyException(L("CouldNotValidateExternalUser"));
            }

            return userInfo;
        }

        private string GetTenancyNameOrNull()
        {
            if (!AbpSession.TenantId.HasValue)
            {
                return null;
            }

            return _TenantCache.GetOrNull(AbpSession.TenantId.Value)?.TenancyName;
        }

        private async Task<AbpLoginResult<Tenant, User>> GetLoginResultAsync(string usernameOrEmailAddress, string password, string tenancyName)
        {
            AbpLoginResult<Tenant, User> loginResult = await _LogInManager.LoginAsync(usernameOrEmailAddress, password, tenancyName);

            switch (loginResult.Result)
            {
                case AbpLoginResultType.Success:
                    return loginResult;
                default:
                    throw _AbpLoginResultTypeHelper.CreateExceptionForFailedLoginAttempt(loginResult.Result, usernameOrEmailAddress, tenancyName);
            }
        }

        private string CreateAccessToken(IEnumerable<Claim> claims, TimeSpan? expiration = null)
        {
            DateTime now = DateTime.UtcNow;

            JwtSecurityToken jwtSecurityToken = new JwtSecurityToken(
                issuer: _Configuration.Issuer,
                audience: _Configuration.Audience,
                claims: claims,
                notBefore: now,
                expires: now.Add(expiration ?? _Configuration.Expiration),
                signingCredentials: _Configuration.SigningCredentials
            );

            return new JwtSecurityTokenHandler().WriteToken(jwtSecurityToken);
        }

        private static List<Claim> CreateJwtClaims(ClaimsIdentity identity)
        {
            List<Claim> claims = identity.Claims.ToList();
            Claim nameIdClaim = claims.First(c => c.Type == ClaimTypes.NameIdentifier);

            // Specifically add the jti (random nonce), iat (issued timestamp), and sub (subject/user) claims.
            claims.AddRange(new[]
            {
                new Claim(JwtRegisteredClaimNames.Sub, nameIdClaim.Value),
                new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
                new Claim(JwtRegisteredClaimNames.Iat, DateTimeOffset.Now.ToUnixTimeSeconds().ToString(), ClaimValueTypes.Integer64)
            });

            return claims;
        }

        private string GetEncrpyedAccessToken(string accessToken)
        {
            return SimpleStringCipher.Instance.Encrypt(accessToken, AppConsts.DefaultPassPhrase);
        }

        [HttpPost]
        [AbpAllowAnonymous]
        public async Task<string> SendEmailTwoFactor(string email, string username)
        {
            return await _TwoFactorDomainService.TwoFactorSendCode(email, username);
        }
    }
}


