﻿using Abp.AspNetCore.Mvc.Controllers;
using Abp.IdentityFramework;
using GenAI.Crosscutting.Infra.Settings;
using Microsoft.AspNetCore.Identity;

namespace GenAI.Web.Core.Controllers
{
    public abstract class GenAIControllerBase : AbpController
    {

        protected GenAIControllerBase()
        {
            LocalizationSourceName = GenAIConsts.LocalizationLabelsSourceName;
        }

        protected void CheckErrors(IdentityResult identityResult)
        {
            identityResult.CheckErrors(LocalizationManager);
        }
    }
}


