﻿using Abp.Dependency;
using Abp.Runtime.Session;
using Microsoft.AspNetCore.Mvc.Filters;
using System.Threading.Tasks;

namespace GenAI.Web.Core.Filter
{
    public class ValidateCompanyFilter : IAsyncActionFilter, ITransientDependency
    {
        private readonly IAbpSession _Session;
        public ValidateCompanyFilter()
        {
            _Session = IocManager.Instance.Resolve<IAbpSession>();
        }
        public async Task OnActionExecutionAsync(ActionExecutingContext context, ActionExecutionDelegate next)
        {            
            var resultContext = await next();
        }
    }
}
