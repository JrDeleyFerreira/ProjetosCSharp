﻿using GenAI.Domain.Entities.Logs;
using Microsoft.Extensions.Logging;
using Microsoft.WindowsAzure.Storage.Table;
using System;

namespace GenAI.Web.Core.Logs
{
    public class AzureTableLogger : ILogger
    {
        private readonly CloudTable loggingTable;

        public AzureTableLogger(string connectionString, string tableName)
        {
            var storageAccount = Microsoft.WindowsAzure.Storage.CloudStorageAccount.Parse(connectionString);
            var cloudTableClient = storageAccount.CreateCloudTableClient();
            loggingTable = cloudTableClient.GetTableReference(tableName);
            loggingTable.CreateIfNotExistsAsync();
        }

        public IDisposable BeginScope<TState>(TState state)
        {
            return null;
        }

        public bool IsEnabled(LogLevel logLevel)
        {
            return true;
        }

        public void Log(LogLevel logLevel, string message)
        {
            Log(logLevel, new EventId(), message, null, (state, exception) => message);
        }

        public void Log<TState>(LogLevel logLevel, EventId eventId, TState state, Exception exception, Func<TState, Exception, string> formatter)
        {
            var log = new LogEntity
            {
                EventId = eventId.ToString(),
                LogLevel = logLevel.ToString(),
                Message = formatter(state, exception),//exception?.ToString(),
                PartitionKey = DateTime.Now.ToString("yyyyMMdd"),
                RowKey = Guid.NewGuid().ToString()
            };

            var insertOp = TableOperation.Insert(log);
            loggingTable.ExecuteAsync(insertOp).GetAwaiter().GetResult();
        }
    }
}
