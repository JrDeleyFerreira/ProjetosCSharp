  /*
SCRIPT PARA CARGA DE COMPONENTE
*/

/*
SCRIPT PARA CRIA��O DO <COMPONENT_DESCRIPTION>
*/
BEGIN TRAN

DECLARE
	@ComponentConfigurationId uniqueidentifier = newid()
	, @StatusEntityModel nvarchar(20) = 'ACTIVE'
	, @Code nvarchar(50)
	, @Description nvarchar(max)
	, @Title nvarchar(100)
	, @TechnicalDescription nvarchar(max)
	, @KafkaTopic nvarchar(100)
	, @CreatorUserId bigint = 1
	, @CreationTime datetime2(7) = GETDATE()
	, @InputCollection nvarchar(max)
	, @OutputCollection nvarchar(max)

/*
SCRIPT PARA CRIA��O DO <COMPONENT_DESCRIPTION>
*/
BEGIN TRAN

SELECT 
	@ComponentConfigurationId = '7CA86451-7163-4376-80CF-76E7FC84AA02' --select newid()
	, @StatusEntityModel = 'ACTIVE'
	, @Code = 'CD_AFFINITY_COMPASS'
	, @Description = 'Affinity Compass Component'
	, @Title = 'Affinity Compass Component'
	, @TechnicalDescription = 'Affinity Compass Component'
	, @KafkaTopic = null
	, @CreatorUserId = 1
	, @CreationTime = GETDATE()
	, @InputCollection = '{
                            "input":{
                                "json_schema":{
                                    "$schema":"http://json-schema.org/draft-07/schema#",
                                    "type":"object",
                                    "properties":{
                                    "CD_PR_COMPONENT_personal_access_token_kv_string":{
                                        "type":"string",
                                        "default":"{{CD_PR_COMPONENT_personal_access_token_kv_string}}",
                                        "description":"Token de acesso pessoal do Azure no Key Vault",
                                        "title":"Token de Acesso Pessoal do Azure no Key Vault"
                                    },
                                    "CD_PR_COMPONENT_pull_request_url_string":{
                                        "type":"string",
                                        "default":"{{CD_PR_COMPONENT_pull_request_url_string}}",
                                        "description":"URL do Pull Request",
                                        "title":"URL do Pull Request"
                                    },
                                    "CD_PR_COMPONENT_organization_url_string":{
                                        "type":"string",
                                        "default":"https://iautomation.visualstudio.com/",
                                        "description":"URL da organiza��o no Visual Studio",
                                        "title":"URL da Organiza��o no Visual Studio"
                                    },
                                    "CD_PR_COMPONENT_extra_instructions_string":{
                                        "type":"string",
                                        "default":"",
                                        "description":"Instru��es extras para o componente",
                                        "title":"Instru��es Extras"
                                    },
                                    "CD_PR_COMPONENT_open_ai_api_key_kv_string":{
                                        "type":"string",
                                        "default":"OPENAI-API-KEY4",
                                        "description":"Chave da API Open AI no Key Vault",
                                        "title":"Chave da API Open AI no Key Vault"
                                    },
                                    "CD_PR_COMPONENT_open_ai_api_base_string":{
                                        "type":"string",
                                        "default":"{{CD_PR_COMPONENT_open_ai_api_base_string}}",
                                        "description":"Base URL da API Open AI",
                                        "title":"Base URL da API Open AI"
                                    },
                                    "CD_PR_COMPONENT_open_ai_api_version_string":{
                                        "type":"string",
                                        "default":"2023-07-01-preview",
                                        "description":"Vers�o da API Open AI",
                                        "title":"Vers�o da API Open AI"
                                    },
                                    "CD_PR_COMPONENT_open_ai_api_type_string":{
                                        "type":"string",
                                        "default":"azure",
                                        "description":"Tipo de API da Open AI",
                                        "title":"Tipo de API da Open AI"
                                    },
                                    "CD_PR_COMPONENT_open_ai_engine_string":{
                                        "type":"string",
                                        "default":"gpt-4-32k",
                                        "description":"Motor da Open AI utilizado",
                                        "title":"Motor da Open AI"
                                    }
                                    },
                                    "required":[
                                    "CD_PR_COMPONENT_personal_access_token_kv_string",
                                    "CD_PR_COMPONENT_pull_request_url_string",
                                    "CD_PR_COMPONENT_organization_url_string",
                                    "CD_PR_COMPONENT_extra_instructions_string",
                                    "CD_PR_COMPONENT_open_ai_api_key_kv_string",
                                    "CD_PR_COMPONENT_open_ai_api_base_string",
                                    "CD_PR_COMPONENT_open_ai_api_version_string",
                                    "CD_PR_COMPONENT_open_ai_api_type_string",
                                    "CD_PR_COMPONENT_open_ai_engine_string"
                                    ]
                                },
                                "json_schema_sample":{
                                    "CD_PR_COMPONENT_personal_access_token_kv_string":"exemplo_token_acesso_pessoal",
                                    "CD_PR_COMPONENT_pull_request_url_string":"https://exemplo.visualstudio.com/repositorio/_pullRequest/123",
                                    "CD_PR_COMPONENT_organization_url_string":"https://exemplo.visualstudio.com/",
                                    "CD_PR_COMPONENT_extra_instructions_string":"Instru��es adicionais relevantes aqui",
                                    "CD_PR_COMPONENT_open_ai_api_key_kv_string":"OPENAI-API-KEY4",
                                    "CD_PR_COMPONENT_open_ai_api_base_string":"https://api.openai.com",
                                    "CD_PR_COMPONENT_open_ai_api_version_string":"2023-07-01-preview",
                                    "CD_PR_COMPONENT_open_ai_api_type_string":"azure",
                                    "CD_PR_COMPONENT_open_ai_engine_string":"gpt-4-32k"
                                },
                                "default_configuration":null,
                                "property_configuration":{
                                    "properties":[
                                    {
                                        "name":"CD_PR_COMPONENT_personal_access_token_kv_string",
                                        "type_property":"string",
                                        "label_property":null,
                                        "full_path":"CD_PR_COMPONENT_personal_access_token_kv_string",
                                        "format_property":null,
                                        "enum":null,
                                        "required":true,
                                        "default_value":"{{CD_PR_COMPONENT_personal_access_token_kv_string}}",
                                        "actual_value":null,
                                        "title":"Token de Acesso Pessoal do Azure no Key Vault",
                                        "description":"Token de acesso pessoal do Azure no Key Vault",
                                        "items":null,
                                        "child_properties":null
                                    },
                                    {
                                        "name":"CD_PR_COMPONENT_pull_request_url_string",
                                        "type_property":"string",
                                        "label_property":null,
                                        "full_path":"CD_PR_COMPONENT_pull_request_url_string",
                                        "format_property":null,
                                        "enum":null,
                                        "required":true,
                                        "default_value":"{{CD_PR_COMPONENT_pull_request_url_string}}",
                                        "actual_value":null,
                                        "title":"URL do Pull Request",
                                        "description":"URL do Pull Request",
                                        "items":null,
                                        "child_properties":null
                                    },
                                    {
                                        "name":"CD_PR_COMPONENT_organization_url_string",
                                        "type_property":"string",
                                        "label_property":null,
                                        "full_path":"CD_PR_COMPONENT_organization_url_string",
                                        "format_property":null,
                                        "enum":null,
                                        "required":true,
                                        "default_value":"https://iautomation.visualstudio.com/",
                                        "actual_value":null,
                                        "title":"URL da Organiza��o no Visual Studio",
                                        "description":"URL da organiza��o no Visual Studio",
                                        "items":null,
                                        "child_properties":null
                                    },
                                    {
                                        "name":"CD_PR_COMPONENT_extra_instructions_string",
                                        "type_property":"string",
                                        "label_property":null,
                                        "full_path":"CD_PR_COMPONENT_extra_instructions_string",
                                        "format_property":null,
                                        "enum":null,
                                        "required":true,
                                        "default_value":"",
                                        "actual_value":null,
                                        "title":"Instru��es Extras",
                                        "description":"Instru��es extras para o componente",
                                        "items":null,
                                        "child_properties":null
                                    },
                                    {
                                        "name":"CD_PR_COMPONENT_open_ai_api_key_kv_string",
                                        "type_property":"string",
                                        "label_property":null,
                                        "full_path":"CD_PR_COMPONENT_open_ai_api_key_kv_string",
                                        "format_property":null,
                                        "enum":null,
                                        "required":true,
                                        "default_value":"OPENAI-API-KEY4",
                                        "actual_value":null,
                                        "title":"Chave da API Open AI no Key Vault",
                                        "description":"Chave da API Open AI no Key Vault",
                                        "items":null,
                                        "child_properties":null
                                    },
                                    {
                                        "name":"CD_PR_COMPONENT_open_ai_api_base_string",
                                        "type_property":"string",
                                        "label_property":null,
                                        "full_path":"CD_PR_COMPONENT_open_ai_api_base_string",
                                        "format_property":null,
                                        "enum":null,
                                        "required":true,
                                        "default_value":"{{CD_PR_COMPONENT_open_ai_api_base_string}}",
                                        "actual_value":null,
                                        "title":"Base URL da API Open AI",
                                        "description":"Base URL da API Open AI",
                                        "items":null,
                                        "child_properties":null
                                    },
                                    {
                                        "name":"CD_PR_COMPONENT_open_ai_api_version_string",
                                        "type_property":"string",
                                        "label_property":null,
                                        "full_path":"CD_PR_COMPONENT_open_ai_api_version_string",
                                        "format_property":null,
                                        "enum":null,
                                        "required":true,
                                        "default_value":"2023-07-01-preview",
                                        "actual_value":null,
                                        "title":"Vers�o da API Open AI",
                                        "description":"Vers�o da API Open AI",
                                        "items":null,
                                        "child_properties":null
                                    },
                                    {
                                        "name":"CD_PR_COMPONENT_open_ai_api_type_string",
                                        "type_property":"string",
                                        "label_property":null,
                                        "full_path":"CD_PR_COMPONENT_open_ai_api_type_string",
                                        "format_property":null,
                                        "enum":null,
                                        "required":true,
                                        "default_value":"azure",
                                        "actual_value":null,
                                        "title":"Tipo de API da Open AI",
                                        "description":"Tipo de API da Open AI",
                                        "items":null,
                                        "child_properties":null
                                    },
                                    {
                                        "name":"CD_PR_COMPONENT_open_ai_engine_string",
                                        "type_property":"string",
                                        "label_property":null,
                                        "full_path":"CD_PR_COMPONENT_open_ai_engine_string",
                                        "format_property":null,
                                        "enum":null,
                                        "required":true,
                                        "default_value":"gpt-4-32k",
                                        "actual_value":null,
                                        "title":"Motor da Open AI",
                                        "description":"Motor da Open AI utilizado",
                                        "items":null,
                                        "child_properties":null
                                    }
                                    ]
                                }
                            }
                        }'
	, @OutputCollection = '{
                               "output":{
                                  "json_schema":{
                                     "$schema":"http://json-schema.org/draft-07/schema#",
                                     "type":"object",
                                     "properties":{
                                        "CD_PR_COMPONENT_output_text_string":{
                                           "type":"string",
                                           "title":"Output Text",
                                           "description":"Texto de sa�da para CD_PR_COMPONENT"
                                        }
                                     },
                                     "required":[
                                        "CD_PR_COMPONENT_output_text_string"
                                     ]
                                  },
                                  "json_schema_sample":{
                                     "CD_PR_COMPONENT_output_text_string":"Este � um texto de sa�da exemplo."
                                  },
                                  "default_configuration":null,
                                  "property_configuration":{
                                     "properties":[
                                        {
                                           "name":"CD_PR_COMPONENT_output_text_string",
                                           "type_property":"string",
                                           "label_property":null,
                                           "full_path":"CD_PR_COMPONENT_output_text_string",
                                           "format_property":null,
                                           "enum":null,
                                           "required":true,
                                           "default_value":null,
                                           "actual_value":null,
                                           "title":"Output Text",
                                           "description":"Texto de sa�da para CD_PR_COMPONENT",
                                           "items":null,
                                           "child_properties":null
                                        }
                                     ]
                                  }
                               },
                               "partial_outputs":[
      
                               ]
                            }'

INSERT INTO [genai].[ComponentConfigurations] 
(
	[Id]
	, [StatusEntityModel]
	, [Code]
	, [Description]
	, [Title]
	, [TechnicalDescription]
	, [KafkaTopic]
	, [CreatorUserId]
	, [CreationTime]
) VALUES (
	@ComponentConfigurationId
	, @StatusEntityModel
	, @Code
	, @Description
	, @Title
	, @TechnicalDescription
	, @KafkaTopic
	, @CreatorUserId
	, @CreationTime
)

INSERT INTO [genai].[ComponentDetailConfigurations]
(
	[Id]
	,[ComponentConfigurationId]
    ,[Input]
    ,[Output]
    ,[CreatorUserId]
    ,[CreationTime]
) VALUES (
	NEWID()
	, @ComponentConfigurationId
	, @InputCollection
	, @OutputCollection
	, @CreatorUserId
	, @CreationTime
)

SELECT * 
FROM [genai].[ComponentConfigurations] CC WITH(NOLOCK)
LEFT JOIN [genai].[ComponentDetailConfigurations] CDC WITH(NOLOCK) ON CDC.ComponentConfigurationId = CC.Id
WHERE CC.Id = @ComponentConfigurationId

COMMIT
