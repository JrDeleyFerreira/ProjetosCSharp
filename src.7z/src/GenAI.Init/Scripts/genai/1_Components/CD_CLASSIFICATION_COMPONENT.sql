/*
SCRIPT PARA CARGA DE TODOS OS COMPONENTES
*/

/*
SCRIPT PARA CRIA��O COMPONENTE DE OCR
*/
BEGIN TRAN

DECLARE
	@ComponentConfigurationId uniqueidentifier = newid()
	, @StatusEntityModel nvarchar(20) = 'ACTIVE'
	, @Code nvarchar(50)
	, @Description nvarchar(max)
	, @Title nvarchar(100)
	, @TechnicalDescription nvarchar(max)
	, @KafkaTopic nvarchar(100)
	, @CreatorUserId bigint = 1
	, @CreationTime datetime2(7) = GETDATE()
	, @InputCollection nvarchar(max)
	, @OutputCollection nvarchar(max)

/*
SCRIPT PARA CRIA��O DO COMPONENTE DE QA
*/
BEGIN TRAN

SELECT 
	@ComponentConfigurationId = 'a10bb2cf-b406-42c0-ad0a-e5bd2c83f5ab' --newid()
	, @StatusEntityModel = 'ACTIVE'
	, @Code = 'CD_CLASSIFICATION'
	, @Description = '## ClassificationComponent\n\n**Objetivo**: Componente respons�vel por realizar uma classifica��o de texto com base em uma lista conhecida.\n\n**Como funciona**: O componente recebe um texto e realiza uma classifica��o no mesmo. O resultado da classifica��o tem como base a lista conhecida enviada previamente.\n\n**Exemplo de uso**: Eu tenho um texto e quero realizar uma classifica��o no mesmo.\n\n\n'
	, @Title = 'Classification Component'
	, @TechnicalDescription = '## ClassificationComponent\n\n**Objetivo**: Componente respons�vel por realizar uma classifica��o de texto com base em uma lista conhecida.\n\n**Como funciona**: O componente recebe um texto e realiza uma classifica��o no mesmo. O resultado da classifica��o tem como base a lista conhecida enviada previamente.\n\n**Exemplo de uso**: Eu tenho um texto e quero realizar uma classifica��o no mesmo.\n\n\n\n'
	, @KafkaTopic = 'genai-classification-input'
	, @CreatorUserId = 1
	, @CreationTime = GETDATE()
	, @InputCollection = '{
        "input": {
            "json_schema": {
                "$schema": "http://json-schema.org/draft-07/schema#",
                "type": "object",
                "properties": {
                    "CD_CLASSIFICATION_open_ai_api_base_string": {
                        "type": "string",
                        "default": "{{CD_CLASSIFICATION_open_ai_api_base_string}}",
                        "description": "Open AI URL (URL da Open AI)",
                        "title": "Open AI URL"
                    },
                    "CD_CLASSIFICATION_open_ai_api_version_string": {
                        "type": "string",
                        "default": "{{CD_CLASSIFICATION_open_ai_api_version_string}}",
                        "description": "Open AI API Version",
                        "title": "Open AI API Version"
                    },
                    "CD_CLASSIFICATION_open_ai_api_type_string": {
                        "type": "string",
                        "default": "{{CD_CLASSIFICATION_open_ai_api_type_string}}",
                        "description": "Open AI API Type",
                        "title": "Open AI API Type"
                    },
                    "CD_CLASSIFICATION_open_ai_api_key_string": {
                        "type": "string",
                        "default": "{{CD_CLASSIFICATION_open_ai_api_key_string}}",
                        "description": "Open AI Key (Chave da Open AI)",
                        "title": "Open AI Key"
                    },
                    "CD_CLASSIFICATION_input_text_string": {
                        "type": "string",
                        "default": "{{CD_CLASSIFICATION_input_text_string}}",
                        "description": "Texto a ser classificado",
                        "title": "Texto a ser classificado"
                    },
                    "CD_CLASSIFICATION_prompt_string": {
                        "type": "string",
                        "default": "{{CD_CLASSIFICATION_prompt_string}}",
                        "description": "prompt base para classifica��o",
                        "title": "Prompt base para classifica��o"
                    },
                    "CD_CLASSIFICATION_system_prompt_string": {
                        "type": "string",
                        "default": "{{CD_CLASSIFICATION_system_prompt_string}}",
                        "description": "Texto de prompt do sistema",
                        "title": "Texto de prompt do sistema"
                    },
                    "CD_CLASSIFICATION_list_classification": {
                        "type": "array",
                        "items": {
                            "type": "string"
                        },
                        "default": [],
                        "description": "Array dos itens possiveis para classifica��o",
                        "title": "Array dos itens possiveis para classifica��oo"
                    },
                    "CD_CLASSIFICATION_open_ai_chat_completion_body_object": {
                        "type": "object",
                        "properties": {
                            "CD_CLASSIFICATION_engine_string": {
                                "type": "string",
                                "enum": [
                                    "gpt-35-turbo-16k",
                                    "gpt-4-32k"
                                ],
                                "default": "gpt-4-32k",
                                "description": "Vers�o do modelo da Open AI",
                                "title": "Vers�o do modelo da Open AI"
                            },
                            "CD_CLASSIFICATION_messages_array": {
                                "type": "array",
                                "items": {
                                    "type": "string"
                                },
                                "default": [],
                                "description": "Array de mensagens para conversa��o",
                                "title": "Array de mensagens para conversa��o"
                            },
                            "CD_CLASSIFICATION_temperature_number": {
                                "type": "number",
                                "default": 0.5,
                                "description": "Par�metro de temperatura para gera��o de texto",
                                "title": "Par�metro de temperatura para gera��o de texto"
                            },
                            "CD_CLASSIFICATION_max_tokens_number": {
                                "type": "number",
                                "default": 2000,
                                "description": "N�mero m�ximo de tokens a serem gerados",
                                "title": "N�mero m�ximo de tokens a serem gerados"
                            },
                            "CD_CLASSIFICATION_top_p_number": {
                                "type": "number",
                                "default": 0.95,
                                "description": "Par�metro de top-p sampling",
                                "title": "Par�metro de top-p sampling"
                            },
                            "CD_CLASSIFICATION_frequency_penalty_number": {
                                "type": "number",
                                "default": 0,
                                "description": "Penalidade de frequ�ncia para gera��o de texto",
                                "title": "Penalidade de frequ�ncia para gera��o de texto"
                            },
                            "CD_CLASSIFICATION_presence_penalty_number": {
                                "type": "number",
                                "default": 0,
                                "description": "Penalidade de presen�a para gera��o de texto",
                                "title": "Penalidade de presen�a para gera��o de texto"
                            }
                        },
                        "required": [
                            "CD_CLASSIFICATION_engine_string",
                            "CD_CLASSIFICATION_temperature_number",
                            "CD_CLASSIFICATION_max_tokens_number",
                            "CD_CLASSIFICATION_top_p_number",
                            "CD_CLASSIFICATION_frequency_penalty_number",
                            "CD_CLASSIFICATION_presence_penalty_number"
                        ],
                        "description": "Corpo da requisi��o para a API de gera��o de chat da Open AI",
                        "title": "Corpo da requisi��o para a API de gera��o de chat da Open AI"
                    }
                },
                "required": [
                    "CD_CLASSIFICATION_open_ai_api_base_string",
                    "CD_CLASSIFICATION_open_ai_api_version_string",
                    "CD_CLASSIFICATION_open_ai_api_key_string",
                    "CD_CLASSIFICATION_open_ai_api_type_string",
                    "CD_CLASSIFICATION_input_text_string",
                    "CD_CLASSIFICATION_prompt_string",
                    "CD_CLASSIFICATION_system_prompt_string",
                    "CD_CLASSIFICATION_open_ai_chat_completion_body_object",
                    "CD_CLASSIFICATION_list_classification"
                ]
            },
            "json_schema_sample": {
                "CD_CLASSIFICATION_open_ai_api_base_string": "https://api.openai.com/v1/engines/davinci/completions",
                "CD_CLASSIFICATION_open_ai_api_key_string": "OPEN_AI_KEY",
                "CD_CLASSIFICATION_open_ai_api_version_string": "2023-07-01-preview",
                "CD_CLASSIFICATION_open_ai_api_type_string": "azure",
                "CD_CLASSIFICATION_input_text_string": "Texto de sa�da para exemplo de mapping",
                "CD_CLASSIFICATION_prompt_string": "Logo abaixo segue um prompt e um template schema para o mapeamento de dados...",
                "CD_CLASSIFICATION_system_prompt_string": "Quero que voc� resuma o texto a 100 palavras.",
                "CD_CLASSIFICATION_list_classification": [
                    "Valor1",
                    "Valor2"
                ],
                "CD_CLASSIFICATION_open_ai_chat_completion_body_object": {
                    "CD_CLASSIFICATION_engine_string": "gpt-4-32k",
                    "CD_CLASSIFICATION_messages_array": [],
                    "CD_CLASSIFICATION_temperature_number": 0.5,
                    "CD_CLASSIFICATION_max_tokens_number": 2000,
                    "CD_CLASSIFICATION_top_p_number": 0.95,
                    "CD_CLASSIFICATION_frequency_penalty_number": 0,
                    "CD_CLASSIFICATION_presence_penalty_number": 0
                }
            },
            "default_configuration": null,
            "property_configuration": {
                "properties": [
                    {
                        "name": "CD_CLASSIFICATION_open_ai_api_base_string",
                        "type_property": "string",
                        "label_property": null,
                        "full_path": "CD_CLASSIFICATION_open_ai_api_base_string",
                        "format_property": null,
                        "enum": null,
                        "required": true,
                        "default_value": "{{CD_CLASSIFICATION_open_ai_api_base_string}}",
                        "actual_value": null,
                        "title": "Open AI URL",
                        "description": "Open AI URL (URL da Open AI)",
                        "items": null,
                        "child_properties": null
                    },
                    {
                        "name": "CD_CLASSIFICATION_open_ai_api_version_string",
                        "type_property": "string",
                        "label_property": null,
                        "full_path": "CD_CLASSIFICATION_open_ai_api_version_string",
                        "format_property": null,
                        "enum": null,
                        "required": true,
                        "default_value": "{{CD_CLASSIFICATION_open_ai_api_version_string}}",
                        "actual_value": null,
                        "title": "Open AI API Version",
                        "description": "Open AI API Version",
                        "items": null,
                        "child_properties": null
                    },
                    {
                        "name": "CD_CLASSIFICATION_open_ai_api_type_string",
                        "type_property": "string",
                        "label_property": null,
                        "full_path": "CD_CLASSIFICATION_open_ai_api_type_string",
                        "format_property": null,
                        "enum": null,
                        "required": true,
                        "default_value": "{{CD_CLASSIFICATION_open_ai_api_type_string}}",
                        "actual_value": null,
                        "title": "Open AI API Type",
                        "description": "Open AI API Type",
                        "items": null,
                        "child_properties": null
                    },
                    {
                        "name": "CD_CLASSIFICATION_open_ai_api_key_string",
                        "type_property": "string",
                        "label_property": null,
                        "full_path": "CD_CLASSIFICATION_open_ai_api_key_string",
                        "format_property": null,
                        "enum": null,
                        "required": true,
                        "default_value": "{{CD_CLASSIFICATION_open_ai_api_key_string}}",
                        "actual_value": null,
                        "title": "Open AI Key",
                        "description": "Open AI Key (Chave da Open AI)",
                        "items": null,
                        "child_properties": null
                    },
                    {
                        "name": "CD_CLASSIFICATION_input_text_string",
                        "type_property": "string",
                        "label_property": null,
                        "full_path": "CD_CLASSIFICATION_input_text_string",
                        "format_property": null,
                        "enum": null,
                        "required": true,
                        "default_value": "{{CD_CLASSIFICATION_input_text_string}}",
                        "actual_value": null,
                        "title": "Texto a ser classificado",
                        "description": "Texto a ser classificado",
                        "items": null,
                        "child_properties": null
                    },
                    {
                        "name": "CD_CLASSIFICATION_prompt_string",
                        "type_property": "string",
                        "label_property": null,
                        "full_path": "CD_CLASSIFICATION_prompt_string",
                        "format_property": null,
                        "enum": null,
                        "required": true,
                        "default_value": "{{CD_CLASSIFICATION_prompt_string}}",
                        "actual_value": null,
                        "title": "Prompt base para classifica��o",
                        "description": "prompt base para classifica��o",
                        "items": null,
                        "child_properties": null
                    },
                    {
                        "name": "CD_CLASSIFICATION_system_prompt_string",
                        "type_property": "string",
                        "label_property": null,
                        "full_path": "CD_CLASSIFICATION_system_prompt_string",
                        "format_property": null,
                        "enum": null,
                        "required": true,
                        "default_value": "{{CD_CLASSIFICATION_system_prompt_string}}",
                        "actual_value": null,
                        "title": "Texto de prompt do sistema",
                        "description": "Texto de prompt do sistema",
                        "items": null,
                        "child_properties": null
                    },
                    {
                        "name": "CD_CLASSIFICATION_list_classification",
                        "type_property": "array",
                        "label_property": null,
                        "full_path": "CD_CLASSIFICATION_list_classification",
                        "format_property": null,
                        "enum": null,
                        "required": true,
                        "default_value": [],
                        "actual_value": null,
                        "title": "Array dos itens possiveis para classifica��oo",
                        "description": "Array dos itens possiveis para classifica��o",
                        "items": {
                            "type_item": "string",
                            "properties": null
                        },
                        "child_properties": []
                    },
                    {
                        "name": "CD_CLASSIFICATION_open_ai_chat_completion_body_object",
                        "type_property": "object",
                        "label_property": null,
                        "full_path": "CD_CLASSIFICATION_open_ai_chat_completion_body_object",
                        "format_property": null,
                        "enum": null,
                        "required": true,
                        "default_value": null,
                        "actual_value": null,
                        "title": "Corpo da requisi��o para a API de gera��o de chat da Open AI",
                        "description": "Corpo da requisi��o para a API de gera��o de chat da Open AI",
                        "items": null,
                        "child_properties": [
                            {
                                "name": "CD_CLASSIFICATION_engine_string",
                                "type_property": "string",
                                "label_property": null,
                                "full_path": "CD_CLASSIFICATION_open_ai_chat_completion_body_object.CD_CLASSIFICATION_engine_string",
                                "format_property": null,
                                "enum": [
                                    "gpt-35-turbo-16k",
                                    "gpt-4-32k"
                                ],
                                "required": true,
                                "default_value": "gpt-4-32k",
                                "actual_value": null,
                                "title": "Vers�o do modelo da Open AI",
                                "description": "Vers�o do modelo da Open AI",
                                "items": null,
                                "child_properties": null
                            },
                            {
                                "name": "CD_CLASSIFICATION_messages_array",
                                "type_property": "array",
                                "label_property": null,
                                "full_path": "CD_CLASSIFICATION_open_ai_chat_completion_body_object.CD_CLASSIFICATION_messages_array",
                                "format_property": null,
                                "enum": null,
                                "required": false,
                                "default_value": [],
                                "actual_value": null,
                                "title": "Array de mensagens para conversa��o",
                                "description": "Array de mensagens para conversa��o",
                                "items": {
                                    "type_item": "string",
                                    "properties": null
                                },
                                "child_properties": []
                            },
                            {
                                "name": "CD_CLASSIFICATION_temperature_number",
                                "type_property": "number",
                                "label_property": null,
                                "full_path": "CD_CLASSIFICATION_open_ai_chat_completion_body_object.CD_CLASSIFICATION_temperature_number",
                                "format_property": null,
                                "enum": null,
                                "required": true,
                                "default_value": 0.5,
                                "actual_value": null,
                                "title": "Par�metro de temperatura para gera��o de texto",
                                "description": "Par�metro de temperatura para gera��o de texto",
                                "items": null,
                                "child_properties": null
                            },
                            {
                                "name": "CD_CLASSIFICATION_max_tokens_number",
                                "type_property": "number",
                                "label_property": null,
                                "full_path": "CD_CLASSIFICATION_open_ai_chat_completion_body_object.CD_CLASSIFICATION_max_tokens_number",
                                "format_property": null,
                                "enum": null,
                                "required": true,
                                "default_value": 2000,
                                "actual_value": null,
                                "title": "N�mero m�ximo de tokens a serem gerados",
                                "description": "N�mero m�ximo de tokens a serem gerados",
                                "items": null,
                                "child_properties": null
                            },
                            {
                                "name": "CD_CLASSIFICATION_top_p_number",
                                "type_property": "number",
                                "label_property": null,
                                "full_path": "CD_CLASSIFICATION_open_ai_chat_completion_body_object.CD_CLASSIFICATION_top_p_number",
                                "format_property": null,
                                "enum": null,
                                "required": true,
                                "default_value": 0.95,
                                "actual_value": null,
                                "title": "Par�metro de top-p sampling",
                                "description": "Par�metro de top-p sampling",
                                "items": null,
                                "child_properties": null
                            },
                            {
                                "name": "CD_CLASSIFICATION_frequency_penalty_number",
                                "type_property": "number",
                                "label_property": null,
                                "full_path": "CD_CLASSIFICATION_open_ai_chat_completion_body_object.CD_CLASSIFICATION_frequency_penalty_number",
                                "format_property": null,
                                "enum": null,
                                "required": true,
                                "default_value": 0,
                                "actual_value": null,
                                "title": "Penalidade de frequ�ncia para gera��o de texto",
                                "description": "Penalidade de frequ�ncia para gera��o de texto",
                                "items": null,
                                "child_properties": null
                            },
                            {
                                "name": "CD_CLASSIFICATION_presence_penalty_number",
                                "type_property": "number",
                                "label_property": null,
                                "full_path": "CD_CLASSIFICATION_open_ai_chat_completion_body_object.CD_CLASSIFICATION_presence_penalty_number",
                                "format_property": null,
                                "enum": null,
                                "required": true,
                                "default_value": 0,
                                "actual_value": null,
                                "title": "Penalidade de presen�a para gera��o de texto",
                                "description": "Penalidade de presen�a para gera��o de texto",
                                "items": null,
                                "child_properties": null
                            }
                        ]
                    }
                ]
            }
        }
    }'
	, @OutputCollection = '{
        "output": {
            "json_schema": {
                "$schema": "http://json-schema.org/draft-07/schema#",
                "type": "object",
                "properties": {
                    "CD_CLASSIFICATION_output_text_string": {
                        "type": "string",
                        "default": "",
                        "title": "Output Text",
                        "description": "Texto de sa�da"
                    },
                    "CD_CLASSIFICATION_metadata": {
                        "type": "object",
                        "properties": {
                            "prompt_tokens_string": {
                                "type": "string",
                                "default": "",
                                "title": "Prompt Tokens",
                                "description": "Prompt Tokens"
                            },
                            "completion_tokens_string": {
                                "type": "string",
                                "default": "",
                                "title": "Completion Tokens",
                                "description": "Completion Tokens"
                            },
                            "total_tokens_string": {
                                "type": "string",
                                "default": "",
                                "title": "Total Tokens",
                                "description": "Total Tokens"
                            }
                        },
                        "required": [
                            "prompt_tokens_string",
                            "completion_tokens_string",
                            "total_tokens_string"
                        ]
                    }
                },
                "required": [
                    "CD_CLASSIFICATION_output_text_string",
                    "CD_CLASSIFICATION_metadata"
                ]
            },
            "json_schema_sample": {
                "CD_CLASSIFICATION_output_text_string": "Este � o texto sumarizado.",
                "CD_CLASSIFICATION_metadata": {
                    "prompt_tokens_string": "Estes s�o os tokens de prompt.",
                    "completion_tokens_string": "Estes s�o os tokens de conclus�o.",
                    "total_tokens_string": "100"
                }
            },
            "default_configuration": null,
            "property_configuration": {
                "properties": [
                    {
                        "name": "CD_CLASSIFICATION_output_text_string",
                        "type_property": "string",
                        "label_property": null,
                        "full_path": "CD_CLASSIFICATION_output_text_string",
                        "format_property": null,
                        "enum": null,
                        "required": true,
                        "default_value": "",
                        "actual_value": null,
                        "title": "Output Text",
                        "description": "Texto de sa�da",
                        "items": null,
                        "child_properties": null
                    },
                    {
                        "name": "CD_CLASSIFICATION_metadata",
                        "type_property": "object",
                        "label_property": null,
                        "full_path": "CD_CLASSIFICATION_metadata",
                        "format_property": null,
                        "enum": null,
                        "required": true,
                        "default_value": null,
                        "actual_value": null,
                        "title": null,
                        "description": null,
                        "items": null,
                        "child_properties": [
                            {
                                "name": "prompt_tokens_string",
                                "type_property": "string",
                                "label_property": null,
                                "full_path": "CD_CLASSIFICATION_metadata.prompt_tokens_string",
                                "format_property": null,
                                "enum": null,
                                "required": true,
                                "default_value": "",
                                "actual_value": null,
                                "title": "Prompt Tokens",
                                "description": "Prompt Tokens",
                                "items": null,
                                "child_properties": null
                            },
                            {
                                "name": "completion_tokens_string",
                                "type_property": "string",
                                "label_property": null,
                                "full_path": "CD_CLASSIFICATION_metadata.completion_tokens_string",
                                "format_property": null,
                                "enum": null,
                                "required": true,
                                "default_value": "",
                                "actual_value": null,
                                "title": "Completion Tokens",
                                "description": "Completion Tokens",
                                "items": null,
                                "child_properties": null
                            },
                            {
                                "name": "total_tokens_string",
                                "type_property": "string",
                                "label_property": null,
                                "full_path": "CD_CLASSIFICATION_metadata.total_tokens_string",
                                "format_property": null,
                                "enum": null,
                                "required": true,
                                "default_value": "",
                                "actual_value": null,
                                "title": "Total Tokens",
                                "description": "Total Tokens",
                                "items": null,
                                "child_properties": null
                            }
                        ]
                    }
                ]
            }
        },
        "partial_outputs": []
    }'

INSERT INTO [genai].[ComponentConfigurations] 
(
	[Id]
	, [StatusEntityModel]
	, [Code]
	, [Description]
	, [Title]
	, [TechnicalDescription]
	, [KafkaTopic]
	, [CreatorUserId]
	, [CreationTime]
) VALUES (
	@ComponentConfigurationId
	, @StatusEntityModel
	, @Code
	, @Description
	, @Title
	, @TechnicalDescription
	, @KafkaTopic
	, @CreatorUserId
	, @CreationTime
)

INSERT INTO [genai].[ComponentDetailConfigurations]
(
	[Id]
	,[ComponentConfigurationId]
    ,[Input]
    ,[Output]
    ,[CreatorUserId]
    ,[CreationTime]
) VALUES (
	NEWID()
	, @ComponentConfigurationId
	, @InputCollection
	, @OutputCollection
	, @CreatorUserId
	, @CreationTime
)

SELECT * 
FROM [genai].[ComponentConfigurations] CC WITH(NOLOCK)
LEFT JOIN [genai].[ComponentDetailConfigurations] CDC WITH(NOLOCK) ON CDC.ComponentConfigurationId = CC.Id
WHERE CC.Id = @ComponentConfigurationId

COMMIT
