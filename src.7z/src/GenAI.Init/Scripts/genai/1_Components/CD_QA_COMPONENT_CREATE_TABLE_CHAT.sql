drop table if exists genai.ChatInteractions;
drop table if exists genai.Chats;

CREATE TABLE genai.Chats (
	Id uniqueidentifier NOT NULL,
	TenantId uniqueidentifier NOT NULL,
	UserId bigint null,
	Title VARCHAR(255) NULL,
	UserEmailAddress VARCHAR(255),
	CreatedDate datetime2 DEFAULT CURRENT_TIMESTAMP,
	UpdatedDate datetime2 null,
	Status VARCHAR(255) NULL,
	Feedback int null,
	FeedbackDate datetime2 null,
	ConnectionId varchar(255) null,
	CodeWorkflow varchar(255) null,
	PRIMARY KEY(Id)
);

CREATE TABLE genai.ChatInteractions (
    Id uniqueidentifier,
	ChatId uniqueidentifier,
    Question VARCHAR(MAX) NOT NULL,
    QuestionDate DATETIME2,
    Answer VARCHAR(MAX),
    AnswerDate DATETIME2,
    Feedback INT DEFAULT 5,
    FeedbackDate DATETIME2,
    WorkflowId uniqueidentifier,
	primary key (Id),
	foreign key (ChatId) references genai.Chats(Id)
);
