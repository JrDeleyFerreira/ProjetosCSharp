/*
SCRIPT PARA CARGA DE TODOS OS COMPONENTES
*/

/*
SCRIPT PARA CRIA��O COMPONENTE DE OCR
*/
BEGIN TRAN

DECLARE
	@ComponentConfigurationId uniqueidentifier = newid()
	, @StatusEntityModel nvarchar(20) = 'ACTIVE'
	, @Code nvarchar(50)
	, @Description nvarchar(max)
	, @Title nvarchar(100)
	, @TechnicalDescription nvarchar(max)
	, @KafkaTopic nvarchar(100)
	, @CreatorUserId bigint = 1
	, @CreationTime datetime2(7) = GETDATE()
	, @InputCollection nvarchar(max)
	, @OutputCollection nvarchar(max)

/*
SCRIPT PARA CRIA��O DO COMPONENTE DE QA
*/
BEGIN TRAN

SELECT 
	@ComponentConfigurationId = '1EA8C7F0-D9A3-49B5-93F1-40BD335EF8CE' --newid()
	, @StatusEntityModel = 'ACTIVE'
	, @Code = 'CD_OCR'
	, @Description = 'Componente respons�vel por realizar a Opera��o de Reconhecimento �ptico de Caracteres (OCR) utilizando o Form Recognizer do Azure.'
	, @Title = 'Ocr Component'
	, @TechnicalDescription = 'O OCRComponent executa o processo de OCR por meio do Form Recognizer do Azure. Para sua opera��o, ele requer os par�metros de entrada {CD_OCR_blob_container_name_string} e {CD_OCR_blob_file_name_string}, que representam, respectivamente, o nome do container de blob e o nome do arquivo no Azure Blob Storage. Esses par�metros s�o essenciais para localizar e processar o arquivo correto durante a tarefa de OCR.'
	, @KafkaTopic = 'genai-ocr-input'
	, @CreatorUserId = 1
	, @CreationTime = GETDATE()
	, @InputCollection = '{
        "input": {
            "json_schema": {
                "$schema": "http://json-schema.org/draft-07/schema#",
                "type": "object",
                "properties": {
                    "CD_OCR_blob_container_name_string": {
                        "type": "string",
                        "default": "{{CD_OCR_blob_container_name}}",
                        "description": "Nome do cont�iner blob",
                        "title": "Nome do cont�iner blob"
                    },
                    "CD_OCR_blob_file_name_string": {
                        "type": "string",
                        "default": "{{CD_OCR_blob_file_name}}",
                        "description": "Nome do arquivo blob",
                        "title": "Nome do arquivo blob"
                    }
                },
                "required": [
                    "CD_OCR_blob_container_name_string",
                    "CD_OCR_blob_file_name_string"
                ]
            },
            "json_schema_sample": {
                "CD_OCR_blob_container_name_string": "squad5",
                "CD_OCR_blob_file_name_string": "file.pdf"
            },
            "default_configuration": null,
            "property_configuration": {
                "properties": [
                    {
                        "name": "CD_OCR_blob_container_name_string",
                        "type_property": "string",
                        "label_property": null,
                        "full_path": "CD_OCR_blob_container_name_string",
                        "format_property": null,
                        "enum": null,
                        "required": true,
                        "default_value": "{{CD_OCR_blob_container_name}}",
                        "actual_value": null,
                        "title": "Nome do cont�iner blob",
                        "description": "Nome do cont�iner blob",
                        "items": null,
                        "child_properties": null
                    },
                    {
                        "name": "CD_OCR_blob_file_name_string",
                        "type_property": "string",
                        "label_property": null,
                        "full_path": "CD_OCR_blob_file_name_string",
                        "format_property": null,
                        "enum": null,
                        "required": true,
                        "default_value": "{{CD_OCR_blob_file_name}}",
                        "actual_value": null,
                        "title": "Nome do arquivo blob",
                        "description": "Nome do arquivo blob",
                        "items": null,
                        "child_properties": null
                    }
                ]
            }
        }
    }'
	, @OutputCollection = '{
        "output": {
            "json_schema": {
                "$schema": "http://json-schema.org/draft-07/schema#",
                "type": "object",
                "properties": {
                    "CD_OCR_output_text_string": {
                        "type": "string",
                        "default": "",
                        "title": "Output Text",
                        "description": "Texto de sa�da"
                    },
                    "CD_OCR_output_confidence_number": {
                        "type": "number",
                        "default": 1,
                        "title": "Valor de confian�a",
                        "description": "Valor de confianca do arquivo"
                    }
                },
                "required": [
                    "CD_OCR_output_text_string",
                    "CD_OCR_output_confidence_number"
                ]
            },
            "json_schema_sample": {
                "CD_OCR_output_text_string": "Texto de sa�da ap�s o processamento do componente.",
                "CD_OCR_output_confidence_number": 1
            },
            "default_configuration": null,
            "property_configuration": {
                "properties": [
                    {
                        "name": "CD_OCR_output_text_string",
                        "type_property": "string",
                        "label_property": null,
                        "full_path": "CD_OCR_output_text_string",
                        "format_property": null,
                        "enum": null,
                        "required": true,
                        "default_value": "",
                        "actual_value": null,
                        "title": "Output Text",
                        "description": "Texto de sa�da",
                        "items": null,
                        "child_properties": null
                    },
                    {
                        "name": "CD_OCR_output_confidence_number",
                        "type_property": "number",
                        "label_property": null,
                        "full_path": "CD_OCR_output_confidence_number",
                        "format_property": null,
                        "enum": null,
                        "required": true,
                        "default_value": 1,
                        "actual_value": null,
                        "title": "Valor de confian�a",
                        "description": "Valor de confianca do arquivo",
                        "items": null,
                        "child_properties": null
                    }
                ]
            }
        },
        "partial_outputs": []
    }'

INSERT INTO [genai].[ComponentConfigurations] 
(
	[Id]
	, [StatusEntityModel]
	, [Code]
	, [Description]
	, [Title]
	, [TechnicalDescription]
	, [KafkaTopic]
	, [CreatorUserId]
	, [CreationTime]
) VALUES (
	@ComponentConfigurationId
	, @StatusEntityModel
	, @Code
	, @Description
	, @Title
	, @TechnicalDescription
	, @KafkaTopic
	, @CreatorUserId
	, @CreationTime
)

INSERT INTO [genai].[ComponentDetailConfigurations]
(
	[Id]
	,[ComponentConfigurationId]
    ,[Input]
    ,[Output]
    ,[CreatorUserId]
    ,[CreationTime]
) VALUES (
	NEWID()
	, @ComponentConfigurationId
	, @InputCollection
	, @OutputCollection
	, @CreatorUserId
	, @CreationTime
)

SELECT * 
FROM [genai].[ComponentConfigurations] CC WITH(NOLOCK)
LEFT JOIN [genai].[ComponentDetailConfigurations] CDC WITH(NOLOCK) ON CDC.ComponentConfigurationId = CC.Id
WHERE CC.Id = @ComponentConfigurationId

COMMIT
