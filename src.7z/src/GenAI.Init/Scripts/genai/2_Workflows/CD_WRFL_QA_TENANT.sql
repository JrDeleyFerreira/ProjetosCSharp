/*
Scripts de carga das configura��es de workflow
*/

DECLARE 
	@WorkflowConfigurationId uniqueidentifier
	, @StatusEntityModel nvarchar(20)
	, @Code nvarchar(50)
	, @Description nvarchar(max)
	, @Title nvarchar(100)
	, @TenantId uniqueidentifier
	, @ExecutionCount bigint
	, @KafkaTopicCallback nvarchar(100)
	, @CreatorUserId bigint
	, @CreationTime datetime2(7)
	, @InputCollection nvarchar(max)

DECLARE
	@WSCId0 uniqueidentifier
	, @WSCCode0 nvarchar(50)
	, @WSCDescription0 nvarchar(max)
	, @WSCTitle0 nvarchar(100)
	, @WSCOrder0 bigint
	, @WSCComponentConfigurationId0 uniqueidentifier
	, @WSCParentId0 uniqueidentifier
	, @WSCInputCollection0 nvarchar(max)
	, @WSCOutputCollection0 nvarchar(max)
	, @WSCMapping0 nvarchar(max) = null


/*
SCRIPT PARA CRIA��O DE WORKFLOW CD_WRFL_QA
*/
BEGIN TRAN

/* Vari�veis do WorkflowConfiguration */
SELECT 
	@WorkflowConfigurationId = '9a134d3f-d397-438b-83bb-1d941cea59a1' --NEWID()
	, @StatusEntityModel = 'ACTIVE'
	, @Code = 'CD_WRFL_QA_TENANT'
	, @Description = 'Workflow QA Squad5'
	, @Title = 'Workflow QA Squad5'
	, @TenantId = '9858F1B3-0F37-41E2-A3E3-92C64CD2BF59'
	, @ExecutionCount = 0
	, @KafkaTopicCallback = null
	, @CreatorUserId = 1
	, @CreationTime = GETDATE()
	, @InputCollection = '{
        "properties": [
            {
                "workflow_step_id": "33f15220-f346-4e0e-8e1d-2d1052a9992c",
                "workflow_step_order": 0,
                "workflow_step_property": {
                    "properties": [
                        {
                            "name": "CD_QA_TENANT_tenant_id_string",
                            "type_property": "string",
                            "label_property": null,
                            "full_path": "CD_QA_TENANT_tenant_id_string",
                            "format_property": null,
                            "enum": null,
                            "required": true,
                            "default_value": "{{CD_QA_TENANT_tenant_id_string}}",
                            "actual_value": null,
                            "title": null,
                            "description": "ID do Tenant.",
                            "items": null,
                            "child_properties": null
                        },
                        {
                            "name": "CD_QA_TENANT_connection_id_string",
                            "type_property": "string",
                            "label_property": null,
                            "full_path": "CD_QA_TENANT_connection_id_string",
                            "format_property": null,
                            "enum": null,
                            "required": true,
                            "default_value": "{{CD_QA_TENANT_connection_id_string}}",
                            "actual_value": null,
                            "title": null,
                            "description": "ID da connection para o SignalR.",
                            "items": null,
                            "child_properties": null
                        },
                        {
                            "name": "CD_QA_TENANT_context_id_string",
                            "type_property": "string",
                            "label_property": null,
                            "full_path": "CD_QA_TENANT_context_id_string",
                            "format_property": null,
                            "enum": null,
                            "required": true,
                            "default_value": "{{CD_QA_TENANT_context_id_string}}",
                            "actual_value": null,
                            "title": "ID do Contexto",
                            "description": "ID do contexto do QA",
                            "items": null,
                            "child_properties": null
                        }
                    ]
                }
            }
        ]
    }'
	
/* Vari�veis do WorkflowStepConfiguration */
SELECT
	/* Vari�veis step 0 */
	@WSCId0 = '16434b9f-b973-4212-b18c-4533a5aa091a' --newid()
	, @WSCCode0 = 'CD_ST_0_QA_TENANT'
	, @WSCDescription0 = 'Etapa de QA Tenant'
	, @WSCTitle0 = 'Etapa QA Tenant'
	, @WSCOrder0 = 0
	, @WSCComponentConfigurationId0 = (SELECT [Id] FROM [genai].[ComponentConfigurations] CC WHERE CC.Code = 'CD_QA_TENANT') -- '9c3a6495-b6ab-4b01-8e97-0c44c8bb1065'
	, @WSCParentId0 = (SELECT [Id] FROM [genai].[WorkflowStepConfigurations] WSC WHERE WSC.Code = '')
	, @WSCInputCollection0 = '{
        "input": {
            "json_schema": {
                "$schema": "http://json-schema.org/draft-07/schema#",
                "type": "object",
                "description": "QA Tenant Component Configuration Schema. Ele � respons�vel por armazenar as configura��es do componente de QA Tenant. ",
                "title": "QA Component Configuration Schema",
                "properties": {
                    "CD_QA_TENANT_open_ai_api_base_string": {
                        "type": "string",
                        "default": "{{CD_QA_TENANT_open_ai_url}}",
                        "description": "Open AI API Base (Base da API da Open AI)",
                        "title": "Open AI API Base"
                    },
                    "CD_QA_TENANT_open_ai_api_version_string": {
                        "type": "string",
                        "default": "{{CD_QA_TENANT_open_ai_api_version_string}}",
                        "description": "Vers�o da API da Open AI",
                        "title": "Vers�o da API da Open AI"
                    },
                    "CD_QA_TENANT_open_ai_api_type_string": {
                        "type": "string",
                        "default": "{{CD_QA_TENANT_open_ai_api_type_string}}",
                        "description": "Tipo da API da Open AI",
                        "title": "Tipo da API da Open AI"
                    },
                    "CD_QA_TENANT_open_ai_api_key_kv_string": {
                        "type": "string",
                        "default": "{{CD_QA_TENANT_open_ai_api_key_kv_string}}",
                        "description": "Chave da API da Open AI [Key Vault]",
                        "title": "Chave da API da Open AI [Key Vault]"
                    },
                    "CD_QA_TENANT_tenant_id_string": {
                        "type": "string",
                        "description": "ID do Tenant.",
                        "default": "{{CD_QA_TENANT_tenant_id_string}}"
                    },
                    "CD_QA_TENANT_connection_id_string": {
                        "type": "string",
                        "description": "ID da connection para o SignalR.",
                        "default": "{{CD_QA_TENANT_connection_id_string}}"
                    },
                    "CD_QA_TENANT_context_id_string": {
                        "type": "string",
                        "default": "{{CD_QA_TENANT_context_id_string}}",
                        "description": "ID do contexto do QA",
                        "title": "ID do Contexto"
                    },
                    "CD_QA_TENANT_search_index_string": {
                        "type": "string",
                        "default": "{{CD_QA_TENANT_search_index_string}}",
                        "description": "�ndice de busca para QA",
                        "title": "�ndice de Busca"
                    },
                    "CD_QA_TENANT_search_index_array": {
                        "type": "array",
                        "items": {
                            "type": "string"
                        },
                        "default": [],
                        "description": "Array de �ndices de busca para QA",
                        "title": "�ndices de Busca"
                    },
                    "CD_QA_TENANT_system_prompt_chat_title_string": {
                        "type": "string",
                        "default": "You are a conversation title generator, and you will only perform this task.",
                        "description": "System Prompt para o t�tulo do chat do QA",
                        "title": "Prompt para o t�tulo do chat do QA"
                    },
                    "CD_QA_TENANT_prompt_chat_title_string": {
                        "type": "string",
                        "default": "Your task is to generate a conversation title based on a text.\nThis title should have up to 15 words and should not contain names, company names, personal data such as CPF, identity number, passport, or company names.\nThe title must always be written in Portuguese. Below is the text that will be used as a reference:\nTEXT: ```{0}```",
                        "description": "Prompt para o t�tulo do chat do QA. Ele utiliza um prompt template que deve conter a tag {0} no texto do prompt",
                        "title": "Prompt para QA"
                    },
                    "CD_QA_TENANT_prompt_string": {
                        "type": "string",
                        "default": "{{CD_QA_TENANT_prompt_string}}",
                        "description": "Prompt para QA. Ele utiliza um prompt template que deve conter as tags {summaries} e {question} no texto do prompt",
                        "title": "Prompt para QA"
                    },
                    "CD_QA_TENANT_condense_question_prompt_string": {
                        "type": "string",
                        "default": "Dado o seguinte di�logo e uma pergunta de acompanhamento, reformule a pergunta de acompanhamento para que seja uma pergunta independente.\n\nHist�rico do Chat:\n{chat_history}\nEntrada de acompanhamento: {question}\npergunta independente:",
                        "description": "Prompt de quest�o condensada para QA. Ele utiliza um prompt template que deve conter as tags {chat_history} e {question} no texto do prompt",
                        "title": "Prompt de Quest�o Condensada"
                    },
                    "CD_QA_TENANT_history_limit_integer": {
                        "type": "integer",
                        "default": "{{CD_QA_TENANT_history_limit_integer}}",
                        "description": "Limite de hist�rico para QA",
                        "title": "Limite de Hist�rico"
                    },
                    "CD_QA_TENANT_blob_container_name_string": {
                        "type": "string",
                        "default": "{{CD_QA_TENANT_blob_container_name_string}}",
                        "description": "Nome do container de blob para QA",
                        "title": "Nome do Container de Blob"
                    },
                    "CD_QA_TENANT_cosmos_database_name_string": {
                        "type": "string",
                        "default": "{{CD_QA_TENANT_comos_database_name}}",
                        "description": "Nome do banco de dados Cosmos para QA",
                        "title": "Nome do Banco de Dados Cosmos"
                    },
                    "CD_QA_TENANT_cosmos_container_name_string": {
                        "type": "string",
                        "default": "{{CD_QA_TENANT_comos_container_name}}",
                        "description": "Nome do container Cosmos para QA",
                        "title": "Nome do Container Cosmos"
                    },
                    "CD_QA_TENANT_open_ai_chat_completion_body_object": {
                        "type": "object",
                        "properties": {
                            "CD_QA_TENANT_engine_string": {
                                "type": "string",
                                "enum": [
                                    "gpt-35-turbo-16k",
                                    "gpt-4-32k"
                                ],
                                "default": "gpt-35-turbo-16k",
                                "description": "Motor (engine) da Open AI para QA",
                                "title": "Motor da Open AI"
                            },
                            "CD_QA_TENANT_messages_array": {
                                "type": "array",
                                "items": {
                                    "type": "string"
                                },
                                "default": [],
                                "description": "Array de mensagens para conversa��o em QA",
                                "title": "Mensagens para Conversa��o"
                            },
                            "CD_QA_TENANT_temperature_number": {
                                "type": "number",
                                "default": 0.5,
                                "description": "Temperatura para gera��o de texto em QA",
                                "title": "Temperatura para Gera��o de Texto"
                            },
                            "CD_QA_TENANT_max_tokens_number": {
                                "type": "number",
                                "default": 2000,
                                "description": "M�ximo de tokens para gera��o de texto em QA",
                                "title": "M�ximo de Tokens"
                            },
                            "CD_QA_TENANT_top_p_number": {
                                "type": "number",
                                "default": 0.95,
                                "description": "Par�metro de amostragem top-p para QA",
                                "title": "Par�metro de Amostragem Top-p"
                            },
                            "CD_QA_TENANT_frequency_penalty_number": {
                                "type": "number",
                                "default": 0,
                                "description": "Penalidade de frequ�ncia em QA",
                                "title": "Penalidade de Frequ�ncia"
                            },
                            "CD_QA_TENANT_presence_penalty_number": {
                                "type": "number",
                                "default": 0,
                                "description": "Penalidade de presen�a em QA",
                                "title": "Penalidade de Presen�a"
                            }
                        },
                        "required": [
                            "CD_QA_TENANT_engine_string",
                            "CD_QA_TENANT_temperature_number",
                            "CD_QA_TENANT_max_tokens_number",
                            "CD_QA_TENANT_top_p_number",
                            "CD_QA_TENANT_frequency_penalty_number",
                            "CD_QA_TENANT_presence_penalty_number"
                        ],
                        "description": "Corpo da requisi��o para conversa��o da API da Open AI em QA",
                        "title": "Requisi��o de Conversa��o da Open AI"
                    }
                },
                "required": [
                    "CD_QA_TENANT_open_ai_api_base_string",
                    "CD_QA_TENANT_open_ai_api_version_string",
                    "CD_QA_TENANT_open_ai_api_type_string",
                    "CD_QA_TENANT_open_ai_api_key_kv_string",
                    "CD_QA_TENANT_tenant_id_string",
                    "CD_QA_TENANT_connection_id_string",
                    "CD_QA_TENANT_context_id_string",
                    "CD_QA_TENANT_search_index_string",
                    "CD_QA_TENANT_system_prompt_chat_title_string",
                    "CD_QA_TENANT_prompt_chat_title_string",
                    "CD_QA_TENANT_prompt_string",
                    "CD_QA_TENANT_condense_question_prompt_string",
                    "CD_QA_TENANT_search_index_array",
                    "CD_QA_TENANT_history_limit_integer",
                    "CD_QA_TENANT_blob_container_name_string",
                    "CD_QA_TENANT_cosmos_database_name_string",
                    "CD_QA_TENANT_cosmos_container_name_string",
                    "CD_QA_TENANT_open_ai_chat_completion_body_object"
                ]
            },
            "json_schema_sample": {
                "CD_QA_TENANT_open_ai_api_base_string": "https://api.openai.com",
                "CD_QA_TENANT_open_ai_api_version_string": "v1",
                "CD_QA_TENANT_open_ai_api_type_string": "text",
                "CD_QA_TENANT_open_ai_api_key_kv_string": "YOUR_OPEN_AI_API_KEY",
                "CD_QA_TENANT_tenant_id_string": "doc12345",
                "CD_QA_TENANT_connection_id_string": "doc12345",
                "CD_QA_TENANT_context_id_string": "context12345",
                "CD_QA_TENANT_search_index_string": "index123",
                "CD_QA_TENANT_system_prompt_chat_title_string": "You are a conversation title generator, and you will only perform this task.",
                "CD_QA_TENANT_prompt_chat_title_string": "Your task is to generate a conversation title based on a text.\nThis title should have up to 15 words and should not contain names, company names, personal data such as CPF, identity number, passport, or company names.\nThe title must always be written in Portuguese. Below is the text that will be used as a reference:\n\nTEXT: ```{0}```",
                "CD_QA_TENANT_prompt_string": "O que � o JSON schema?",
                "CD_QA_TENANT_condense_question_prompt_string": "Descri��o do JSON schema",
                "CD_QA_TENANT_search_index_array": [
                    "indexA",
                    "indexB"
                ],
                "CD_QA_TENANT_history_limit_integer": 10,
                "CD_QA_TENANT_blob_container_name_string": "blob-container-qa",
                "CD_QA_TENANT_cosmos_database_name_string": "cosmos-db-qa",
                "CD_QA_TENANT_cosmos_container_name_string": "cosmos-container-qa",
                "CD_QA_TENANT_open_ai_chat_completion_body_object": {
                    "CD_QA_TENANT_engine_string": "gpt-35-turbo-16k",
                    "CD_QA_TENANT_messages_array": [
                        "Ol�, como posso ajudar?",
                        "O que � o JSON schema?"
                    ],
                    "CD_QA_TENANT_temperature_number": 0.7,
                    "CD_QA_TENANT_max_tokens_number": 1500,
                    "CD_QA_TENANT_top_p_number": 0.9,
                    "CD_QA_TENANT_frequency_penalty_number": 0.1,
                    "CD_QA_TENANT_presence_penalty_number": 0.05
                }
            },
            "default_configuration": null,
            "property_configuration": {
                "properties": [
                    {
                        "name": "CD_QA_TENANT_open_ai_api_base_string",
                        "type_property": "string",
                        "label_property": null,
                        "full_path": "CD_QA_TENANT_open_ai_api_base_string",
                        "format_property": null,
                        "enum": null,
                        "required": true,
                        "default_value": "https://genaiavanade4.openai.azure.com/",
                        "actual_value": null,
                        "title": "Open AI API Base",
                        "description": "Open AI API Base (Base da API da Open AI)",
                        "items": null,
                        "child_properties": null
                    },
                    {
                        "name": "CD_QA_TENANT_open_ai_api_version_string",
                        "type_property": "string",
                        "label_property": null,
                        "full_path": "CD_QA_TENANT_open_ai_api_version_string",
                        "format_property": null,
                        "enum": null,
                        "required": true,
                        "default_value": "2023-07-01-preview",
                        "actual_value": null,
                        "title": "Vers�o da API da Open AI",
                        "description": "Vers�o da API da Open AI",
                        "items": null,
                        "child_properties": null
                    },
                    {
                        "name": "CD_QA_TENANT_open_ai_api_type_string",
                        "type_property": "string",
                        "label_property": null,
                        "full_path": "CD_QA_TENANT_open_ai_api_type_string",
                        "format_property": null,
                        "enum": null,
                        "required": true,
                        "default_value": "azure",
                        "actual_value": null,
                        "title": "Tipo da API da Open AI",
                        "description": "Tipo da API da Open AI",
                        "items": null,
                        "child_properties": null
                    },
                    {
                        "name": "CD_QA_TENANT_open_ai_api_key_kv_string",
                        "type_property": "string",
                        "label_property": null,
                        "full_path": "CD_QA_TENANT_open_ai_api_key_kv_string",
                        "format_property": null,
                        "enum": null,
                        "required": true,
                        "default_value": "OPENAI-API-KEY4",
                        "actual_value": null,
                        "title": "Chave da API da Open AI [Key Vault]",
                        "description": "Chave da API da Open AI [Key Vault]",
                        "items": null,
                        "child_properties": null
                    },
                    {
                        "name": "CD_QA_TENANT_tenant_id_string",
                        "type_property": "string",
                        "label_property": null,
                        "full_path": "CD_QA_TENANT_tenant_id_string",
                        "format_property": null,
                        "enum": null,
                        "required": true,
                        "default_value": "{{CD_QA_TENANT_tenant_id_string}}",
                        "actual_value": null,
                        "title": null,
                        "description": "ID do Tenant.",
                        "items": null,
                        "child_properties": null
                    },
                    {
                        "name": "CD_QA_TENANT_connection_id_string",
                        "type_property": "string",
                        "label_property": null,
                        "full_path": "CD_QA_TENANT_connection_id_string",
                        "format_property": null,
                        "enum": null,
                        "required": true,
                        "default_value": "{{CD_QA_TENANT_connection_id_string}}",
                        "actual_value": null,
                        "title": null,
                        "description": "ID da connection para o SignalR.",
                        "items": null,
                        "child_properties": null
                    },
                    {
                        "name": "CD_QA_TENANT_context_id_string",
                        "type_property": "string",
                        "label_property": null,
                        "full_path": "CD_QA_TENANT_context_id_string",
                        "format_property": null,
                        "enum": null,
                        "required": true,
                        "default_value": "{{CD_QA_TENANT_context_id_string}}",
                        "actual_value": null,
                        "title": "ID do Contexto",
                        "description": "ID do contexto do QA",
                        "items": null,
                        "child_properties": null
                    },
                    {
                        "name": "CD_QA_TENANT_search_index_string",
                        "type_property": "string",
                        "label_property": null,
                        "full_path": "CD_QA_TENANT_search_index_string",
                        "format_property": null,
                        "enum": null,
                        "required": true,
                        "default_value": "idx-documents",
                        "actual_value": null,
                        "title": "�ndice de Busca",
                        "description": "�ndice de busca para QA",
                        "items": null,
                        "child_properties": null
                    },
                    {
                        "name": "CD_QA_TENANT_search_index_array",
                        "type_property": "array",
                        "label_property": null,
                        "full_path": "CD_QA_TENANT_search_index_array",
                        "format_property": null,
                        "enum": null,
                        "required": true,
                        "default_value": [
                            "idx-documents"
                        ],
                        "actual_value": null,
                        "title": "�ndices de Busca",
                        "description": "Array de �ndices de busca para QA",
                        "items": {
                            "type_item": "string",
                            "properties": null
                        },
                        "child_properties": []
                    },
                    {
                        "name": "CD_QA_TENANT_system_prompt_chat_title_string",
                        "type_property": "string",
                        "label_property": null,
                        "full_path": "CD_QA_TENANT_system_prompt_chat_title_string",
                        "format_property": null,
                        "enum": null,
                        "required": true,
                        "default_value": "You are a conversation title generator, and you will only perform this task.",
                        "actual_value": null,
                        "title": "Prompt para o t�tulo do chat do QA",
                        "description": "System Prompt para o t�tulo do chat do QA",
                        "items": null,
                        "child_properties": null
                    },
                    {
                        "name": "CD_QA_TENANT_prompt_chat_title_string",
                        "type_property": "string",
                        "label_property": null,
                        "full_path": "CD_QA_TENANT_prompt_chat_title_string",
                        "format_property": null,
                        "enum": null,
                        "required": true,
                        "default_value": "Your task is to generate a conversation title based on a text.\nThis title should have up to 15 words and should not contain names, company names, personal data such as CPF, identity number, passport, or company names.\nThe title must always be written in Portuguese. Below is the text that will be used as a reference:\nTEXT: ```{0}```",
                        "actual_value": null,
                        "title": "Prompt para QA",
                        "description": "Prompt para o t�tulo do chat do QA. Ele utiliza um prompt template que deve conter a tag {0} no texto do prompt",
                        "items": null,
                        "child_properties": null
                    },
                    {
                        "name": "CD_QA_TENANT_prompt_string",
                        "type_property": "string",
                        "label_property": null,
                        "full_path": "CD_QA_TENANT_prompt_string",
                        "format_property": null,
                        "enum": null,
                        "required": true,
                        "default_value": "{summaries}\n            Por favor, responda � pergunta usando apenas as informa��es presentes no texto acima.\n            Se voc� n�o conseguir encontrar, responda educadamente que a informa��o n�o est� na base de conhecimento.\n            Detecte o idioma da pergunta e responda no mesmo idioma.\n            Se for pedido uma enumera��o, liste todas elas e n�o invente nenhuma.\n            Cada fonte tem um nome seguido de dois pontos e da informa��o real, sempre inclua o nome da fonte para cada fato que voc� usar na resposta. \n            Use sempre colchetes duplos para fazer refer�ncia ao nome do arquivo fonte, por exemplo, [[info1.pdf.txt]]. \n            N�o combine fontes, liste cada fonte separadamente, por exemplo, [[info1.pdf]][[info2.txt]].\n            Caso a fonte seja um link extrai da mesma o nome do arquivo e coloque no formado informado anteriormente.\n            Caso o nome do arquivo esteja com encode retire os encodes e escreva de forma normal.\n            N�o deixe links na resposta, deixe apenas o nome do arquivo da fonte.\n\n            pergunta: {question}\n\n            resposta:",
                        "actual_value": null,
                        "title": "Prompt para QA",
                        "description": "Prompt para QA. Ele utiliza um prompt template que deve conter as tags {summaries} e {question} no texto do prompt",
                        "items": null,
                        "child_properties": null
                    },
                    {
                        "name": "CD_QA_TENANT_condense_question_prompt_string",
                        "type_property": "string",
                        "label_property": null,
                        "full_path": "CD_QA_TENANT_condense_question_prompt_string",
                        "format_property": null,
                        "enum": null,
                        "required": true,
                        "default_value": "Dado o seguinte di�logo e uma pergunta de acompanhamento, reformule a pergunta de acompanhamento para que seja uma pergunta independente.\n\nHist�rico do Chat:\n{chat_history}\nEntrada de acompanhamento: {question}\npergunta independente:",
                        "actual_value": null,
                        "title": "Prompt de Quest�o Condensada",
                        "description": "Prompt de quest�o condensada para QA. Ele utiliza um prompt template que deve conter as tags {chat_history} e {question} no texto do prompt",
                        "items": null,
                        "child_properties": null
                    },
                    {
                        "name": "CD_QA_TENANT_history_limit_integer",
                        "type_property": "integer",
                        "label_property": null,
                        "full_path": "CD_QA_TENANT_history_limit_integer",
                        "format_property": null,
                        "enum": null,
                        "required": true,
                        "default_value": 5,
                        "actual_value": null,
                        "title": "Limite de Hist�rico",
                        "description": "Limite de hist�rico para QA",
                        "items": null,
                        "child_properties": null
                    },
                    {
                        "name": "CD_QA_TENANT_blob_container_name_string",
                        "type_property": "string",
                        "label_property": null,
                        "full_path": "CD_QA_TENANT_blob_container_name_string",
                        "format_property": null,
                        "enum": null,
                        "required": true,
                        "default_value": "files",
                        "actual_value": null,
                        "title": "Nome do Container de Blob",
                        "description": "Nome do container de blob para QA",
                        "items": null,
                        "child_properties": null
                    },
                    {
                        "name": "CD_QA_TENANT_cosmos_database_name_string",
                        "type_property": "string",
                        "label_property": null,
                        "full_path": "CD_QA_TENANT_cosmos_database_name_string",
                        "format_property": null,
                        "enum": null,
                        "required": true,
                        "default_value": "GenAICrossDBDev",
                        "actual_value": null,
                        "title": "Nome do Banco de Dados Cosmos",
                        "description": "Nome do banco de dados Cosmos para QA",
                        "items": null,
                        "child_properties": null
                    },
                    {
                        "name": "CD_QA_TENANT_cosmos_container_name_string",
                        "type_property": "string",
                        "label_property": null,
                        "full_path": "CD_QA_TENANT_cosmos_container_name_string",
                        "format_property": null,
                        "enum": null,
                        "required": true,
                        "default_value": "Chats",
                        "actual_value": null,
                        "title": "Nome do Container Cosmos",
                        "description": "Nome do container Cosmos para QA",
                        "items": null,
                        "child_properties": null
                    },
                    {
                        "name": "CD_QA_TENANT_open_ai_chat_completion_body_object",
                        "type_property": "object",
                        "label_property": null,
                        "full_path": "CD_QA_TENANT_open_ai_chat_completion_body_object",
                        "format_property": null,
                        "enum": null,
                        "required": true,
                        "default_value": null,
                        "actual_value": null,
                        "title": "Requisi��o de Conversa��o da Open AI",
                        "description": "Corpo da requisi��o para conversa��o da API da Open AI em QA",
                        "items": null,
                        "child_properties": [
                            {
                                "name": "CD_QA_TENANT_engine_string",
                                "type_property": "string",
                                "label_property": null,
                                "full_path": "CD_QA_TENANT_open_ai_chat_completion_body_object.CD_QA_TENANT_engine_string",
                                "format_property": null,
                                "enum": [
                                    "gpt-35-turbo-16k",
                                    "gpt-4-32k"
                                ],
                                "required": true,
                                "default_value": "gpt-4-32k",
                                "actual_value": null,
                                "title": "Motor da Open AI",
                                "description": "Motor (engine) da Open AI para QA",
                                "items": null,
                                "child_properties": null
                            },
                            {
                                "name": "CD_QA_TENANT_messages_array",
                                "type_property": "array",
                                "label_property": null,
                                "full_path": "CD_QA_TENANT_open_ai_chat_completion_body_object.CD_QA_TENANT_messages_array",
                                "format_property": null,
                                "enum": null,
                                "required": false,
                                "default_value": [],
                                "actual_value": null,
                                "title": "Mensagens para Conversa��o",
                                "description": "Array de mensagens para conversa��o em QA",
                                "items": {
                                    "type_item": "string",
                                    "properties": null
                                },
                                "child_properties": []
                            },
                            {
                                "name": "CD_QA_TENANT_temperature_number",
                                "type_property": "number",
                                "label_property": null,
                                "full_path": "CD_QA_TENANT_open_ai_chat_completion_body_object.CD_QA_TENANT_temperature_number",
                                "format_property": null,
                                "enum": null,
                                "required": true,
                                "default_value": 0.5,
                                "actual_value": null,
                                "title": "Temperatura para Gera��o de Texto",
                                "description": "Temperatura para gera��o de texto em QA",
                                "items": null,
                                "child_properties": null
                            },
                            {
                                "name": "CD_QA_TENANT_max_tokens_number",
                                "type_property": "number",
                                "label_property": null,
                                "full_path": "CD_QA_TENANT_open_ai_chat_completion_body_object.CD_QA_TENANT_max_tokens_number",
                                "format_property": null,
                                "enum": null,
                                "required": true,
                                "default_value": 2000,
                                "actual_value": null,
                                "title": "M�ximo de Tokens",
                                "description": "M�ximo de tokens para gera��o de texto em QA",
                                "items": null,
                                "child_properties": null
                            },
                            {
                                "name": "CD_QA_TENANT_top_p_number",
                                "type_property": "number",
                                "label_property": null,
                                "full_path": "CD_QA_TENANT_open_ai_chat_completion_body_object.CD_QA_TENANT_top_p_number",
                                "format_property": null,
                                "enum": null,
                                "required": true,
                                "default_value": 0.95,
                                "actual_value": null,
                                "title": "Par�metro de Amostragem Top-p",
                                "description": "Par�metro de amostragem top-p para QA",
                                "items": null,
                                "child_properties": null
                            },
                            {
                                "name": "CD_QA_TENANT_frequency_penalty_number",
                                "type_property": "number",
                                "label_property": null,
                                "full_path": "CD_QA_TENANT_open_ai_chat_completion_body_object.CD_QA_TENANT_frequency_penalty_number",
                                "format_property": null,
                                "enum": null,
                                "required": true,
                                "default_value": 0,
                                "actual_value": null,
                                "title": "Penalidade de Frequ�ncia",
                                "description": "Penalidade de frequ�ncia em QA",
                                "items": null,
                                "child_properties": null
                            },
                            {
                                "name": "CD_QA_TENANT_presence_penalty_number",
                                "type_property": "number",
                                "label_property": null,
                                "full_path": "CD_QA_TENANT_open_ai_chat_completion_body_object.CD_QA_TENANT_presence_penalty_number",
                                "format_property": null,
                                "enum": null,
                                "required": true,
                                "default_value": 0,
                                "actual_value": null,
                                "title": "Penalidade de Presen�a",
                                "description": "Penalidade de presen�a em QA",
                                "items": null,
                                "child_properties": null
                            }
                        ]
                    }
                ]
            }
        }
    }'
	, @WSCOutputCollection0 = '{
        "output": {
            "json_schema": {
                "$schema": "http://json-schema.org/draft-07/schema#",
                "type": "object",
                "properties": {
                    "CD_QA_TENANT_output_text_string": {
                        "type": "string",
                        "title": "Output Text",
                        "description": "Texto de sa�da para CD_QA"
                    },
                    "CD_QA_TENANT_output_connection_id_string": {
                        "type": "string",
                        "title": "Output json data",
                        "description": "ID da connection para o SignalR"
                    },
                    "CD_QA_TENANT_metadata_object": {
                        "type": "object",
                        "title": "Metadata",
                        "description": "Metadados para CD_QA",
                        "properties": {
                            "CD_QA_TENANT_prompt_tokens_integer": {
                                "type": "integer",
                                "default": 0,
                                "title": "Prompt Tokens",
                                "description": "Quantidade de tokens do prompt para CD_QA"
                            },
                            "CD_QA_TENANT_completion_tokens_integer": {
                                "type": "integer",
                                "default": 0,
                                "title": "Completion Tokens",
                                "description": "Quantidade de tokens de conclus�o para CD_QA"
                            },
                            "CD_QA_TENANT_total_tokens_integer": {
                                "type": "integer",
                                "default": 0,
                                "title": "Total Tokens",
                                "description": "Quantidade total de tokens para CD_QA"
                            }
                        },
                        "required": [
                            "CD_QA_TENANT_prompt_tokens_integer",
                            "CD_QA_TENANT_completion_tokens_integer",
                            "CD_QA_TENANT_total_tokens_integer"
                        ]
                    }
                },
                "required": [
                    "CD_QA_TENANT_output_text_string",
                    "CD_QA_TENANT_output_connection_id_string",
                    "CD_QA_TENANT_metadata_object"
                ]
            },
            "json_schema_sample": {
                "CD_QA_TENANT_output_text_string": "Este � um texto de sa�da exemplo.",
                "CD_QA_TENANT_output_connection_id_string": "teste",
                "CD_QA_TENANT_metadata_object": {
                    "CD_QA_TENANT_prompt_tokens_integer": 5,
                    "CD_QA_TENANT_completion_tokens_integer": 10,
                    "CD_QA_TENANT_total_tokens_integer": 15
                }
            },
            "default_configuration": null,
            "property_configuration": {
                "properties": [
                    {
                        "name": "CD_QA_TENANT_output_text_string",
                        "type_property": "string",
                        "label_property": null,
                        "full_path": "CD_QA_TENANT_output_text_string",
                        "format_property": null,
                        "enum": null,
                        "required": true,
                        "default_value": null,
                        "actual_value": null,
                        "title": "Output Text",
                        "description": "Texto de sa�da para CD_QA",
                        "items": null,
                        "child_properties": null
                    },
                    {
                        "name": "CD_QA_TENANT_output_connection_id_string",
                        "type_property": "string",
                        "label_property": null,
                        "full_path": "CD_QA_TENANT_output_connection_id_string",
                        "format_property": null,
                        "enum": null,
                        "required": true,
                        "default_value": null,
                        "actual_value": null,
                        "title": "Output json data",
                        "description": "ID da connection para o SignalR",
                        "items": null,
                        "child_properties": null
                    },
                    {
                        "name": "CD_QA_TENANT_metadata_object",
                        "type_property": "object",
                        "label_property": null,
                        "full_path": "CD_QA_TENANT_metadata_object",
                        "format_property": null,
                        "enum": null,
                        "required": true,
                        "default_value": null,
                        "actual_value": null,
                        "title": "Metadata",
                        "description": "Metadados para CD_QA",
                        "items": null,
                        "child_properties": [
                            {
                                "name": "CD_QA_TENANT_prompt_tokens_integer",
                                "type_property": "integer",
                                "label_property": null,
                                "full_path": "CD_QA_TENANT_metadata_object.CD_QA_TENANT_prompt_tokens_integer",
                                "format_property": null,
                                "enum": null,
                                "required": true,
                                "default_value": 0,
                                "actual_value": null,
                                "title": "Prompt Tokens",
                                "description": "Quantidade de tokens do prompt para CD_QA",
                                "items": null,
                                "child_properties": null
                            },
                            {
                                "name": "CD_QA_TENANT_completion_tokens_integer",
                                "type_property": "integer",
                                "label_property": null,
                                "full_path": "CD_QA_TENANT_metadata_object.CD_QA_TENANT_completion_tokens_integer",
                                "format_property": null,
                                "enum": null,
                                "required": true,
                                "default_value": 0,
                                "actual_value": null,
                                "title": "Completion Tokens",
                                "description": "Quantidade de tokens de conclus�o para CD_QA",
                                "items": null,
                                "child_properties": null
                            },
                            {
                                "name": "CD_QA_TENANT_total_tokens_integer",
                                "type_property": "integer",
                                "label_property": null,
                                "full_path": "CD_QA_TENANT_metadata_object.CD_QA_TENANT_total_tokens_integer",
                                "format_property": null,
                                "enum": null,
                                "required": true,
                                "default_value": 0,
                                "actual_value": null,
                                "title": "Total Tokens",
                                "description": "Quantidade total de tokens para CD_QA",
                                "items": null,
                                "child_properties": null
                            }
                        ]
                    }
                ]
            }
        },
        "partial_outputs": []
    }'
	, @WSCMapping0 = null

INSERT INTO [genai].[WorkflowConfigurations] 
(
	[Id]
	, [StatusEntityModel]
	, [Code]
	, [Description]
	, [Title]
	, [TenantId]
	, [ExecutionCount]
	, [KafkaTopicCallback]
	, [CreatorUserId]
	, [CreationTime]
) VALUES (
	@WorkflowConfigurationId
	, @StatusEntityModel
	, @Code
	, @Description
	, @Title
	, @TenantId
	, @ExecutionCount
	, @KafkaTopicCallback
	, @CreatorUserId
	, @CreationTime
)

INSERT INTO [genai].[WorkflowDetailConfigurations]
(
	[Id]
	, [WorkflowConfigurationId]
    , [Input]
    , [CreatorUserId]
    , [CreationTime]
) VALUES (
	NEWID()
	, @WorkflowConfigurationId
	, @InputCollection
	, @CreatorUserId
	, @CreationTime
)

INSERT INTO [genai].[WorkflowStepConfigurations]
(
	[Id]
	, [StatusEntityModel]
	, [Code]
	, [Description]
	, [Title]
	, [Order]
	, [WorkflowConfigurationId]
	, [ComponentConfigurationId]
	, [WorkflowStepConfigurationParentId]
	, [CreatorUserId]
	, [CreationTime]
) VALUES (
	@WSCId0
	, @StatusEntityModel
	, @WSCCode0
	, @WSCDescription0
	, @WSCTitle0
	, @WSCOrder0
	, @WorkflowConfigurationId
	, @WSCComponentConfigurationId0
	, @WSCParentId0
	, @CreatorUserId
	, @CreationTime
)

INSERT INTO [genai].[WorkflowStepDetailConfigurations]
(
	[Id]
	, [WorkflowStepConfigurationId]
	, [Input]
	, [Output]
	, [Mapping]
	, [CreatorUserId]
	, [CreationTime]
) VALUES (
	NEWID()
	, @WSCId0
	, @WSCInputCollection0
	, @WSCOutputCollection0
	, @WSCMapping0
	, @CreatorUserId
	, @CreationTime
)

SELECT * 
FROM [genai].[WorkflowConfigurations] WC WITH(NOLOCK)
LEFT JOIN [genai].[WorkflowDetailConfigurations] WDC WITH(NOLOCK) ON WDC.WorkflowConfigurationId = WC.Id
LEFT JOIN [genai].[WorkflowStepConfigurations] WSC WITH(NOLOCK) ON WSC.WorkflowConfigurationId = WC.Id
LEFT JOIN [genai].[WorkflowStepDetailConfigurations] WSDC WITH(NOLOCK) ON WSDC.WorkflowStepConfigurationId = WSC.Id
WHERE WC.Id = @WorkflowConfigurationId

COMMIT

