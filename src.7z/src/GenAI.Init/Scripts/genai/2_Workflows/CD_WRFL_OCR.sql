/*
Scripts de carga das configura��es de workflow
*/

DECLARE 
	@WorkflowConfigurationId uniqueidentifier
	, @StatusEntityModel nvarchar(20)
	, @Code nvarchar(50)
	, @Description nvarchar(max)
	, @Title nvarchar(100)
	, @TenantId uniqueidentifier
	, @ExecutionCount bigint
	, @KafkaTopicCallback nvarchar(100)
	, @CreatorUserId bigint
	, @CreationTime datetime2(7)
	, @InputCollection nvarchar(max)

DECLARE
	@WSCId0 uniqueidentifier
	, @WSCCode0 nvarchar(50)
	, @WSCDescription0 nvarchar(max)
	, @WSCTitle0 nvarchar(100)
	, @WSCOrder0 bigint
	, @WSCComponentConfigurationId0 uniqueidentifier
	, @WSCParentId0 uniqueidentifier
	, @WSCInputCollection0 nvarchar(max)
	, @WSCOutputCollection0 nvarchar(max)
	, @WSCMapping0 nvarchar(max) = null


/*
SCRIPT PARA CRIA��O DE WORKFLOW CD_WRFL_INDEXER
*/
BEGIN TRAN

/* Vari�veis do WorkflowConfiguration */
SELECT 
	@WorkflowConfigurationId = '1ECB3687-8F1A-4452-9496-40E47025E79A' --NEWID()
	, @StatusEntityModel = 'ACTIVE'
	, @Code = 'CD_WRFL_OCR'
	, @Description = 'Workflow de OCR'
	, @Title = 'Workflow de OCR'
	, @TenantId = '5846D05B-F0ED-49FF-B645-576812A70892'
	, @ExecutionCount = 0
	, @KafkaTopicCallback = null
	, @CreatorUserId = 1
	, @CreationTime = GETDATE()
	, @InputCollection = '{
        "properties": [
            {
                "workflow_step_id": "4CB04863-8C66-4EF0-9531-6F39A7012A59",
                "workflow_step_order": 0,
                "workflow_step_property": {
                    "properties": [
                        {
                            "name": "CD_OCR_blob_container_name_string",
                            "type_property": "string",
                            "label_property": null,
                            "full_path": "CD_OCR_blob_container_name_string",
                            "format_property": null,
                            "enum": null,
                            "required": true,
                            "default_value": "{{CD_OCR_blob_container_name}}",
                            "actual_value": null,
                            "title": "Nome do cont�iner blob",
                            "description": "Nome do cont�iner blob",
                            "items": null,
                            "child_properties": null
                        },
                        {
                            "name": "CD_OCR_blob_file_name_string",
                            "type_property": "string",
                            "label_property": null,
                            "full_path": "CD_OCR_blob_file_name_string",
                            "format_property": null,
                            "enum": null,
                            "required": true,
                            "default_value": "{{CD_OCR_blob_file_name}}",
                            "actual_value": null,
                            "title": "Nome do arquivo blob",
                            "description": "Nome do arquivo blob",
                            "items": null,
                            "child_properties": null
                        }
                    ]
                }
            }
        ]
    }
'
	
/* Vari�veis do WorkflowStepConfiguration */
SELECT
	/* Vari�veis step 0 */
	@WSCId0 = '4CB04863-8C66-4EF0-9531-6F39A7012A59' --newid()
	, @WSCCode0 = 'CD_ST_0_OCR'
	, @WSCDescription0 = 'Etapa de OCR'
	, @WSCTitle0 = 'Etapa OCR'
	, @WSCOrder0 = 0
	, @WSCComponentConfigurationId0 = (SELECT [Id] FROM [genai].[ComponentConfigurations] CC WHERE CC.Code = 'CD_OCR') -- '9c3a6495-b6ab-4b01-8e97-0c44c8bb1065'
	, @WSCParentId0 = (SELECT [Id] FROM [genai].[WorkflowStepConfigurations] WSC WHERE WSC.Code = '')
	, @WSCInputCollection0 = '{
  "input": {
    "json_schema": {
      "$schema": "http://json-schema.org/draft-07/schema#",
      "type": "object",
      "properties": {
        "CD_OCR_blob_container_name_string": {
          "type": "string",
          "default": "{{CD_OCR_blob_container_name}}",
          "description": "Nome do cont�iner blob",
          "title": "Nome do cont�iner blob"
        },
        "CD_OCR_blob_file_name_string": {
          "type": "string",
          "default": "{{CD_OCR_blob_file_name}}",
          "description": "Nome do arquivo blob",
          "title": "Nome do arquivo blob"
        }
      },
      "required": [
        "CD_OCR_blob_container_name_string",
        "CD_OCR_blob_file_name_string"
      ]
    },
    "json_schema_sample": {
      "CD_OCR_blob_container_name_string": "squad5",
      "CD_OCR_blob_file_name_string": "file.pdf"
    },
    "default_configuration": null,
    "property_configuration": {
      "properties": [
        {
          "name": "CD_OCR_blob_container_name_string",
          "type_property": "string",
          "label_property": null,
          "full_path": "CD_OCR_blob_container_name_string",
          "format_property": null,
          "enum": null,
          "required": true,
          "default_value": "blob",
          "actual_value": null,
          "title": "Nome do cont�iner blob",
          "description": "Nome do cont�iner blob",
          "items": null,
          "child_properties": null
        },
        {
          "name": "CD_OCR_blob_file_name_string",
          "type_property": "string",
          "label_property": null,
          "full_path": "CD_OCR_blob_file_name_string",
          "format_property": null,
          "enum": null,
          "required": true,
          "default_value": "{{CD_OCR_blob_file_name}}",
          "actual_value": null,
          "title": "Nome do arquivo blob",
          "description": "Nome do arquivo blob",
          "items": null,
          "child_properties": null
        }
      ]
    }
  }
}

'
	, @WSCOutputCollection0 = '{
  "Input": null,
  "Output": {
    "json_schema": {
      "$schema": "http://json-schema.org/draft-07/schema#",
      "type": "object",
      "properties": {
        "CD_OCR_output_text_string": {
          "type": "string",
          "default": "",
          "title": "Output Text",
          "description": "Texto de sa�da"
        },
        "CD_OCR_output_confidence_number": {
          "type": "number",
          "default": 1,
          "title": "Valor de confian�a",
          "description": "Valor de confianca do arquivo"
        }
      },
      "required": [
        "CD_OCR_output_text_string",
        "CD_OCR_output_confidence_number"
      ]
    },
    "json_schema_sample": {
      "CD_OCR_output_text_string": "Texto de sa�da ap�s o processamento do componente.",
      "CD_OCR_output_confidence_number": 1
    },
    "default_configuration": null,
    "property_configuration": {
      "Properties": [
        {
          "name": "CD_OCR_output_text_string",
          "type_property": "string",
          "label_property": null,
          "full_path": "CD_OCR_output_text_string",
          "format_property": null,
          "enum": null,
          "required": true,
          "default_value": "",
          "actual_value": null,
          "title": "Output Text",
          "description": "Texto de sa�da",
          "items": null,
          "child_properties": null,
          "ParentFullPath": null
        },
        {
          "name": "CD_OCR_output_confidence_number",
          "type_property": "number",
          "label_property": null,
          "full_path": "CD_OCR_output_confidence_number",
          "format_property": null,
          "enum": null,
          "required": true,
          "default_value": 1,
          "actual_value": null,
          "title": "Valor de confian�a",
          "description": "Valor de confianca do arquivo",
          "items": null,
          "child_properties": null,
          "ParentFullPath": null
        }
      ]
    }
  }
}

'
	, @WSCMapping0 = null

INSERT INTO [genai].[WorkflowConfigurations] 
(
	[Id]
	, [StatusEntityModel]
	, [Code]
	, [Description]
	, [Title]
	, [TenantId]
	, [ExecutionCount]
	, [KafkaTopicCallback]
	, [CreatorUserId]
	, [CreationTime]
	, [Type]
) VALUES (
	@WorkflowConfigurationId
	, @StatusEntityModel
	, @Code
	, @Description
	, @Title
	, @TenantId
	, @ExecutionCount
	, @KafkaTopicCallback
	, @CreatorUserId
	, @CreationTime
	, NULL
)

INSERT INTO [genai].[WorkflowDetailConfigurations]
(
	[Id]
	, [WorkflowConfigurationId]
    , [Input]
    , [CreatorUserId]
    , [CreationTime]
) VALUES (
	NEWID()
	, @WorkflowConfigurationId
	, @InputCollection
	, @CreatorUserId
	, @CreationTime
)

INSERT INTO [genai].[WorkflowStepConfigurations]
(
	[Id]
	, [StatusEntityModel]
	, [Code]
	, [Description]
	, [Title]
	, [Order]
	, [WorkflowConfigurationId]
	, [ComponentConfigurationId]
	, [WorkflowStepConfigurationParentId]
	, [CreatorUserId]
	, [CreationTime]
) VALUES (
	@WSCId0
	, @StatusEntityModel
	, @WSCCode0
	, @WSCDescription0
	, @WSCTitle0
	, @WSCOrder0
	, @WorkflowConfigurationId
	, @WSCComponentConfigurationId0
	, @WSCParentId0
	, @CreatorUserId
	, @CreationTime
)

INSERT INTO [genai].[WorkflowStepDetailConfigurations]
(
	[Id]
	, [WorkflowStepConfigurationId]
	, [Input]
	, [Output]
	, [Mapping]
	, [CreatorUserId]
	, [CreationTime]
) VALUES (
	NEWID()
	, @WSCId0
	, @WSCInputCollection0
	, @WSCOutputCollection0
	, @WSCMapping0
	, @CreatorUserId
	, @CreationTime
)

SELECT * 
FROM [genai].[WorkflowConfigurations] WC WITH(NOLOCK)
LEFT JOIN [genai].[WorkflowDetailConfigurations] WDC WITH(NOLOCK) ON WDC.WorkflowConfigurationId = WC.Id
LEFT JOIN [genai].[WorkflowStepConfigurations] WSC WITH(NOLOCK) ON WSC.WorkflowConfigurationId = WC.Id
LEFT JOIN [genai].[WorkflowStepDetailConfigurations] WSDC WITH(NOLOCK) ON WSDC.WorkflowStepConfigurationId = WSC.Id
WHERE WC.Id = @WorkflowConfigurationId

COMMIT

