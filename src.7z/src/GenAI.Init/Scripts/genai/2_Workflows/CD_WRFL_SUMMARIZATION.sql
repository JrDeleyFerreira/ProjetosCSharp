/*
Scripts de carga das configura��es de workflow
*/

DECLARE 
	@WorkflowConfigurationId uniqueidentifier
	, @StatusEntityModel nvarchar(20)
	, @Code nvarchar(50)
	, @Description nvarchar(max)
	, @Title nvarchar(100)
	, @TenantId uniqueidentifier
	, @ExecutionCount bigint
	, @KafkaTopicCallback nvarchar(100)
	, @CreatorUserId bigint
	, @CreationTime datetime2(7)
	, @InputCollection nvarchar(max)

DECLARE
	@WSCId0 uniqueidentifier
	, @WSCCode0 nvarchar(50)
	, @WSCDescription0 nvarchar(max)
	, @WSCTitle0 nvarchar(100)
	, @WSCOrder0 bigint
	, @WSCComponentConfigurationId0 uniqueidentifier
	, @WSCParentId0 uniqueidentifier
	, @WSCInputCollection0 nvarchar(max)
	, @WSCOutputCollection0 nvarchar(max)
	, @WSCMapping0 nvarchar(max) = null


/*
SCRIPT PARA CRIA��O DE WORKFLOW CD_WRFL_INDEXER
*/
BEGIN TRAN

/* Vari�veis do WorkflowConfiguration */
SELECT 
	@WorkflowConfigurationId = '0648C78B-7203-4DE5-8194-12C36303D87F' --NEWID()
	, @StatusEntityModel = 'ACTIVE'
	, @Code = 'CD_WRFL_SUMMARIZATION'
	, @Description = 'Workflow de Sumariza��o'
	, @Title = 'Workflow de Sumariza��o'
	, @TenantId = '5846D05B-F0ED-49FF-B645-576812A70892'
	, @ExecutionCount = 0
	, @KafkaTopicCallback = null
	, @CreatorUserId = 1
	, @CreationTime = GETDATE()
	, @InputCollection = '{
        "properties": [
            {
                "workflow_step_id": "d51d0a7a-5b2c-4ab1-ba4e-2231c573c402",
                "workflow_step_order": 0,
                "workflow_step_property": {
                    "properties": [
                        {
                            "name": "CD_SUMMARIZATION_input_text_string",
                            "type_property": "string",
                            "label_property": null,
                            "full_path": "CD_SUMMARIZATION_input_text_string",
                            "format_property": null,
                            "enum": null,
                            "required": true,
                            "default_value": "{{CD_SUMMARIZATION_input_text_string}}",
                            "actual_value": null,
                            "title": "Texto a ser sumarizado",
                            "description": "Texto a ser sumarizado",
                            "items": null,
                            "child_properties": null
                        }
                    ]
                }
            }
        ]
    }
'
	
/* Vari�veis do WorkflowStepConfiguration */
SELECT
	/* Vari�veis step 0 */
	@WSCId0 = 'd51d0a7a-5b2c-4ab1-ba4e-2231c573c402' --newid()
	, @WSCCode0 = 'CD_ST_0_SAMPLE_SUMMARIZATION_SUMARIZATION'
	, @WSCDescription0 = 'Etapa de sumariza��o'
	, @WSCTitle0 = 'Etapa der sumariza��o'
	, @WSCOrder0 = 0
	, @WSCComponentConfigurationId0 = (SELECT [Id] FROM [genai].[ComponentConfigurations] CC WHERE CC.Code = 'CD_SUMMARIZATION') -- '9c3a6495-b6ab-4b01-8e97-0c44c8bb1065'
	, @WSCParentId0 = (SELECT [Id] FROM [genai].[WorkflowStepConfigurations] WSC WHERE WSC.Code = '')
	, @WSCInputCollection0 = '{
        "input": {
            "json_schema": {
                "$schema": "http://json-schema.org/draft-07/schema#",
                "type": "object",
                "properties": {
                    "CD_SUMMARIZATION_open_ai_api_base_string": {
                        "type": "string",
                        "default": "{{CD_SUMMARIZATION_open_ai_api_base_string}}",
                        "description": "Open AI URL (URL da Open AI)",
                        "title": "Open AI URL"
                    },
                    "CD_SUMMARIZATION_open_ai_api_version_string": {
                        "type": "string",
                        "default": "{{CD_SUMMARIZATION_open_ai_api_version_string}}",
                        "description": "Open AI API Version",
                        "title": "Open AI API Version"
                    },
                    "CD_SUMMARIZATION_open_ai_api_type_string": {
                        "type": "string",
                        "default": "{{CD_SUMMARIZATION_open_ai_api_type_string}}",
                        "description": "Open AI API Type",
                        "title": "Open AI API Type"
                    },
                    "CD_SUMMARIZATION_open_ai_api_key_string": {
                        "type": "string",
                        "default": "{{CD_SUMMARIZATION_open_ai_api_key_string}}",
                        "description": "Open AI Key (Chave da Open AI)",
                        "title": "Open AI Key"
                    },
                    "CD_SUMMARIZATION_input_text_string": {
                        "type": "string",
                        "default": "{{CD_SUMMARIZATION_input_text_string}}",
                        "description": "Texto a ser sumarizado",
                        "title": "Texto a ser sumarizado"
                    },
                    "CD_SUMMARIZATION_prompt_string": {
                        "type": "string",
                        "default": "{{CD_SUMMARIZATION_prompt_string}}",
                        "description": "prompt base para sumariza��o",
                        "title": "Prompt base para sumariza��o"
                    },
                    "CD_SUMMARIZATION_system_prompt_string": {
                        "type": "string",
                        "default": "{{CD_SUMMARIZATION_system_prompt_string}}",
                        "description": "Texto de prompt do sistema",
                        "title": "Texto de prompt do sistema"
                    },
                    "CD_SUMMARIZATION_open_ai_chat_completion_body_object": {
                        "type": "object",
                        "properties": {
                            "CD_SUMMARIZATION_engine_string": {
                                "type": "string",
                                "enum": [
                                    "gpt-35-turbo-16k"
                                ],
                                "default": "gpt-35-turbo-16k",
                                "description": "Vers�o do modelo da Open AI",
                                "title": "Vers�o do modelo da Open AI"
                            },
                            "CD_SUMMARIZATION_messages_array": {
                                "type": "array",
                                "items": {
                                    "type": "string"
                                },
                                "default": [],
                                "description": "Array de mensagens para conversa��o",
                                "title": "Array de mensagens para conversa��o"
                            },
                            "CD_SUMMARIZATION_temperature_number": {
                                "type": "number",
                                "default": 0.5,
                                "description": "Par�metro de temperatura para gera��o de texto",
                                "title": "Par�metro de temperatura para gera��o de texto"
                            },
                            "CD_SUMMARIZATION_max_tokens_number": {
                                "type": "number",
                                "default": 2000,
                                "description": "N�mero m�ximo de tokens a serem gerados",
                                "title": "N�mero m�ximo de tokens a serem gerados"
                            },
                            "CD_SUMMARIZATION_top_p_number": {
                                "type": "number",
                                "default": 0.95,
                                "description": "Par�metro de top-p sampling",
                                "title": "Par�metro de top-p sampling"
                            },
                            "CD_SUMMARIZATION_frequency_penalty_number": {
                                "type": "number",
                                "default": 0,
                                "description": "Penalidade de frequ�ncia para gera��o de texto",
                                "title": "Penalidade de frequ�ncia para gera��o de texto"
                            },
                            "CD_SUMMARIZATION_presence_penalty_number": {
                                "type": "number",
                                "default": 0,
                                "description": "Penalidade de presen�a para gera��o de texto",
                                "title": "Penalidade de presen�a para gera��o de texto"
                            }
                        },
                        "required": [
                            "CD_SUMMARIZATION_engine_string",
                            "CD_SUMMARIZATION_temperature_number",
                            "CD_SUMMARIZATION_max_tokens_number",
                            "CD_SUMMARIZATION_top_p_number",
                            "CD_SUMMARIZATION_frequency_penalty_number",
                            "CD_SUMMARIZATION_presence_penalty_number"
                        ],
                        "description": "Corpo da requisi��o para a API de gera��o de chat da Open AI",
                        "title": "Corpo da requisi��o para a API de gera��o de chat da Open AI"
                    }
                },
                "required": [
                    "CD_SUMMARIZATION_open_ai_api_base_string",
                    "CD_SUMMARIZATION_open_ai_api_version_string",
                    "CD_SUMMARIZATION_open_ai_api_key_string",
                    "CD_SUMMARIZATION_open_ai_api_type_string",
                    "CD_SUMMARIZATION_input_text_string",
                    "CD_SUMMARIZATION_prompt_string",
                    "CD_SUMMARIZATION_system_prompt_string",
                    "CD_SUMMARIZATION_open_ai_chat_completion_body_object"
                ]
            },
            "json_schema_sample": {
                "CD_SUMMARIZATION_open_ai_api_base_string": "https://api.openai.com/v1/engines/davinci/completions",
                "CD_SUMMARIZATION_open_ai_api_key_string": "OPENAI_API_KEY",
                "CD_SUMMARIZATION_open_ai_api_version_string": "2023-07-01-preview",
                "CD_SUMMARIZATION_open_ai_api_type_string": "azure",
                "CD_SUMMARIZATION_input_text_string": "Texto de sa�da para exemplo de mapping",
                "CD_SUMMARIZATION_prompt_string": "Logo abaixo segue um prompt e um template schema para o mapeamento de dados...",
                "CD_SUMMARIZATION_system_prompt_string": "Quero que voc� resuma o texto a 100 palavras.",
                "CD_SUMMARIZATION_open_ai_chat_completion_body_object": {
                    "CD_SUMMARIZATION_engine_string": "gpt-35-turbo-16k",
                    "CD_SUMMARIZATION_messages_array": [],
                    "CD_SUMMARIZATION_temperature_number": 0.5,
                    "CD_SUMMARIZATION_max_tokens_number": 2000,
                    "CD_SUMMARIZATION_top_p_number": 0.95,
                    "CD_SUMMARIZATION_frequency_penalty_number": 0,
                    "CD_SUMMARIZATION_presence_penalty_number": 0
                }
            },
            "default_configuration": null,
            "property_configuration": {
                "properties": [
                    {
                        "name": "CD_SUMMARIZATION_open_ai_api_base_string",
                        "type_property": "string",
                        "label_property": null,
                        "full_path": "CD_SUMMARIZATION_open_ai_api_base_string",
                        "format_property": null,
                        "enum": null,
                        "required": true,
                        "default_value": "https://oai-genai-pr001.openai.azure.com/",
                        "actual_value": null,
                        "title": "Open AI URL",
                        "description": "Open AI URL (URL da Open AI)",
                        "items": null,
                        "child_properties": null
                    },
                    {
                        "name": "CD_SUMMARIZATION_open_ai_api_version_string",
                        "type_property": "string",
                        "label_property": null,
                        "full_path": "CD_SUMMARIZATION_open_ai_api_version_string",
                        "format_property": null,
                        "enum": null,
                        "required": true,
                        "default_value": "2023-07-01-preview",
                        "actual_value": null,
                        "title": "Open AI API Version",
                        "description": "Open AI API Version",
                        "items": null,
                        "child_properties": null
                    },
                    {
                        "name": "CD_SUMMARIZATION_open_ai_api_type_string",
                        "type_property": "string",
                        "label_property": null,
                        "full_path": "CD_SUMMARIZATION_open_ai_api_type_string",
                        "format_property": null,
                        "enum": null,
                        "required": true,
                        "default_value": "azure",
                        "actual_value": null,
                        "title": "Open AI API Type",
                        "description": "Open AI API Type",
                        "items": null,
                        "child_properties": null
                    },
                    {
                        "name": "CD_SUMMARIZATION_open_ai_api_key_string",
                        "type_property": "string",
                        "label_property": null,
                        "full_path": "CD_SUMMARIZATION_open_ai_api_key_string",
                        "format_property": null,
                        "enum": null,
                        "required": true,
                        "default_value": "OPENAI-API-KEY",
                        "actual_value": null,
                        "title": "Open AI Key",
                        "description": "Open AI Key (Chave da Open AI)",
                        "items": null,
                        "child_properties": null
                    },
                    {
                        "name": "CD_SUMMARIZATION_input_text_string",
                        "type_property": "string",
                        "label_property": null,
                        "full_path": "CD_SUMMARIZATION_input_text_string",
                        "format_property": null,
                        "enum": null,
                        "required": true,
                        "default_value": "{{CD_SUMMARIZATION_input_text_string}}",
                        "actual_value": null,
                        "title": "Texto a ser sumarizado",
                        "description": "Texto a ser sumarizado",
                        "items": null,
                        "child_properties": null
                    },
                    {
                        "name": "CD_SUMMARIZATION_prompt_string",
                        "type_property": "string",
                        "label_property": null,
                        "full_path": "CD_SUMMARIZATION_prompt_string",
                        "format_property": null,
                        "enum": null,
                        "required": true,
                        "default_value": "\n            Your task is to generate a summary of a legal document.\n            Write everything in portuguese from Brazil.\n            Don''t use names and personal data such (CPF, CNPJ, companie names, person names, process number).\n            Focus on the requests / orders made.\n            Always write your answer is ONLY in bullet points.\n            Always write the answer line by line, never let the text in just one line, separate the text.\n            Write a \" - \" in front of each line.\n            Summarize the text below, delimited by triple\n            backticks, in at most 200 words.\n            Document: ```{CD_SUMMARIZATION_input_text_string}```\n            ",
                        "actual_value": null,
                        "title": "Prompt base para sumariza��o",
                        "description": "prompt base para sumariza��o",
                        "items": null,
                        "child_properties": null
                    },
                    {
                        "name": "CD_SUMMARIZATION_system_prompt_string",
                        "type_property": "string",
                        "label_property": null,
                        "full_path": "CD_SUMMARIZATION_system_prompt_string",
                        "format_property": null,
                        "enum": null,
                        "required": true,
                        "default_value": " ",
                        "actual_value": null,
                        "title": "Texto de prompt do sistema",
                        "description": "Texto de prompt do sistema",
                        "items": null,
                        "child_properties": null
                    },
                    {
                        "name": "CD_SUMMARIZATION_open_ai_chat_completion_body_object",
                        "type_property": "object",
                        "label_property": null,
                        "full_path": "CD_SUMMARIZATION_open_ai_chat_completion_body_object",
                        "format_property": null,
                        "enum": null,
                        "required": true,
                        "default_value": null,
                        "actual_value": null,
                        "title": "Corpo da requisi��o para a API de gera��o de chat da Open AI",
                        "description": "Corpo da requisi��o para a API de gera��o de chat da Open AI",
                        "items": null,
                        "child_properties": [
                            {
                                "name": "CD_SUMMARIZATION_engine_string",
                                "type_property": "string",
                                "label_property": null,
                                "full_path": "CD_SUMMARIZATION_open_ai_chat_completion_body_object.CD_SUMMARIZATION_engine_string",
                                "format_property": null,
                                "enum": [
                                    "gpt-35-turbo-16k"
                                ],
                                "required": true,
                                "default_value": "gpt-35-turbo-16k",
                                "actual_value": null,
                                "title": "Vers�o do modelo da Open AI",
                                "description": "Vers�o do modelo da Open AI",
                                "items": null,
                                "child_properties": null
                            },
                            {
                                "name": "CD_SUMMARIZATION_messages_array",
                                "type_property": "array",
                                "label_property": null,
                                "full_path": "CD_SUMMARIZATION_open_ai_chat_completion_body_object.CD_SUMMARIZATION_messages_array",
                                "format_property": null,
                                "enum": null,
                                "required": false,
                                "default_value": [],
                                "actual_value": null,
                                "title": "Array de mensagens para conversa��o",
                                "description": "Array de mensagens para conversa��o",
                                "items": {
                                    "type_item": "string",
                                    "properties": null
                                },
                                "child_properties": []
                            },
                            {
                                "name": "CD_SUMMARIZATION_temperature_number",
                                "type_property": "number",
                                "label_property": null,
                                "full_path": "CD_SUMMARIZATION_open_ai_chat_completion_body_object.CD_SUMMARIZATION_temperature_number",
                                "format_property": null,
                                "enum": null,
                                "required": true,
                                "default_value": 0.5,
                                "actual_value": null,
                                "title": "Par�metro de temperatura para gera��o de texto",
                                "description": "Par�metro de temperatura para gera��o de texto",
                                "items": null,
                                "child_properties": null
                            },
                            {
                                "name": "CD_SUMMARIZATION_max_tokens_number",
                                "type_property": "number",
                                "label_property": null,
                                "full_path": "CD_SUMMARIZATION_open_ai_chat_completion_body_object.CD_SUMMARIZATION_max_tokens_number",
                                "format_property": null,
                                "enum": null,
                                "required": true,
                                "default_value": 2000,
                                "actual_value": null,
                                "title": "N�mero m�ximo de tokens a serem gerados",
                                "description": "N�mero m�ximo de tokens a serem gerados",
                                "items": null,
                                "child_properties": null
                            },
                            {
                                "name": "CD_SUMMARIZATION_top_p_number",
                                "type_property": "number",
                                "label_property": null,
                                "full_path": "CD_SUMMARIZATION_open_ai_chat_completion_body_object.CD_SUMMARIZATION_top_p_number",
                                "format_property": null,
                                "enum": null,
                                "required": true,
                                "default_value": 0.95,
                                "actual_value": null,
                                "title": "Par�metro de top-p sampling",
                                "description": "Par�metro de top-p sampling",
                                "items": null,
                                "child_properties": null
                            },
                            {
                                "name": "CD_SUMMARIZATION_frequency_penalty_number",
                                "type_property": "number",
                                "label_property": null,
                                "full_path": "CD_SUMMARIZATION_open_ai_chat_completion_body_object.CD_SUMMARIZATION_frequency_penalty_number",
                                "format_property": null,
                                "enum": null,
                                "required": true,
                                "default_value": 0,
                                "actual_value": null,
                                "title": "Penalidade de frequ�ncia para gera��o de texto",
                                "description": "Penalidade de frequ�ncia para gera��o de texto",
                                "items": null,
                                "child_properties": null
                            },
                            {
                                "name": "CD_SUMMARIZATION_presence_penalty_number",
                                "type_property": "number",
                                "label_property": null,
                                "full_path": "CD_SUMMARIZATION_open_ai_chat_completion_body_object.CD_SUMMARIZATION_presence_penalty_number",
                                "format_property": null,
                                "enum": null,
                                "required": true,
                                "default_value": 0,
                                "actual_value": null,
                                "title": "Penalidade de presen�a para gera��o de texto",
                                "description": "Penalidade de presen�a para gera��o de texto",
                                "items": null,
                                "child_properties": null
                            }
                        ]
                    }
                ]
            }
        }
    }
'
	, @WSCOutputCollection0 = '{
        "output": {
            "json_schema": {
                "$schema": "http://json-schema.org/draft-07/schema#",
                "type": "object",
                "properties": {
                    "CD_SUMMARIZATION_output_text_string": {
                        "type": "string",
                        "default": "",
                        "title": "Output Text",
                        "description": "Texto de sa�da"
                    },
                    "CD_SUMMARIZATION_metadata": {
                        "type": "object",
                        "properties": {
                            "prompt_tokens_string": {
                                "type": "string",
                                "default": "",
                                "title": "Prompt Tokens",
                                "description": "Prompt Tokens"
                            },
                            "completion_tokens_string": {
                                "type": "string",
                                "default": "",
                                "title": "Completion Tokens",
                                "description": "Completion Tokens"
                            },
                            "total_tokens_string": {
                                "type": "string",
                                "default": "",
                                "title": "Total Tokens",
                                "description": "Total Tokens"
                            },
                            "summary_rate_string": {
                                "type": "string",
                                "default": "",
                                "title": "Summary rate",
                                "description": "Summary rate"
                            },
                            "original_text_length_string": {
                                "type": "string",
                                "default": "",
                                "title": "Original Text length",
                                "description": "O n�mero de palavras ou caracteres no texto original"
                            },
                            "summarized_text_length_string": {
                                "type": "string",
                                "default": "",
                                "title": "Summarized text length",
                                "description": "O n�mero de palavras ou caracteres no texto resumido"
                            }
                        },
                        "required": [
                            "prompt_tokens_string",
                            "completion_tokens_string",
                            "total_tokens_string",
                            "summary_rate_string",
                            "original_text_length_string",
                            "summarized_text_length_string"
                        ]
                    }
                },
                "required": [
                    "CD_SUMMARIZATION_output_text_string",
                    "CD_SUMMARIZATION_metadata"
                ]
            },
            "json_schema_sample": {
                "CD_SUMMARIZATION_output_text_string": "Este � o texto sumarizado.",
                "CD_SUMMARIZATION_metadata": {
                    "prompt_tokens_string": "Estes s�o os tokens de prompt.",
                    "completion_tokens_string": "Estes s�o os tokens de conclus�o.",
                    "total_tokens_string": "100",
                    "summary_rate_string": "0.5",
                    "original_text_length_string": "200",
                    "summarized_text_length_string": "100"
                }
            },
            "default_configuration": null,
            "property_configuration": {
                "properties": [
                    {
                        "name": "CD_SUMMARIZATION_output_text_string",
                        "type_property": "string",
                        "label_property": null,
                        "full_path": "CD_SUMMARIZATION_output_text_string",
                        "format_property": null,
                        "enum": null,
                        "required": true,
                        "default_value": "",
                        "actual_value": null,
                        "title": "Output Text",
                        "description": "Texto de sa�da",
                        "items": null,
                        "child_properties": null
                    },
                    {
                        "name": "CD_SUMMARIZATION_metadata",
                        "type_property": "object",
                        "label_property": null,
                        "full_path": "CD_SUMMARIZATION_metadata",
                        "format_property": null,
                        "enum": null,
                        "required": true,
                        "default_value": null,
                        "actual_value": null,
                        "title": null,
                        "description": null,
                        "items": null,
                        "child_properties": [
                            {
                                "name": "prompt_tokens_string",
                                "type_property": "string",
                                "label_property": null,
                                "full_path": "CD_SUMMARIZATION_metadata.prompt_tokens_string",
                                "format_property": null,
                                "enum": null,
                                "required": true,
                                "default_value": "",
                                "actual_value": null,
                                "title": "Prompt Tokens",
                                "description": "Prompt Tokens",
                                "items": null,
                                "child_properties": null
                            },
                            {
                                "name": "completion_tokens_string",
                                "type_property": "string",
                                "label_property": null,
                                "full_path": "CD_SUMMARIZATION_metadata.completion_tokens_string",
                                "format_property": null,
                                "enum": null,
                                "required": true,
                                "default_value": "",
                                "actual_value": null,
                                "title": "Completion Tokens",
                                "description": "Completion Tokens",
                                "items": null,
                                "child_properties": null
                            },
                            {
                                "name": "total_tokens_string",
                                "type_property": "string",
                                "label_property": null,
                                "full_path": "CD_SUMMARIZATION_metadata.total_tokens_string",
                                "format_property": null,
                                "enum": null,
                                "required": true,
                                "default_value": "",
                                "actual_value": null,
                                "title": "Total Tokens",
                                "description": "Total Tokens",
                                "items": null,
                                "child_properties": null
                            },
                            {
                                "name": "summary_rate_string",
                                "type_property": "string",
                                "label_property": null,
                                "full_path": "CD_SUMMARIZATION_metadata.summary_rate_string",
                                "format_property": null,
                                "enum": null,
                                "required": true,
                                "default_value": "",
                                "actual_value": null,
                                "title": "Summary rate",
                                "description": "Summary rate",
                                "items": null,
                                "child_properties": null
                            },
                            {
                                "name": "original_text_length_string",
                                "type_property": "string",
                                "label_property": null,
                                "full_path": "CD_SUMMARIZATION_metadata.original_text_length_string",
                                "format_property": null,
                                "enum": null,
                                "required": true,
                                "default_value": "",
                                "actual_value": null,
                                "title": "Original Text length",
                                "description": "O n�mero de palavras ou caracteres no texto original",
                                "items": null,
                                "child_properties": null
                            },
                            {
                                "name": "summarized_text_length_string",
                                "type_property": "string",
                                "label_property": null,
                                "full_path": "CD_SUMMARIZATION_metadata.summarized_text_length_string",
                                "format_property": null,
                                "enum": null,
                                "required": true,
                                "default_value": "",
                                "actual_value": null,
                                "title": "Summarized text length",
                                "description": "O n�mero de palavras ou caracteres no texto resumido",
                                "items": null,
                                "child_properties": null
                            }
                        ]
                    }
                ]
            }
        },
        "partial_outputs": []
    }
'
	, @WSCMapping0 = null

INSERT INTO [genai].[WorkflowConfigurations] 
(
	[Id]
	, [StatusEntityModel]
	, [Code]
	, [Description]
	, [Title]
	, [TenantId]
	, [ExecutionCount]
	, [KafkaTopicCallback]
	, [CreatorUserId]
	, [CreationTime]
	, [Type]
) VALUES (
	@WorkflowConfigurationId
	, @StatusEntityModel
	, @Code
	, @Description
	, @Title
	, @TenantId
	, @ExecutionCount
	, @KafkaTopicCallback
	, @CreatorUserId
	, @CreationTime
	, NULL
)

INSERT INTO [genai].[WorkflowDetailConfigurations]
(
	[Id]
	, [WorkflowConfigurationId]
    , [Input]
    , [CreatorUserId]
    , [CreationTime]
) VALUES (
	NEWID()
	, @WorkflowConfigurationId
	, @InputCollection
	, @CreatorUserId
	, @CreationTime
)

INSERT INTO [genai].[WorkflowStepConfigurations]
(
	[Id]
	, [StatusEntityModel]
	, [Code]
	, [Description]
	, [Title]
	, [Order]
	, [WorkflowConfigurationId]
	, [ComponentConfigurationId]
	, [WorkflowStepConfigurationParentId]
	, [CreatorUserId]
	, [CreationTime]
) VALUES (
	@WSCId0
	, @StatusEntityModel
	, @WSCCode0
	, @WSCDescription0
	, @WSCTitle0
	, @WSCOrder0
	, @WorkflowConfigurationId
	, @WSCComponentConfigurationId0
	, @WSCParentId0
	, @CreatorUserId
	, @CreationTime
)

INSERT INTO [genai].[WorkflowStepDetailConfigurations]
(
	[Id]
	, [WorkflowStepConfigurationId]
	, [Input]
	, [Output]
	, [Mapping]
	, [CreatorUserId]
	, [CreationTime]
) VALUES (
	NEWID()
	, @WSCId0
	, @WSCInputCollection0
	, @WSCOutputCollection0
	, @WSCMapping0
	, @CreatorUserId
	, @CreationTime
)

SELECT * 
FROM [genai].[WorkflowConfigurations] WC WITH(NOLOCK)
LEFT JOIN [genai].[WorkflowDetailConfigurations] WDC WITH(NOLOCK) ON WDC.WorkflowConfigurationId = WC.Id
LEFT JOIN [genai].[WorkflowStepConfigurations] WSC WITH(NOLOCK) ON WSC.WorkflowConfigurationId = WC.Id
LEFT JOIN [genai].[WorkflowStepDetailConfigurations] WSDC WITH(NOLOCK) ON WSDC.WorkflowStepConfigurationId = WSC.Id
WHERE WC.Id = @WorkflowConfigurationId

COMMIT

