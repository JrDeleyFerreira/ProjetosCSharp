/*
Scripts de carga das configura��es de workflow
*/

DECLARE 
	@WorkflowConfigurationId uniqueidentifier
	, @StatusEntityModel nvarchar(20)
	, @Code nvarchar(50)
	, @Description nvarchar(max)
	, @Title nvarchar(100)
	, @TenantId uniqueidentifier
	, @ExecutionCount bigint
	, @KafkaTopicCallback nvarchar(100)
	, @CreatorUserId bigint
	, @CreationTime datetime2(7)
	, @InputCollection nvarchar(max)

DECLARE
	@WSCId0 uniqueidentifier
	, @WSCCode0 nvarchar(50)
	, @WSCDescription0 nvarchar(max)
	, @WSCTitle0 nvarchar(100)
	, @WSCOrder0 bigint
	, @WSCComponentConfigurationId0 uniqueidentifier
	, @WSCParentId0 uniqueidentifier
	, @WSCInputCollection0 nvarchar(max)
	, @WSCOutputCollection0 nvarchar(max)
	, @WSCMapping0 nvarchar(max) = null


/*
SCRIPT PARA CRIA��O DE WORKFLOW CD_WRFL_QA
*/
BEGIN TRAN

/* Vari�veis do WorkflowConfiguration */
SELECT 
	@WorkflowConfigurationId = 'cb6c5217-d5a6-4bdc-b47a-0907c9fcd25f' --NEWID()
	, @StatusEntityModel = 'ACTIVE'
	, @Code = 'CD_WRFL_PR'
	, @Description = 'Workflow PR'
	, @Title = 'Workflow PR'
	, @TenantId = '5846D05B-F0ED-49FF-B645-576812A70892'
	, @ExecutionCount = 0
	, @KafkaTopicCallback = null
	, @CreatorUserId = 1
	, @CreationTime = GETDATE()
	, @InputCollection = '{
        "properties": [
            {
                "workflow_step_id": "3c73cf88-3e93-4743-8e57-fdfb7dac2e40",
                "workflow_step_order": 0,
                "workflow_step_property": {
                    "properties": [
                        {
                            "name": "CD_PR_COMPONENT_personal_access_token_kv_string",
                            "type_property": "string",
                            "label_property": null,
                            "full_path": "CD_PR_COMPONENT_personal_access_token_kv_string",
                            "format_property": null,
                            "enum": null,
                            "required": true,
                            "default_value": "{{CD_PR_COMPONENT_personal_access_token_kv_string}}",
                            "actual_value": null,
                            "title": "Token de Acesso Pessoal do Azure no Key Vault",
                            "description": "Token de acesso pessoal do Azure no Key Vault",
                            "items": null,
                            "child_properties": null
                        },
                        {
                            "name": "CD_PR_COMPONENT_pull_request_url_string",
                            "type_property": "string",
                            "label_property": null,
                            "full_path": "CD_PR_COMPONENT_pull_request_url_string",
                            "format_property": null,
                            "enum": null,
                            "required": true,
                            "default_value": "{{CD_PR_COMPONENT_pull_request_url_string}}",
                            "actual_value": null,
                            "title": "URL do Pull Request",
                            "description": "URL do Pull Request",
                            "items": null,
                            "child_properties": null
                        }
                    ]
                }
            }
        ]
    }'
	
/* Vari�veis do WorkflowStepConfiguration */
SELECT
	/* Vari�veis step 0 */
	@WSCId0 = '3c73cf88-3e93-4743-8e57-fdfb7dac2e40' --newid()
	, @WSCCode0 = 'CD_ST_0_PR'
	, @WSCDescription0 = 'Etapa de PR'
	, @WSCTitle0 = 'Etapa PR'
	, @WSCOrder0 = 0
	, @WSCComponentConfigurationId0 = (SELECT [Id] FROM [genai].[ComponentConfigurations] CC WHERE CC.Code = 'CD_PR_COMPONENT') -- '9c3a6495-b6ab-4b01-8e97-0c44c8bb1065'
	, @WSCParentId0 = (SELECT [Id] FROM [genai].[WorkflowStepConfigurations] WSC WHERE WSC.Code = '')
	, @WSCInputCollection0 = '{
        "input": {
            "json_schema": {
                "$schema": "http://json-schema.org/draft-07/schema#",
                "type": "object",
                "properties": {
                    "CD_PR_COMPONENT_personal_access_token_kv_string": {
                        "type": "string",
                        "default": "{{CD_PR_COMPONENT_personal_access_token_kv_string}}",
                        "description": "Token de acesso pessoal do Azure no Key Vault",
                        "title": "Token de Acesso Pessoal do Azure no Key Vault"
                    },
                    "CD_PR_COMPONENT_pull_request_url_string": {
                        "type": "string",
                        "default": "{{CD_PR_COMPONENT_pull_request_url_string}}",
                        "description": "URL do Pull Request",
                        "title": "URL do Pull Request"
                    },
                    "CD_PR_COMPONENT_organization_url_string": {
                        "type": "string",
                        "default": "https://iautomation.visualstudio.com/",
                        "description": "URL da organiza��o no Visual Studio",
                        "title": "URL da Organiza��o no Visual Studio"
                    },
                    "CD_PR_COMPONENT_extra_instructions_string": {
                        "type": "string",
                        "default": "",
                        "description": "Instru��es extras para o componente",
                        "title": "Instru��es Extras"
                    },
                    "CD_PR_COMPONENT_open_ai_api_key_kv_string": {
                        "type": "string",
                        "default": "OPENAI-API-KEY4",
                        "description": "Chave da API Open AI no Key Vault",
                        "title": "Chave da API Open AI no Key Vault"
                    },
                    "CD_PR_COMPONENT_open_ai_api_base_string": {
                        "type": "string",
                        "default": "{{CD_PR_COMPONENT_open_ai_api_base_string}}",
                        "description": "Base URL da API Open AI",
                        "title": "Base URL da API Open AI"
                    },
                    "CD_PR_COMPONENT_open_ai_api_version_string": {
                        "type": "string",
                        "default": "2023-07-01-preview",
                        "description": "Vers�o da API Open AI",
                        "title": "Vers�o da API Open AI"
                    },
                    "CD_PR_COMPONENT_open_ai_api_type_string": {
                        "type": "string",
                        "default": "azure",
                        "description": "Tipo de API da Open AI",
                        "title": "Tipo de API da Open AI"
                    },
                    "CD_PR_COMPONENT_open_ai_engine_string": {
                        "type": "string",
                        "default": "gpt-4-32k",
                        "description": "Motor da Open AI utilizado",
                        "title": "Motor da Open AI"
                    }
                },
                "required": [
                    "CD_PR_COMPONENT_personal_access_token_kv_string",
                    "CD_PR_COMPONENT_pull_request_url_string",
                    "CD_PR_COMPONENT_organization_url_string",
                    "CD_PR_COMPONENT_extra_instructions_string",
                    "CD_PR_COMPONENT_open_ai_api_key_kv_string",
                    "CD_PR_COMPONENT_open_ai_api_base_string",
                    "CD_PR_COMPONENT_open_ai_api_version_string",
                    "CD_PR_COMPONENT_open_ai_api_type_string",
                    "CD_PR_COMPONENT_open_ai_engine_string"
                ]
            },
            "json_schema_sample": {
                "CD_PR_COMPONENT_personal_access_token_kv_string": "exemplo_token_acesso_pessoal",
                "CD_PR_COMPONENT_pull_request_url_string": "https://exemplo.visualstudio.com/repositorio/_pullRequest/123",
                "CD_PR_COMPONENT_organization_url_string": "https://exemplo.visualstudio.com/",
                "CD_PR_COMPONENT_extra_instructions_string": "Instru��es adicionais relevantes aqui",
                "CD_PR_COMPONENT_open_ai_api_key_kv_string": "OPENAI-API-KEY4",
                "CD_PR_COMPONENT_open_ai_api_base_string": "https://api.openai.com",
                "CD_PR_COMPONENT_open_ai_api_version_string": "2023-07-01-preview",
                "CD_PR_COMPONENT_open_ai_api_type_string": "azure",
                "CD_PR_COMPONENT_open_ai_engine_string": "gpt-4-32k"
            },
            "default_configuration": null,
            "property_configuration": {
                "properties": [
                    {
                        "name": "CD_PR_COMPONENT_personal_access_token_kv_string",
                        "type_property": "string",
                        "label_property": null,
                        "full_path": "CD_PR_COMPONENT_personal_access_token_kv_string",
                        "format_property": null,
                        "enum": null,
                        "required": true,
                        "default_value": "{{CD_PR_COMPONENT_personal_access_token_kv_string}}",
                        "actual_value": null,
                        "title": "Token de Acesso Pessoal do Azure no Key Vault",
                        "description": "Token de acesso pessoal do Azure no Key Vault",
                        "items": null,
                        "child_properties": null
                    },
                    {
                        "name": "CD_PR_COMPONENT_pull_request_url_string",
                        "type_property": "string",
                        "label_property": null,
                        "full_path": "CD_PR_COMPONENT_pull_request_url_string",
                        "format_property": null,
                        "enum": null,
                        "required": true,
                        "default_value": "{{CD_PR_COMPONENT_pull_request_url_string}}",
                        "actual_value": null,
                        "title": "URL do Pull Request",
                        "description": "URL do Pull Request",
                        "items": null,
                        "child_properties": null
                    },
                    {
                        "name": "CD_PR_COMPONENT_organization_url_string",
                        "type_property": "string",
                        "label_property": null,
                        "full_path": "CD_PR_COMPONENT_organization_url_string",
                        "format_property": null,
                        "enum": null,
                        "required": true,
                        "default_value": "https://iautomation.visualstudio.com/",
                        "actual_value": null,
                        "title": "URL da Organiza��o no Visual Studio",
                        "description": "URL da organiza��o no Visual Studio",
                        "items": null,
                        "child_properties": null
                    },
                    {
                        "name": "CD_PR_COMPONENT_extra_instructions_string",
                        "type_property": "string",
                        "label_property": null,
                        "full_path": "CD_PR_COMPONENT_extra_instructions_string",
                        "format_property": null,
                        "enum": null,
                        "required": true,
                        "default_value": "",
                        "actual_value": null,
                        "title": "Instru��es Extras",
                        "description": "Instru��es extras para o componente",
                        "items": null,
                        "child_properties": null
                    },
                    {
                        "name": "CD_PR_COMPONENT_open_ai_api_key_kv_string",
                        "type_property": "string",
                        "label_property": null,
                        "full_path": "CD_PR_COMPONENT_open_ai_api_key_kv_string",
                        "format_property": null,
                        "enum": null,
                        "required": true,
                        "default_value": "OPENAI-API-KEY4",
                        "actual_value": null,
                        "title": "Chave da API Open AI no Key Vault",
                        "description": "Chave da API Open AI no Key Vault",
                        "items": null,
                        "child_properties": null
                    },
                    {
                        "name": "CD_PR_COMPONENT_open_ai_api_base_string",
                        "type_property": "string",
                        "label_property": null,
                        "full_path": "CD_PR_COMPONENT_open_ai_api_base_string",
                        "format_property": null,
                        "enum": null,
                        "required": true,
                        "default_value": "https://oai-genai-pr001.openai.azure.com/",
                        "actual_value": null,
                        "title": "Base URL da API Open AI",
                        "description": "Base URL da API Open AI",
                        "items": null,
                        "child_properties": null
                    },
                    {
                        "name": "CD_PR_COMPONENT_open_ai_api_version_string",
                        "type_property": "string",
                        "label_property": null,
                        "full_path": "CD_PR_COMPONENT_open_ai_api_version_string",
                        "format_property": null,
                        "enum": null,
                        "required": true,
                        "default_value": "2023-07-01-preview",
                        "actual_value": null,
                        "title": "Vers�o da API Open AI",
                        "description": "Vers�o da API Open AI",
                        "items": null,
                        "child_properties": null
                    },
                    {
                        "name": "CD_PR_COMPONENT_open_ai_api_type_string",
                        "type_property": "string",
                        "label_property": null,
                        "full_path": "CD_PR_COMPONENT_open_ai_api_type_string",
                        "format_property": null,
                        "enum": null,
                        "required": true,
                        "default_value": "azure",
                        "actual_value": null,
                        "title": "Tipo de API da Open AI",
                        "description": "Tipo de API da Open AI",
                        "items": null,
                        "child_properties": null
                    },
                    {
                        "name": "CD_PR_COMPONENT_open_ai_engine_string",
                        "type_property": "string",
                        "label_property": null,
                        "full_path": "CD_PR_COMPONENT_open_ai_engine_string",
                        "format_property": null,
                        "enum": null,
                        "required": true,
                        "default_value": "gpt-4-32k",
                        "actual_value": null,
                        "title": "Motor da Open AI",
                        "description": "Motor da Open AI utilizado",
                        "items": null,
                        "child_properties": null
                    }
                ]
            }
        }
    }'
	, @WSCOutputCollection0 = '{
        "output": {
            "json_schema": {
                "$schema": "http://json-schema.org/draft-07/schema#",
                "type": "object",
                "properties": {
                    "CD_PR_COMPONENT_output_text_string": {
                        "type": "string",
                        "title": "Output Text",
                        "description": "Texto de sa�da para CD_PR_COMPONENT"
                    }
                },
                "required": [
                    "CD_PR_COMPONENT_output_text_string"
                ]
            },
            "json_schema_sample": {
                "CD_PR_COMPONENT_output_text_string": "Este � um texto de sa�da exemplo."
            },
            "default_configuration": null,
            "property_configuration": {
                "properties": [
                    {
                        "name": "CD_PR_COMPONENT_output_text_string",
                        "type_property": "string",
                        "label_property": null,
                        "full_path": "CD_PR_COMPONENT_output_text_string",
                        "format_property": null,
                        "enum": null,
                        "required": true,
                        "default_value": null,
                        "actual_value": null,
                        "title": "Output Text",
                        "description": "Texto de sa�da para CD_PR_COMPONENT",
                        "items": null,
                        "child_properties": null
                    }
                ]
            }
        },
        "partial_outputs": []
    }'
	, @WSCMapping0 = null

INSERT INTO [genai].[WorkflowConfigurations] 
(
	[Id]
	, [StatusEntityModel]
	, [Code]
	, [Description]
	, [Title]
	, [TenantId]
	, [ExecutionCount]
	, [KafkaTopicCallback]
	, [CreatorUserId]
	, [CreationTime]
	, [Type]
) VALUES (
	@WorkflowConfigurationId
	, @StatusEntityModel
	, @Code
	, @Description
	, @Title
	, @TenantId
	, @ExecutionCount
	, @KafkaTopicCallback
	, @CreatorUserId
	, @CreationTime
	, 'PLAYGROUND'
)

INSERT INTO [genai].[WorkflowDetailConfigurations]
(
	[Id]
	, [WorkflowConfigurationId]
    , [Input]
    , [CreatorUserId]
    , [CreationTime]
) VALUES (
	NEWID()
	, @WorkflowConfigurationId
	, @InputCollection
	, @CreatorUserId
	, @CreationTime
)

INSERT INTO [genai].[WorkflowStepConfigurations]
(
	[Id]
	, [StatusEntityModel]
	, [Code]
	, [Description]
	, [Title]
	, [Order]
	, [WorkflowConfigurationId]
	, [ComponentConfigurationId]
	, [WorkflowStepConfigurationParentId]
	, [CreatorUserId]
	, [CreationTime]
) VALUES (
	@WSCId0
	, @StatusEntityModel
	, @WSCCode0
	, @WSCDescription0
	, @WSCTitle0
	, @WSCOrder0
	, @WorkflowConfigurationId
	, @WSCComponentConfigurationId0
	, @WSCParentId0
	, @CreatorUserId
	, @CreationTime
)

INSERT INTO [genai].[WorkflowStepDetailConfigurations]
(
	[Id]
	, [WorkflowStepConfigurationId]
	, [Input]
	, [Output]
	, [Mapping]
	, [CreatorUserId]
	, [CreationTime]
) VALUES (
	NEWID()
	, @WSCId0
	, @WSCInputCollection0
	, @WSCOutputCollection0
	, @WSCMapping0
	, @CreatorUserId
	, @CreationTime
)

SELECT * 
FROM [genai].[WorkflowConfigurations] WC WITH(NOLOCK)
LEFT JOIN [genai].[WorkflowDetailConfigurations] WDC WITH(NOLOCK) ON WDC.WorkflowConfigurationId = WC.Id
LEFT JOIN [genai].[WorkflowStepConfigurations] WSC WITH(NOLOCK) ON WSC.WorkflowConfigurationId = WC.Id
LEFT JOIN [genai].[WorkflowStepDetailConfigurations] WSDC WITH(NOLOCK) ON WSDC.WorkflowStepConfigurationId = WSC.Id
WHERE WC.Id = @WorkflowConfigurationId

COMMIT

