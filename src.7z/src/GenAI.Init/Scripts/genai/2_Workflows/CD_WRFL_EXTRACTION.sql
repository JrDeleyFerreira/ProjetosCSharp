/*
Scripts de carga das configura��es de workflow
*/

DECLARE 
	@WorkflowConfigurationId uniqueidentifier
	, @StatusEntityModel nvarchar(20)
	, @Code nvarchar(50)
	, @Description nvarchar(max)
	, @Title nvarchar(100)
	, @TenantId uniqueidentifier
	, @ExecutionCount bigint
	, @KafkaTopicCallback nvarchar(100)
	, @CreatorUserId bigint
	, @CreationTime datetime2(7)
	, @InputCollection nvarchar(max)

DECLARE
	@WSCId0 uniqueidentifier
	, @WSCCode0 nvarchar(50)
	, @WSCDescription0 nvarchar(max)
	, @WSCTitle0 nvarchar(100)
	, @WSCOrder0 bigint
	, @WSCComponentConfigurationId0 uniqueidentifier
	, @WSCParentId0 uniqueidentifier
	, @WSCInputCollection0 nvarchar(max)
	, @WSCOutputCollection0 nvarchar(max)
	, @WSCMapping0 nvarchar(max) = null


/*
SCRIPT PARA CRIA��O DE WORKFLOW CD_WRFL_QA
*/
BEGIN TRAN

/* Vari�veis do WorkflowConfiguration */
SELECT 
	@WorkflowConfigurationId = 'cd93ce10-c825-47ec-b31e-54002893d564' --NEWID()
	, @StatusEntityModel = 'ACTIVE'
	, @Code = 'CD_WRFL_EXTRACTION'
	, @Description = 'Workflow Extraction'
	, @Title = 'Workflow Extraction'
	, @TenantId = '5846D05B-F0ED-49FF-B645-576812A70892'
	, @ExecutionCount = 0
	, @KafkaTopicCallback = null
	, @CreatorUserId = 1
	, @CreationTime = GETDATE()
	, @InputCollection = '{
        "properties": [
            {
                "workflow_step_id": "0ed792ec-092f-4b8b-ac80-ceb8b5e51583",
                "workflow_step_order": 0,
                "workflow_step_property": {
                    "properties": [
                        {
                            "name": "CD_EXTRACTION_input_text_string",
                            "type_property": "string",
                            "label_property": null,
                            "full_path": "CD_EXTRACTION_input_text_string",
                            "format_property": null,
                            "enum": null,
                            "required": true,
                            "default_value": "{{CD_EXTRACTION_input_text_string}}",
                            "actual_value": null,
                            "title": "Texto a ser extra�do",
                            "description": "Texto a ser extra�do",
                            "items": null,
                            "child_properties": null
                        }
                    ]
                }
            }
        ]
    }'
	
/* Vari�veis do WorkflowStepConfiguration */
SELECT
	/* Vari�veis step 0 */
	@WSCId0 = '0ed792ec-092f-4b8b-ac80-ceb8b5e51583' --newid()
	, @WSCCode0 = 'CD_ST_0_EXTRACTION'
	, @WSCDescription0 = 'Etapa de entrada de texto para extra��o'
	, @WSCTitle0 = 'Etapa de entrada de texto para extra��o'
	, @WSCOrder0 = 0
	, @WSCComponentConfigurationId0 = (SELECT [Id] FROM [genai].[ComponentConfigurations] CC WHERE CC.Code = 'CD_EXTRACTION') -- '9c3a6495-b6ab-4b01-8e97-0c44c8bb1065'
	, @WSCParentId0 = (SELECT [Id] FROM [genai].[WorkflowStepConfigurations] WSC WHERE WSC.Code = '')
	, @WSCInputCollection0 = '{
        "input": {
            "json_schema": {
                "$schema": "http://json-schema.org/draft-07/schema#",
                "type": "object",
                "properties": {
                    "CD_EXTRACTION_open_ai_api_base_string": {
                        "type": "string",
                        "default": "{{CD_EXTRACTION_open_ai_api_base_string}}",
                        "description": "Open AI URL (URL da Open AI)",
                        "title": "Open AI URL"
                    },
                    "CD_EXTRACTION_open_ai_api_version_string": {
                        "type": "string",
                        "default": "{{CD_EXTRACTION_open_ai_api_version_string}}",
                        "description": "Open AI API Version",
                        "title": "Open AI API Version"
                    },
                    "CD_EXTRACTION_open_ai_api_type_string": {
                        "type": "string",
                        "default": "{{CD_EXTRACTION_open_ai_api_type_string}}",
                        "description": "Open AI API Type",
                        "title": "Open AI API Type"
                    },
                    "CD_EXTRACTION_open_ai_api_key_string": {
                        "type": "string",
                        "default": "{{CD_EXTRACTION_open_ai_api_key_string}}",
                        "description": "Open AI Key (Chave da Open AI)",
                        "title": "Open AI Key"
                    },
                    "CD_EXTRACTION_input_text_string": {
                        "type": "string",
                        "default": "{{CD_EXTRACTION_input_text_string}}",
                        "description": "Texto a ser extra�do",
                        "title": "Texto a ser extra�do"
                    },
                    "CD_EXTRACTION_prompt_string": {
                        "type": "string",
                        "default": "{{CD_EXTRACTION_prompt_string}}",
                        "description": "prompt base para extra��o",
                        "title": "Prompt base para extra��o"
                    },
                    "CD_EXTRACTION_system_prompt_string": {
                        "type": "string",
                        "default": "{{CD_EXTRACTION_system_prompt_string}}",
                        "description": "Texto de prompt do sistema",
                        "title": "Texto de prompt do sistema"
                    },
                    "CD_EXTRACTION_partial_json_schema_array": {
                        "type": "array",
                        "items": {
                            "type": "object"
                        },
                        "description": "Array de objetos.",
                        "title": "Array de objetos"
                    },
                    "CD_EXTRACTION_open_ai_chat_completion_body_object": {
                        "type": "object",
                        "properties": {
                            "CD_EXTRACTION_engine_string": {
                                "type": "string",
                                "enum": [
                                    "gpt-4-32k"
                                ],
                                "default": "gpt-4-32k",
                                "description": "Vers�o do modelo da Open AI",
                                "title": "Vers�o do modelo da Open AI"
                            },
                            "CD_EXTRACTION_messages_array": {
                                "type": "array",
                                "items": {
                                    "type": "string"
                                },
                                "default": [],
                                "description": "Array de mensagens para conversa��o",
                                "title": "Array de mensagens para conversa��o"
                            },
                            "CD_EXTRACTION_temperature_number": {
                                "type": "number",
                                "default": 0.5,
                                "description": "Par�metro de temperatura para gera��o de texto",
                                "title": "Par�metro de temperatura para gera��o de texto"
                            },
                            "CD_EXTRACTION_max_tokens_number": {
                                "type": "number",
                                "default": 2000,
                                "description": "N�mero m�ximo de tokens a serem gerados",
                                "title": "N�mero m�ximo de tokens a serem gerados"
                            },
                            "CD_EXTRACTION_top_p_number": {
                                "type": "number",
                                "default": 0.95,
                                "description": "Par�metro de top-p sampling",
                                "title": "Par�metro de top-p sampling"
                            },
                            "CD_EXTRACTION_frequency_penalty_number": {
                                "type": "number",
                                "default": 0,
                                "description": "Penalidade de frequ�ncia para gera��o de texto",
                                "title": "Penalidade de frequ�ncia para gera��o de texto"
                            },
                            "CD_EXTRACTION_presence_penalty_number": {
                                "type": "number",
                                "default": 0,
                                "description": "Penalidade de presen�a para gera��o de texto",
                                "title": "Penalidade de presen�a para gera��o de texto"
                            }
                        },
                        "required": [
                            "CD_EXTRACTION_engine_string",
                            "CD_EXTRACTION_temperature_number",
                            "CD_EXTRACTION_max_tokens_number",
                            "CD_EXTRACTION_top_p_number",
                            "CD_EXTRACTION_frequency_penalty_number",
                            "CD_EXTRACTION_presence_penalty_number"
                        ],
                        "description": "Corpo da requisi��o para a API de gera��o de chat da Open AI",
                        "title": "Corpo da requisi��o para a API de gera��o de chat da Open AI"
                    }
                },
                "required": [
                    "CD_EXTRACTION_open_ai_api_base_string",
                    "CD_EXTRACTION_open_ai_api_version_string",
                    "CD_EXTRACTION_open_ai_api_key_string",
                    "CD_EXTRACTION_open_ai_api_type_string",
                    "CD_EXTRACTION_input_text_string",
                    "CD_EXTRACTION_prompt_string",
                    "CD_EXTRACTION_system_prompt_string",
                    "CD_EXTRACTION_open_ai_chat_completion_body_object"
                ]
            },
            "json_schema_sample": {
                "CD_EXTRACTION_open_ai_api_base_string": "https://api.openai.com/v1/engines/davinci/completions",
                "CD_EXTRACTION_open_ai_api_key_string": "OPEN_AI_KEY",
                "CD_EXTRACTION_open_ai_api_version_string": "2023-07-01-preview",
                "CD_EXTRACTION_open_ai_api_type_string": "azure",
                "CD_EXTRACTION_input_text_string": "Texto de sa�da para exemplo de mapping",
                "CD_EXTRACTION_prompt_string": "Logo abaixo segue um prompt e um template schema para o mapeamento de dados...",
                "CD_EXTRACTION_system_prompt_string": "Quero que voc� realize a extra��o do texto XYZ.",
                "CD_EXTRACTION_partial_json_schema_array": [
                    {
                        "campo1": "valor1",
                        "campo2": 123
                    },
                    {
                        "campoA": "valorA",
                        "campoB": "valorB",
                        "campoC": [
                            1,
                            2,
                            3
                        ]
                    }
                ],
                "CD_EXTRACTION_open_ai_chat_completion_body_object": {
                    "CD_EXTRACTION_engine_string": "gpt-35-turbo-16k",
                    "CD_EXTRACTION_messages_array": [],
                    "CD_EXTRACTION_temperature_number": 0.5,
                    "CD_EXTRACTION_max_tokens_number": 2000,
                    "CD_EXTRACTION_top_p_number": 0.95,
                    "CD_EXTRACTION_frequency_penalty_number": 0,
                    "CD_EXTRACTION_presence_penalty_number": 0
                }
            },
            "default_configuration": null,
            "property_configuration": {
                "properties": [
                    {
                        "name": "CD_EXTRACTION_open_ai_api_base_string",
                        "type_property": "string",
                        "label_property": null,
                        "full_path": "CD_EXTRACTION_open_ai_api_base_string",
                        "format_property": null,
                        "enum": null,
                        "required": true,
                        "default_value": "https://oai-genai-pr001.openai.azure.com/",
                        "actual_value": null,
                        "title": "Open AI URL",
                        "description": "Open AI URL (URL da Open AI)",
                        "items": null,
                        "child_properties": null
                    },
                    {
                        "name": "CD_EXTRACTION_open_ai_api_version_string",
                        "type_property": "string",
                        "label_property": null,
                        "full_path": "CD_EXTRACTION_open_ai_api_version_string",
                        "format_property": null,
                        "enum": null,
                        "required": true,
                        "default_value": "2023-07-01-preview",
                        "actual_value": null,
                        "title": "Open AI API Version",
                        "description": "Open AI API Version",
                        "items": null,
                        "child_properties": null
                    },
                    {
                        "name": "CD_EXTRACTION_open_ai_api_type_string",
                        "type_property": "string",
                        "label_property": null,
                        "full_path": "CD_EXTRACTION_open_ai_api_type_string",
                        "format_property": null,
                        "enum": null,
                        "required": true,
                        "default_value": "azure",
                        "actual_value": null,
                        "title": "Open AI API Type",
                        "description": "Open AI API Type",
                        "items": null,
                        "child_properties": null
                    },
                    {
                        "name": "CD_EXTRACTION_open_ai_api_key_string",
                        "type_property": "string",
                        "label_property": null,
                        "full_path": "CD_EXTRACTION_open_ai_api_key_string",
                        "format_property": null,
                        "enum": null,
                        "required": true,
                        "default_value": "OPENAI-API-KEY4",
                        "actual_value": null,
                        "title": "Open AI Key",
                        "description": "Open AI Key (Chave da Open AI)",
                        "items": null,
                        "child_properties": null
                    },
                    {
                        "name": "CD_EXTRACTION_input_text_string",
                        "type_property": "string",
                        "label_property": null,
                        "full_path": "CD_EXTRACTION_input_text_string",
                        "format_property": null,
                        "enum": null,
                        "required": true,
                        "default_value": "{{CD_EXTRACTION_input_text_string}}",
                        "actual_value": null,
                        "title": "Texto a ser extra�do",
                        "description": "Texto a ser extra�do",
                        "items": null,
                        "child_properties": null
                    },
                    {
                        "name": "CD_EXTRACTION_prompt_string",
                        "type_property": "string",
                        "label_property": null,
                        "full_path": "CD_EXTRACTION_prompt_string",
                        "format_property": null,
                        "enum": null,
                        "required": true,
                        "default_value": "\n        of�cio: ```{CD_EXTRACTION_input_text_string}```\n\n        modelo JSON: ###{json_schema}### ",
                        "actual_value": null,
                        "title": "Prompt base para extra��o",
                        "description": "prompt base para extra��o",
                        "items": null,
                        "child_properties": null
                    },
                    {
                        "name": "CD_EXTRACTION_system_prompt_string",
                        "type_property": "string",
                        "label_property": null,
                        "full_path": "CD_EXTRACTION_system_prompt_string",
                        "format_property": null,
                        "enum": null,
                        "required": true,
                        "default_value": "\n    Atue como um analista judicial com ampla experi�ncia em of�cios jur�dicos.\n    Siga as instru��es a baixo passo a passo.\n    Sua principal fun��o � analisar um of�cio judicial que estar� entre crases triplas ```.\n    Sua resposta deve estar no formato JSON, use o formato de exemplo que est� entre cerquilhas triplas ###.\n    Para preencher as propriedades ''value'' do objeto JSON voc� deve seguir as ''instru��es'' que est�o na propriedade ''description'', responda todas de maneira minuciosa.\n\n    Sua resposta deve ser no formato JSON de sa�da.\n    Sua respostar deve estar neste formato:\n    {\n  \"nomeDaPropriedade\": \"Valor\",\n  \"nomeDaPropriedade\": [\"Valor\"]\n}",
                        "actual_value": null,
                        "title": "Texto de prompt do sistema",
                        "description": "Texto de prompt do sistema",
                        "items": null,
                        "child_properties": null
                    },
                    {
                        "name": "CD_EXTRACTION_partial_json_schema_array",
                        "type_property": "array",
                        "label_property": null,
                        "full_path": "CD_EXTRACTION_partial_json_schema_array",
                        "format_property": null,
                        "enum": null,
                        "required": false,
                        "default_value": null,
                        "actual_value": [
                            {
                                "$schema": "https://json-schema.org/draft-07/schema#",
                                "type": "object",
                                "properties": {
                                    "processoJudicial": {
                                        "type": "string",
                                        "description": "responda o n�mero do processo judicial que consta no of�cio, se n�o existir responda ''N�o identificado''"
                                    },
                                    "numeroOficio": {
                                        "type": "string",
                                        "description": "responda o n�mero do of�cio, se n�o existir responda ''N�o identificado'';"
                                    },
                                    "estado": {
                                        "type": "string",
                                        "description": "responda o Estado do org�o solicitante, se n�o existir responda ''N�o identificado'';"
                                    },
                                    "municipio": {
                                        "type": "string",
                                        "description": "responda o Munic�pio do org�o solicitante, se n�o existir responda ''N�o identificado'';"
                                    },
                                    "orgaoJulgador": {
                                        "type": "string",
                                        "description": "geralmente � a ''Vara'', mas nem sempre. ''Vara estadual'', ''Vara do Trabalho'', entre outras. Se o of�cio for expedido por delegacia, ser� o �rg�o julgador, se n�o existir responda ''N�o identificado'';"
                                    },
                                    "prazoAtendimento": {
                                        "type": "string",
                                        "description": "existe o prazo que o Banco Bradesco tem para responder ao requerimento? Obtenha apenas o n�mero, nunca o texto, se n�o existir responda ''N�o identificado'';"
                                    },
                                    "prazoOficio": {
                                        "type": "string",
                                        "description": "existe o prazo Banco Bradesco tem para responder ao requerimento? Sua resposta deve vir como: ''dia(s)'', ''dias uteis'', ''horas'', ''data definida'' ou ''N�o identificado'';"
                                    },
                                    "membroPartidoPolitico": {
                                        "type": "string",
                                        "description": "� uma resposta bin�ria, ''Sim'' ou ''N�o identificado'', se ''incluirNomePartidoPolitico'' for diferente de ''N�o identificado'', use ''Sim'', sen�o ''N�o identificado'';"
                                    },
                                    "incluirNomePartidoPolitico": {
                                        "type": "string",
                                        "description": "Procure os nomes nesta lista: PoliticalParty dentro do documento que foi passado, se n�o existir responda ''N�o identificado'';"
                                    }
                                },
                                "required": [
                                    "processoJudicial",
                                    "numeroOficio",
                                    "estado",
                                    "municipio",
                                    "orgaoJulgador",
                                    "prazoAtendimento",
                                    "prazoOficio",
                                    "membroPartidoPolitico",
                                    "incluirNomePartidoPolitico"
                                ]
                            },
                            {
                                "$schema": "https://json-schema.org/draft-07/schema#",
                                "type": "object",
                                "properties": {
                                    "email": {
                                        "type": "string",
                                        "description": "retorne apenas o email que for do org�o julgador, retorne no formato de lista ['']. Caso n�o tenha, dever� retornar [''];"
                                    }
                                },
                                "required": [
                                    "email"
                                ]
                            },
                            {
                                "$schema": "https://json-schema.org/draft-07/schema#",
                                "type": "object",
                                "properties": {
                                    "executados": {
                                        "description": "Diga os nomes e cpf ou cnpj das partes envolvidas que est�o presentes no of�cio. \nFa�a as corre��es de acentua��o nos nomes, por exemplo: De ''GRAFICA'' para ''GR�FICA''.\n se for CPF use o formato ''000.000.000-00'' ou ''00.000.000/0000-00'' se for CNPJ. \n N�o inclua no JSON ''nomes'' que se repetem e que n�o tem ''cpfOuCnpj'' em formato num�rico.\n Se n�o existir ''nome'' ou ''cpfOuCnpj'' preencha ''N�o identificado'';",
                                        "type": "array",
                                        "items": {
                                            "type": "object",
                                            "properties": {
                                                "nome": {
                                                    "type": "string",
                                                    "description": ""
                                                },
                                                "cpfOuCnpj": {
                                                    "type": "string",
                                                    "pattern": "^(\\d{3}\\.\\d{3}\\.\\d{3}-\\d{2}|\\d{2}\\.\\d{3}\\.\\d{3}/\\d{4}-\\d{2})$",
                                                    "description": ""
                                                }
                                            },
                                            "required": [
                                                "nome",
                                                "cpfOuCnpj"
                                            ]
                                        }
                                    }
                                },
                                "required": [
                                    "executados"
                                ]
                            }
                        ],
                        "title": "Array de objetos",
                        "description": "Array de objetos.",
                        "items": {
                            "type_item": "object",
                            "properties": []
                        },
                        "child_properties": []
                    },
                    {
                        "name": "CD_EXTRACTION_open_ai_chat_completion_body_object",
                        "type_property": "object",
                        "label_property": null,
                        "full_path": "CD_EXTRACTION_open_ai_chat_completion_body_object",
                        "format_property": null,
                        "enum": null,
                        "required": true,
                        "default_value": null,
                        "actual_value": null,
                        "title": "Corpo da requisi��o para a API de gera��o de chat da Open AI",
                        "description": "Corpo da requisi��o para a API de gera��o de chat da Open AI",
                        "items": null,
                        "child_properties": [
                            {
                                "name": "CD_EXTRACTION_engine_string",
                                "type_property": "string",
                                "label_property": null,
                                "full_path": "CD_EXTRACTION_open_ai_chat_completion_body_object.CD_EXTRACTION_engine_string",
                                "format_property": null,
                                "enum": [
                                    "gpt-4-32k"
                                ],
                                "required": true,
                                "default_value": "gpt-4-32k",
                                "actual_value": null,
                                "title": "Vers�o do modelo da Open AI",
                                "description": "Vers�o do modelo da Open AI",
                                "items": null,
                                "child_properties": null
                            },
                            {
                                "name": "CD_EXTRACTION_messages_array",
                                "type_property": "array",
                                "label_property": null,
                                "full_path": "CD_EXTRACTION_open_ai_chat_completion_body_object.CD_EXTRACTION_messages_array",
                                "format_property": null,
                                "enum": null,
                                "required": false,
                                "default_value": [],
                                "actual_value": null,
                                "title": "Array de mensagens para conversa��o",
                                "description": "Array de mensagens para conversa��o",
                                "items": {
                                    "type_item": "string",
                                    "properties": null
                                },
                                "child_properties": []
                            },
                            {
                                "name": "CD_EXTRACTION_temperature_number",
                                "type_property": "number",
                                "label_property": null,
                                "full_path": "CD_EXTRACTION_open_ai_chat_completion_body_object.CD_EXTRACTION_temperature_number",
                                "format_property": null,
                                "enum": null,
                                "required": true,
                                "default_value": 0.5,
                                "actual_value": null,
                                "title": "Par�metro de temperatura para gera��o de texto",
                                "description": "Par�metro de temperatura para gera��o de texto",
                                "items": null,
                                "child_properties": null
                            },
                            {
                                "name": "CD_EXTRACTION_max_tokens_number",
                                "type_property": "number",
                                "label_property": null,
                                "full_path": "CD_EXTRACTION_open_ai_chat_completion_body_object.CD_EXTRACTION_max_tokens_number",
                                "format_property": null,
                                "enum": null,
                                "required": true,
                                "default_value": 2000,
                                "actual_value": null,
                                "title": "N�mero m�ximo de tokens a serem gerados",
                                "description": "N�mero m�ximo de tokens a serem gerados",
                                "items": null,
                                "child_properties": null
                            },
                            {
                                "name": "CD_EXTRACTION_top_p_number",
                                "type_property": "number",
                                "label_property": null,
                                "full_path": "CD_EXTRACTION_open_ai_chat_completion_body_object.CD_EXTRACTION_top_p_number",
                                "format_property": null,
                                "enum": null,
                                "required": true,
                                "default_value": 0.95,
                                "actual_value": null,
                                "title": "Par�metro de top-p sampling",
                                "description": "Par�metro de top-p sampling",
                                "items": null,
                                "child_properties": null
                            },
                            {
                                "name": "CD_EXTRACTION_frequency_penalty_number",
                                "type_property": "number",
                                "label_property": null,
                                "full_path": "CD_EXTRACTION_open_ai_chat_completion_body_object.CD_EXTRACTION_frequency_penalty_number",
                                "format_property": null,
                                "enum": null,
                                "required": true,
                                "default_value": 0,
                                "actual_value": null,
                                "title": "Penalidade de frequ�ncia para gera��o de texto",
                                "description": "Penalidade de frequ�ncia para gera��o de texto",
                                "items": null,
                                "child_properties": null
                            },
                            {
                                "name": "CD_EXTRACTION_presence_penalty_number",
                                "type_property": "number",
                                "label_property": null,
                                "full_path": "CD_EXTRACTION_open_ai_chat_completion_body_object.CD_EXTRACTION_presence_penalty_number",
                                "format_property": null,
                                "enum": null,
                                "required": true,
                                "default_value": 0,
                                "actual_value": null,
                                "title": "Penalidade de presen�a para gera��o de texto",
                                "description": "Penalidade de presen�a para gera��o de texto",
                                "items": null,
                                "child_properties": null
                            }
                        ]
                    }
                ]
            }
        }
    }'
	, @WSCOutputCollection0 = '{
        "output": {
            "json_schema": {
                "$schema": "http://json-schema.org/draft-07/schema#",
                "type": "object",
                "properties": {
                    "CD_EXTRACTION_output_json_data_object": {
                        "type": "object",
                        "title": "Output json data",
                        "description": "Dados extra�dos"
                    },
                    "CD_EXTRACTION_metadata": {
                        "type": "object",
                        "properties": {
                            "prompt_tokens_string": {
                                "type": "string",
                                "default": "",
                                "title": "Prompt Tokens",
                                "description": "Prompt Tokens"
                            },
                            "completion_tokens_string": {
                                "type": "string",
                                "default": "",
                                "title": "Completion Tokens",
                                "description": "Completion Tokens"
                            },
                            "total_tokens_string": {
                                "type": "string",
                                "default": "",
                                "title": "Total Tokens",
                                "description": "Total Tokens"
                            }
                        },
                        "required": [
                            "prompt_tokens_string",
                            "completion_tokens_string",
                            "total_tokens_string"
                        ]
                    }
                },
                "required": [
                    "CD_EXTRACTION_output_json_data_object",
                    "CD_EXTRACTION_metadata"
                ]
            },
            "json_schema_sample": {
                "CD_EXTRACTION_output_json_data_object": {
                    "teste": "a"
                },
                "CD_EXTRACTION_metadata": {
                    "prompt_tokens_string": "Estes s�o os tokens de prompt.",
                    "completion_tokens_string": "Estes s�o os tokens de conclus�o.",
                    "total_tokens_string": "100"
                }
            },
            "default_configuration": null,
            "property_configuration": {
                "properties": [
                    {
                        "name": "CD_EXTRACTION_output_json_data_object",
                        "type_property": "object",
                        "label_property": null,
                        "full_path": "CD_EXTRACTION_output_json_data_object",
                        "format_property": null,
                        "enum": null,
                        "required": true,
                        "default_value": null,
                        "actual_value": null,
                        "title": "Output json data",
                        "description": "Dados extra�dos",
                        "items": null,
                        "child_properties": []
                    },
                    {
                        "name": "CD_EXTRACTION_metadata",
                        "type_property": "object",
                        "label_property": null,
                        "full_path": "CD_EXTRACTION_metadata",
                        "format_property": null,
                        "enum": null,
                        "required": true,
                        "default_value": null,
                        "actual_value": null,
                        "title": null,
                        "description": null,
                        "items": null,
                        "child_properties": [
                            {
                                "name": "prompt_tokens_string",
                                "type_property": "string",
                                "label_property": null,
                                "full_path": "CD_EXTRACTION_metadata.prompt_tokens_string",
                                "format_property": null,
                                "enum": null,
                                "required": true,
                                "default_value": "",
                                "actual_value": null,
                                "title": "Prompt Tokens",
                                "description": "Prompt Tokens",
                                "items": null,
                                "child_properties": null
                            },
                            {
                                "name": "completion_tokens_string",
                                "type_property": "string",
                                "label_property": null,
                                "full_path": "CD_EXTRACTION_metadata.completion_tokens_string",
                                "format_property": null,
                                "enum": null,
                                "required": true,
                                "default_value": "",
                                "actual_value": null,
                                "title": "Completion Tokens",
                                "description": "Completion Tokens",
                                "items": null,
                                "child_properties": null
                            },
                            {
                                "name": "total_tokens_string",
                                "type_property": "string",
                                "label_property": null,
                                "full_path": "CD_EXTRACTION_metadata.total_tokens_string",
                                "format_property": null,
                                "enum": null,
                                "required": true,
                                "default_value": "",
                                "actual_value": null,
                                "title": "Total Tokens",
                                "description": "Total Tokens",
                                "items": null,
                                "child_properties": null
                            }
                        ]
                    }
                ]
            }
        },
        "partial_outputs": []
    }'
	, @WSCMapping0 = null

INSERT INTO [genai].[WorkflowConfigurations] 
(
	[Id]
	, [StatusEntityModel]
	, [Code]
	, [Description]
	, [Title]
	, [TenantId]
	, [ExecutionCount]
	, [KafkaTopicCallback]
	, [CreatorUserId]
	, [CreationTime]
	, [Type]
) VALUES (
	@WorkflowConfigurationId
	, @StatusEntityModel
	, @Code
	, @Description
	, @Title
	, @TenantId
	, @ExecutionCount
	, @KafkaTopicCallback
	, @CreatorUserId
	, @CreationTime
	, 'PLAYGROUND'
)

INSERT INTO [genai].[WorkflowDetailConfigurations]
(
	[Id]
	, [WorkflowConfigurationId]
    , [Input]
    , [CreatorUserId]
    , [CreationTime]
) VALUES (
	NEWID()
	, @WorkflowConfigurationId
	, @InputCollection
	, @CreatorUserId
	, @CreationTime
)

INSERT INTO [genai].[WorkflowStepConfigurations]
(
	[Id]
	, [StatusEntityModel]
	, [Code]
	, [Description]
	, [Title]
	, [Order]
	, [WorkflowConfigurationId]
	, [ComponentConfigurationId]
	, [WorkflowStepConfigurationParentId]
	, [CreatorUserId]
	, [CreationTime]
) VALUES (
	@WSCId0
	, @StatusEntityModel
	, @WSCCode0
	, @WSCDescription0
	, @WSCTitle0
	, @WSCOrder0
	, @WorkflowConfigurationId
	, @WSCComponentConfigurationId0
	, @WSCParentId0
	, @CreatorUserId
	, @CreationTime
)

INSERT INTO [genai].[WorkflowStepDetailConfigurations]
(
	[Id]
	, [WorkflowStepConfigurationId]
	, [Input]
	, [Output]
	, [Mapping]
	, [CreatorUserId]
	, [CreationTime]
) VALUES (
	NEWID()
	, @WSCId0
	, @WSCInputCollection0
	, @WSCOutputCollection0
	, @WSCMapping0
	, @CreatorUserId
	, @CreationTime
)

SELECT * 
FROM [genai].[WorkflowConfigurations] WC WITH(NOLOCK)
LEFT JOIN [genai].[WorkflowDetailConfigurations] WDC WITH(NOLOCK) ON WDC.WorkflowConfigurationId = WC.Id
LEFT JOIN [genai].[WorkflowStepConfigurations] WSC WITH(NOLOCK) ON WSC.WorkflowConfigurationId = WC.Id
LEFT JOIN [genai].[WorkflowStepDetailConfigurations] WSDC WITH(NOLOCK) ON WSDC.WorkflowStepConfigurationId = WSC.Id
WHERE WC.Id = @WorkflowConfigurationId

--COMMIT
--rollback

