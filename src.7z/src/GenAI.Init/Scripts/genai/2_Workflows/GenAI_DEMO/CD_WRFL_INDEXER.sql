/*
Scripts de carga das configura��es de workflow
*/

DECLARE 
	@WorkflowConfigurationId uniqueidentifier
	, @WorkflowTypeId uniqueidentifier
	, @StatusEntityModel nvarchar(20)
	, @Code nvarchar(50)
	, @Description nvarchar(max)
	, @Title nvarchar(100)
	, @TenantId uniqueidentifier
	, @ExecutionCount bigint
	, @KafkaTopicCallback nvarchar(100)
	, @CreatorUserId bigint
	, @CreationTime datetime2(7)
	, @InputCollection nvarchar(max)

DECLARE
	@WSCId0 uniqueidentifier
	, @WSCCode0 nvarchar(50)
	, @WSCDescription0 nvarchar(max)
	, @WSCTitle0 nvarchar(100)
	, @WSCOrder0 bigint
	, @WSCComponentConfigurationId0 uniqueidentifier
	, @WSCParentId0 uniqueidentifier
	, @WSCInputCollection0 nvarchar(max)
	, @WSCOutputCollection0 nvarchar(max)
	, @WSCMapping0 nvarchar(max) = null


/*
SCRIPT PARA CRIA��O DE WORKFLOW CD_WRFL_INDEXER
*/
BEGIN TRAN

/* Vari�veis do WorkflowConfiguration */
SELECT 
	@WorkflowConfigurationId = '23B46D73-7420-448A-B369-557792BF049D' --SELECT NEWID()
	, @WorkflowTypeId = 'B3B9DE20-3A06-40FA-A1A0-312740F82371'
	, @StatusEntityModel = 'ACTIVE'
	, @Code = 'CD_WRFL_INDEXER_GENAI'
	, @Description = 'Workflow de Indexa��o'
	, @Title = 'Workflow de Indexa��o'
	, @TenantId = 'C81F4DF7-1762-4970-BC2E-036A4A988DFB'
	, @ExecutionCount = 0
	, @KafkaTopicCallback = null
	, @CreatorUserId = 1
	, @CreationTime = GETDATE()
	, @InputCollection = '{
      "properties": [
        {
          "workflow_step_id": "386DA03C-5951-4F93-A616-A27F317D43D4",
          "workflow_step_order": 0,
          "workflow_step_property": {
            "properties": [
              {
                "name": "CD_INDEXER_document_id_string",
                "type_property": "string",
                "label_property": null,
                "full_path": "CD_INDEXER_document_id_string",
                "format_property": null,
                "enum": null,
                "required": true,
                "default_value": "{{CD_INDEXER_document_id_string}}",
                "actual_value": null,
                "title": null,
                "description": "ID do documento.",
                "items": null,
                "child_properties": null
              },
              {
                "name": "CD_INDEXER_document_file_name_string",
                "type_property": "string",
                "label_property": null,
                "full_path": "CD_INDEXER_document_file_name_string",
                "format_property": null,
                "enum": null,
                "required": true,
                "default_value": "{{CD_INDEXER_document_file_name_string}}",
                "actual_value": null,
                "title": null,
                "description": "Nome do arquivo do documento.",
                "items": null,
                "child_properties": null
              },
              {
                "name": "CD_INDEXER_container_string",
                "type_property": "string",
                "label_property": null,
                "full_path": "CD_INDEXER_container_string",
                "format_property": null,
                "enum": null,
                "required": true,
                "default_value": "{{CD_INDEXER_container_string}}",
                "actual_value": null,
                "title": null,
                "description": "Nome do cont�iner.",
                "items": null,
                "child_properties": null
              },
              {
                "name": "CD_INDEXER_ocr_boolean",
                "type_property": "boolean",
                "label_property": null,
                "full_path": "CD_INDEXER_ocr_boolean",
                "format_property": null,
                "enum": null,
                "required": true,
                "default_value": "{{CD_INDEXER_ocr_boolean}}",
                "actual_value": null,
                "title": null,
                "description": "Flag para OCR.",
                "items": null,
                "child_properties": null
              },
			  {
			  "name": "CD_INDEXER_indexName_string",
			  "type_property": "string",
			  "label_property": null,
			  "full_path": "CD_INDEXER_indexName_string",
			  "format_property": null,
			  "enum": null,
			  "required": true,
			  "default_value": "{{CD_INDEXER_indexName_string}}",
			  "actual_value": null,
			  "title": null,
			  "description": "Nome do �ndice.",
			  "items": null,
			  "child_properties": null
			}
            ]
          }
        }
      ]
    }
'
	
/* Vari�veis do WorkflowStepConfiguration */
SELECT
	/* Vari�veis step 0 */
	@WSCId0 = '386DA03C-5951-4F93-A616-A27F317D43D4' --newid()
	, @WSCCode0 = 'CD_ST_0_INDEXER_GENAI'
	, @WSCDescription0 = 'Etapa de indexa��o'
	, @WSCTitle0 = 'Etapa indexa��o'
	, @WSCOrder0 = 0
	, @WSCComponentConfigurationId0 = (SELECT [Id] FROM [genai].[ComponentConfigurations] CC WHERE CC.Code = 'CD_INDEXER') -- '9c3a6495-b6ab-4b01-8e97-0c44c8bb1065'
	, @WSCParentId0 = (SELECT [Id] FROM [genai].[WorkflowStepConfigurations] WSC WHERE WSC.Code = '')
	, @WSCInputCollection0 = '{
  "input": {
    "json_schema": {
      "$schema": "http://json-schema.org/draft-07/schema#",
      "type": "object",
      "properties": {
        "CD_INDEXER_document_id_string": {
          "type": "string",
          "description": "ID do documento.",
          "default": "{{CD_INDEXER_document_id_string}}"
        },
        "CD_INDEXER_cosmo_container_document_string": {
          "type": "string",
          "description": "Nome do arquivo do documento.",
          "default": "{{CD_INDEXER_cosmo_container_document_string}}"
        },
        "CD_INDEXER_cosmo_database_document_string": {
          "type": "string",
          "description": "Nome do arquivo do documento.",
          "default": "{{CD_INDEXER_cosmo_database_document_string}}"
        },
        "CD_INDEXER_document_file_name_string": {
          "type": "string",
          "description": "Nome do arquivo do documento.",
          "default": "{{CD_INDEXER_document_file_name_string}}"
        },
        "CD_INDEXER_indexName_string": {
          "type": "string",
          "description": "Nome do �ndice.",
          "default": "{{CD_INDEXER_indexName_string}}"
        },
        "CD_INDEXER_container_string": {
          "type": "string",
          "description": "Nome do cont�iner.",
          "default": "{{CD_INDEXER_container_string}}"
        },
        "CD_INDEXER_ocr_boolean": {
          "type": "boolean",
          "description": "Flag para OCR.",
          "default": "{{CD_INDEXER_ocr_boolean}}"
        }
      },
      "required": [
        "CD_INDEXER_document_id_string",
        "CD_INDEXER_cosmo_container_document_string",
        "CD_INDEXER_cosmo_database_document_string",
        "CD_INDEXER_document_file_name_string",
        "CD_INDEXER_indexName_string",
        "CD_INDEXER_container_string",
        "CD_INDEXER_ocr_boolean"
      ]
    },
    "json_schema_sample": {
      "CD_INDEXER_document_id_string": "c6648aeb-9ce6-41ac-be0a-a21804805326",
      "CD_INDEXER_cosmo_container_document_string": "CosmosContainer",
      "CD_INDEXER_cosmo_database_document_string": "CosmosContainer",
      "CD_INDEXER_document_file_name_string": "CF88_Livro_EC91_2016.pdf",
      "CD_INDEXER_indexName_string": "idx-documents",
      "CD_INDEXER_container_string": "squad5",
      "CD_INDEXER_ocr_boolean": true
    },
    "default_configuration": null,
    "property_configuration": {
      "properties": [
        {
          "name": "CD_INDEXER_document_id_string",
          "type_property": "string",
          "label_property": null,
          "full_path": "CD_INDEXER_document_id_string",
          "format_property": null,
          "enum": null,
          "required": true,
          "default_value": "{{CD_INDEXER_document_id_string}}",
          "actual_value": null,
          "title": null,
          "description": "ID do documento.",
          "items": null,
          "child_properties": null
        },
        {
          "name": "CD_INDEXER_cosmo_container_document_string",
          "type_property": "string",
          "label_property": null,
          "full_path": "CD_INDEXER_cosmo_container_document_string",
          "format_property": null,
          "enum": null,
          "required": true,
          "default_value": "documents",
          "actual_value": null,
          "title": null,
          "description": "Nome do arquivo do documento.",
          "items": null,
          "child_properties": null
        },
        {
          "name": "CD_INDEXER_cosmo_database_document_string",
          "type_property": "string",
          "label_property": null,
          "full_path": "CD_INDEXER_cosmo_database_document_string",
          "format_property": null,
          "enum": null,
          "required": true,
          "default_value": "db-squad5",
          "actual_value": null,
          "title": null,
          "description": "Nome do arquivo do documento.",
          "items": null,
          "child_properties": null
        },
        {
          "name": "CD_INDEXER_document_file_name_string",
          "type_property": "string",
          "label_property": null,
          "full_path": "CD_INDEXER_document_file_name_string",
          "format_property": null,
          "enum": null,
          "required": true,
          "default_value": "{{CD_INDEXER_document_file_name_string}}",
          "actual_value": null,
          "title": null,
          "description": "Nome do arquivo do documento.",
          "items": null,
          "child_properties": null
        },
        {
          "name": "CD_INDEXER_indexName_string",
          "type_property": "string",
          "label_property": null,
          "full_path": "CD_INDEXER_indexName_string",
          "format_property": null,
          "enum": null,
          "required": true,
          "default_value": "{{CD_INDEXER_indexName_string}}",
          "actual_value": null,
          "title": null,
          "description": "Nome do �ndice.",
          "items": null,
          "child_properties": null
        },
        {
          "name": "CD_INDEXER_container_string",
          "type_property": "string",
          "label_property": null,
          "full_path": "CD_INDEXER_container_string",
          "format_property": null,
          "enum": null,
          "required": true,
          "default_value": "{{CD_INDEXER_container_string}}",
          "actual_value": null,
          "title": null,
          "description": "Nome do cont�iner.",
          "items": null,
          "child_properties": null
        },
        {
          "name": "CD_INDEXER_ocr_boolean",
          "type_property": "boolean",
          "label_property": null,
          "full_path": "CD_INDEXER_ocr_boolean",
          "format_property": null,
          "enum": null,
          "required": true,
          "default_value": "{{CD_INDEXER_ocr_boolean}}",
          "actual_value": null,
          "title": null,
          "description": "Flag para OCR.",
          "items": null,
          "child_properties": null
        }
      ]
    }
  }
}
'
	, @WSCOutputCollection0 = '{
  "output": {
    "json_schema": {
      "$schema": "http://json-schema.org/draft-07/schema#",
      "type": "object",
      "properties": {
        "CD_INDEXER_output_list_array": {
          "type": "array",
          "items": { "type": "string" },
          "title": "Output List",
          "description": "Lista de sa�da"
        }
      },
      "required": ["CD_INDEXER_output_list_array"]
    },
    "json_schema_sample": {
      "CD_INDEXER_output_list_array": ["valor1", "valor2"]
    },
    "default_configuration": null,
    "property_configuration": {
      "properties": [
        {
          "name": "CD_INDEXER_output_list_array",
          "type_property": "array",
          "label_property": null,
          "full_path": "CD_INDEXER_output_list_array",
          "format_property": null,
          "enum": null,
          "required": true,
          "default_value": null,
          "actual_value": null,
          "title": "Output List",
          "description": "Lista de sa�da",
          "items": { "type_item": "string", "properties": null },
          "child_properties": []
        }
      ]
    }
  },
  "partial_outputs": []
}
'
	, @WSCMapping0 = null


INSERT INTO [genai].[WorkflowConfigurations] 
(
	[Id]
	, [StatusEntityModel]
	, [Code]
	, [Description]
	, [Title]
	, [TenantId]
	, [ExecutionCount]
	, [KafkaTopicCallback]
	, [CreatorUserId]
	, [CreationTime]
	, [Type]
	, [WorkflowTypeId]
) VALUES (
	@WorkflowConfigurationId
	, @StatusEntityModel
	, @Code
	, @Description
	, @Title
	, @TenantId
	, @ExecutionCount
	, @KafkaTopicCallback
	, @CreatorUserId
	, @CreationTime
	, NULL
	, @WorkflowTypeId
)
INSERT INTO [genai].[WorkflowDetailConfigurations]
(
	[Id]
	, [WorkflowConfigurationId]
    , [Input]
    , [CreatorUserId]
    , [CreationTime]
) VALUES (
	NEWID()
	, @WorkflowConfigurationId
	, @InputCollection
	, @CreatorUserId
	, @CreationTime
)

INSERT INTO [genai].[WorkflowStepConfigurations]
(
	[Id]
	, [StatusEntityModel]
	, [Code]
	, [Description]
	, [Title]
	, [Order]
	, [WorkflowConfigurationId]
	, [ComponentConfigurationId]
	, [WorkflowStepConfigurationParentId]
	, [CreatorUserId]
	, [CreationTime]
) VALUES (
	@WSCId0
	, @StatusEntityModel
	, @WSCCode0
	, @WSCDescription0
	, @WSCTitle0
	, @WSCOrder0
	, @WorkflowConfigurationId
	, @WSCComponentConfigurationId0
	, @WSCParentId0
	, @CreatorUserId
	, @CreationTime
)

INSERT INTO [genai].[WorkflowStepDetailConfigurations]
(
	[Id]
	, [WorkflowStepConfigurationId]
	, [Input]
	, [Output]
	, [Mapping]
	, [CreatorUserId]
	, [CreationTime]
) VALUES (
	NEWID()
	, @WSCId0
	, @WSCInputCollection0
	, @WSCOutputCollection0
	, @WSCMapping0
	, @CreatorUserId
	, @CreationTime
)

SELECT * 
FROM [genai].[WorkflowConfigurations] WC WITH(NOLOCK)
LEFT JOIN [genai].[WorkflowDetailConfigurations] WDC WITH(NOLOCK) ON WDC.WorkflowConfigurationId = WC.Id
LEFT JOIN [genai].[WorkflowStepConfigurations] WSC WITH(NOLOCK) ON WSC.WorkflowConfigurationId = WC.Id
LEFT JOIN [genai].[WorkflowStepDetailConfigurations] WSDC WITH(NOLOCK) ON WSDC.WorkflowStepConfigurationId = WSC.Id
WHERE WC.Id = @WorkflowConfigurationId

--COMMIT

