/*
Scripts de carga das configura��es de workflow
*/

DECLARE 
	@WorkflowConfigurationId uniqueidentifier
	, @WorkflowTypeId uniqueidentifier
	, @StatusEntityModel nvarchar(20)
	, @Code nvarchar(50)
	, @Description nvarchar(max)
	, @Title nvarchar(100)
	, @TenantId uniqueidentifier
	, @ExecutionCount bigint
	, @KafkaTopicCallback nvarchar(100)
	, @CreatorUserId bigint
	, @CreationTime datetime2(7)
	, @InputCollection nvarchar(max)

DECLARE
	@WSCId0 uniqueidentifier
	, @WSCCode0 nvarchar(50)
	, @WSCDescription0 nvarchar(max)
	, @WSCTitle0 nvarchar(100)
	, @WSCOrder0 bigint
	, @WSCComponentConfigurationId0 uniqueidentifier
	, @WSCParentId0 uniqueidentifier
	, @WSCInputCollection0 nvarchar(max)
	, @WSCOutputCollection0 nvarchar(max)
	, @WSCMapping0 nvarchar(max) = null


/*
SCRIPT PARA CRIA��O DE WORKFLOW CD_WRFL_QA
*/
BEGIN TRAN

/* Vari�veis do WorkflowConfiguration */
SELECT 
	@WorkflowConfigurationId = 'CEE8BF47-E71F-400D-B03F-8674369E192D' --SELECT NEWID()
	, @WorkflowTypeId = '30E302A1-511F-422B-8EBE-126941EFB353'
	, @StatusEntityModel = 'ACTIVE'
	, @Code = 'CD_WRFL_CLASSIFICATION_GENAI'
	, @Description = 'Workflow Classification'
	, @Title = 'Workflow Classification'
	, @TenantId = 'C81F4DF7-1762-4970-BC2E-036A4A988DFB'
	, @ExecutionCount = 0
	, @KafkaTopicCallback = null
	, @CreatorUserId = 1
	, @CreationTime = GETDATE()
	, @InputCollection = '{
        "properties": [
            {
                "workflow_step_id": "78EDC25E-D0D6-4072-B28D-5A157621B715",
                "workflow_step_order": 0,
                "workflow_step_property": {
                    "properties": [
                        {
                            "name": "CD_CLASSIFICATION_input_text_string",
                            "type_property": "string",
                            "label_property": null,
                            "full_path": "CD_CLASSIFICATION_input_text_string",
                            "format_property": null,
                            "enum": null,
                            "required": true,
                            "default_value": "{{CD_CLASSIFICATION_input_text_string}}",
                            "actual_value": null,
                            "title": "Texto a ser classificado",
                            "description": "Texto a ser classificado",
                            "items": null,
                            "child_properties": null
                        }
                    ]
                }
            }
        ]
    }'
	
/* Vari�veis do WorkflowStepConfiguration */
SELECT
	/* Vari�veis step 0 */
	@WSCId0 = '78EDC25E-D0D6-4072-B28D-5A157621B715' --newid()
	, @WSCCode0 = 'CD_ST_0_CLASSIFICATION_GENAI'
	, @WSCDescription0 = 'Etapa de Classifica��o'
	, @WSCTitle0 = 'Etapa Classifica��o'
	, @WSCOrder0 = 0
	, @WSCComponentConfigurationId0 = (SELECT [Id] FROM [genai].[ComponentConfigurations] CC WHERE CC.Code = 'CD_CLASSIFICATION') -- '9c3a6495-b6ab-4b01-8e97-0c44c8bb1065'
	, @WSCParentId0 = (SELECT [Id] FROM [genai].[WorkflowStepConfigurations] WSC WHERE WSC.Code = '')
	, @WSCInputCollection0 = '{
        "input": {
            "json_schema": {
                "$schema": "http://json-schema.org/draft-07/schema#",
                "type": "object",
                "properties": {
                    "CD_CLASSIFICATION_open_ai_api_base_string": {
                        "type": "string",
                        "default": "{{CD_CLASSIFICATION_open_ai_api_base_string}}",
                        "description": "Open AI URL (URL da Open AI)",
                        "title": "Open AI URL"
                    },
                    "CD_CLASSIFICATION_open_ai_api_version_string": {
                        "type": "string",
                        "default": "{{CD_CLASSIFICATION_open_ai_api_version_string}}",
                        "description": "Open AI API Version",
                        "title": "Open AI API Version"
                    },
                    "CD_CLASSIFICATION_open_ai_api_type_string": {
                        "type": "string",
                        "default": "{{CD_CLASSIFICATION_open_ai_api_type_string}}",
                        "description": "Open AI API Type",
                        "title": "Open AI API Type"
                    },
                    "CD_CLASSIFICATION_open_ai_api_key_string": {
                        "type": "string",
                        "default": "{{CD_CLASSIFICATION_open_ai_api_key_string}}",
                        "description": "Open AI Key (Chave da Open AI)",
                        "title": "Open AI Key"
                    },
                    "CD_CLASSIFICATION_input_text_string": {
                        "type": "string",
                        "default": "{{CD_CLASSIFICATION_input_text_string}}",
                        "description": "Texto a ser classificado",
                        "title": "Texto a ser classificado"
                    },
                    "CD_CLASSIFICATION_prompt_string": {
                        "type": "string",
                        "default": "{{CD_CLASSIFICATION_prompt_string}}",
                        "description": "prompt base para classifica��o",
                        "title": "Prompt base para classifica��o"
                    },
                    "CD_CLASSIFICATION_system_prompt_string": {
                        "type": "string",
                        "default": "{{CD_CLASSIFICATION_system_prompt_string}}",
                        "description": "Texto de prompt do sistema",
                        "title": "Texto de prompt do sistema"
                    },
                    "CD_CLASSIFICATION_list_classification": {
                        "type": "array",
                        "items": {
                            "type": "string"
                        },
                        "default": [],
                        "description": "Array dos itens possiveis para classifica��o",
                        "title": "Array dos itens possiveis para classifica��oo"
                    },
                    "CD_CLASSIFICATION_open_ai_chat_completion_body_object": {
                        "type": "object",
                        "properties": {
                            "CD_CLASSIFICATION_engine_string": {
                                "type": "string",
                                "enum": [
                                    "gpt-35-turbo-16k",
                                    "gpt-4-32k"
                                ],
                                "default": "gpt-4-32k",
                                "description": "Vers�o do modelo da Open AI",
                                "title": "Vers�o do modelo da Open AI"
                            },
                            "CD_CLASSIFICATION_messages_array": {
                                "type": "array",
                                "items": {
                                    "type": "string"
                                },
                                "default": [],
                                "description": "Array de mensagens para conversa��o",
                                "title": "Array de mensagens para conversa��o"
                            },
                            "CD_CLASSIFICATION_temperature_number": {
                                "type": "number",
                                "default": 0.5,
                                "description": "Par�metro de temperatura para gera��o de texto",
                                "title": "Par�metro de temperatura para gera��o de texto"
                            },
                            "CD_CLASSIFICATION_max_tokens_number": {
                                "type": "number",
                                "default": 2000,
                                "description": "N�mero m�ximo de tokens a serem gerados",
                                "title": "N�mero m�ximo de tokens a serem gerados"
                            },
                            "CD_CLASSIFICATION_top_p_number": {
                                "type": "number",
                                "default": 0.95,
                                "description": "Par�metro de top-p sampling",
                                "title": "Par�metro de top-p sampling"
                            },
                            "CD_CLASSIFICATION_frequency_penalty_number": {
                                "type": "number",
                                "default": 0,
                                "description": "Penalidade de frequ�ncia para gera��o de texto",
                                "title": "Penalidade de frequ�ncia para gera��o de texto"
                            },
                            "CD_CLASSIFICATION_presence_penalty_number": {
                                "type": "number",
                                "default": 0,
                                "description": "Penalidade de presen�a para gera��o de texto",
                                "title": "Penalidade de presen�a para gera��o de texto"
                            }
                        },
                        "required": [
                            "CD_CLASSIFICATION_engine_string",
                            "CD_CLASSIFICATION_temperature_number",
                            "CD_CLASSIFICATION_max_tokens_number",
                            "CD_CLASSIFICATION_top_p_number",
                            "CD_CLASSIFICATION_frequency_penalty_number",
                            "CD_CLASSIFICATION_presence_penalty_number"
                        ],
                        "description": "Corpo da requisi��o para a API de gera��o de chat da Open AI",
                        "title": "Corpo da requisi��o para a API de gera��o de chat da Open AI"
                    }
                },
                "required": [
                    "CD_CLASSIFICATION_open_ai_api_base_string",
                    "CD_CLASSIFICATION_open_ai_api_version_string",
                    "CD_CLASSIFICATION_open_ai_api_key_string",
                    "CD_CLASSIFICATION_open_ai_api_type_string",
                    "CD_CLASSIFICATION_input_text_string",
                    "CD_CLASSIFICATION_prompt_string",
                    "CD_CLASSIFICATION_system_prompt_string",
                    "CD_CLASSIFICATION_open_ai_chat_completion_body_object",
                    "CD_CLASSIFICATION_list_classification"
                ]
            },
            "json_schema_sample": {
                "CD_CLASSIFICATION_open_ai_api_base_string": "https://api.openai.com/v1/engines/davinci/completions",
                "CD_CLASSIFICATION_open_ai_api_key_string": "OPEN_AI_KEY",
                "CD_CLASSIFICATION_open_ai_api_version_string": "2023-07-01-preview",
                "CD_CLASSIFICATION_open_ai_api_type_string": "azure",
                "CD_CLASSIFICATION_input_text_string": "Texto de sa�da para exemplo de mapping",
                "CD_CLASSIFICATION_prompt_string": "Logo abaixo segue um prompt e um template schema para o mapeamento de dados...",
                "CD_CLASSIFICATION_system_prompt_string": "Quero que voc� resuma o texto a 100 palavras.",
                "CD_CLASSIFICATION_list_classification": [
                    "Valor1",
                    "Valor2"
                ],
                "CD_CLASSIFICATION_open_ai_chat_completion_body_object": {
                    "CD_CLASSIFICATION_engine_string": "gpt-4-32k",
                    "CD_CLASSIFICATION_messages_array": [],
                    "CD_CLASSIFICATION_temperature_number": 0.5,
                    "CD_CLASSIFICATION_max_tokens_number": 2000,
                    "CD_CLASSIFICATION_top_p_number": 0.95,
                    "CD_CLASSIFICATION_frequency_penalty_number": 0,
                    "CD_CLASSIFICATION_presence_penalty_number": 0
                }
            },
            "default_configuration": null,
            "property_configuration": {
                "properties": [
                    {
                        "name": "CD_CLASSIFICATION_open_ai_api_base_string",
                        "type_property": "string",
                        "label_property": null,
                        "full_path": "CD_CLASSIFICATION_open_ai_api_base_string",
                        "format_property": null,
                        "enum": null,
                        "required": true,
                        "default_value": "https://oai-genai-pr001.openai.azure.com/",
                        "actual_value": null,
                        "title": "Open AI URL",
                        "description": "Open AI URL (URL da Open AI)",
                        "items": null,
                        "child_properties": null
                    },
                    {
                        "name": "CD_CLASSIFICATION_open_ai_api_version_string",
                        "type_property": "string",
                        "label_property": null,
                        "full_path": "CD_CLASSIFICATION_open_ai_api_version_string",
                        "format_property": null,
                        "enum": null,
                        "required": true,
                        "default_value": "2023-07-01-preview",
                        "actual_value": null,
                        "title": "Open AI API Version",
                        "description": "Open AI API Version",
                        "items": null,
                        "child_properties": null
                    },
                    {
                        "name": "CD_CLASSIFICATION_open_ai_api_type_string",
                        "type_property": "string",
                        "label_property": null,
                        "full_path": "CD_CLASSIFICATION_open_ai_api_type_string",
                        "format_property": null,
                        "enum": null,
                        "required": true,
                        "default_value": "azure",
                        "actual_value": null,
                        "title": "Open AI API Type",
                        "description": "Open AI API Type",
                        "items": null,
                        "child_properties": null
                    },
                    {
                        "name": "CD_CLASSIFICATION_open_ai_api_key_string",
                        "type_property": "string",
                        "label_property": null,
                        "full_path": "CD_CLASSIFICATION_open_ai_api_key_string",
                        "format_property": null,
                        "enum": null,
                        "required": true,
                        "default_value": "OPENAI-API-KEY4",
                        "actual_value": null,
                        "title": "Open AI Key",
                        "description": "Open AI Key (Chave da Open AI)",
                        "items": null,
                        "child_properties": null
                    },
                    {
                        "name": "CD_CLASSIFICATION_input_text_string",
                        "type_property": "string",
                        "label_property": null,
                        "full_path": "CD_CLASSIFICATION_input_text_string",
                        "format_property": null,
                        "enum": null,
                        "required": true,
                        "default_value": "{{CD_CLASSIFICATION_input_text_string}}",
                        "actual_value": null,
                        "title": "Texto a ser classificado",
                        "description": "Texto a ser classificado",
                        "items": null,
                        "child_properties": null
                    },
                    {
                        "name": "CD_CLASSIFICATION_prompt_string",
                        "type_property": "string",
                        "label_property": null,
                        "full_path": "CD_CLASSIFICATION_prompt_string",
                        "format_property": null,
                        "enum": null,
                        "required": true,
                        "default_value": "\n            Pense passo a passo;\n            Voc� receber� um ''documento'' e uma ''lista'' delimitados por backticks;\n            Considere ''prazo'' como a data limite para resposta;\n            Considere ''reitera��o'' como qualquer men��o �s palavras reitero, reiterando ou similares e sin�nimos;\n            Repita os 7 passos abaixo 2 vezes;\n            1- Avalie qual o prazo descrito no documento;\n            2- Avalie qual o n�mero de dias indicados no prazo;  \n            3- Avalie se o n�mero de dias � maior, menor ou igual a 5;\n            4- Avalie se no ''documento'' existe alguma men��o � multas;\n            5- Avalie se no ''documento'' existe alguma men��o � reitera��o ou palavras similares ou sin�nimas;\n            6- Reflita: Qual � o n�mero de dias indicado no prazo? � maior, menor ou igual a 5? Existe men��o � multas? � uma reitera��o? Ent�o qual � o item da lista? Porque voc� fez esta escolha?\n            7- Baseado nas avalia��es anteriores escolha apenas um item da lista ```{CD_CLASSIFICATION_list_classification}``` para sua resposta;\n            Diretrizes para a sua resposta:\n                N�o fa�a infer�ncias;\n                Documento: ```{CD_CLASSIFICATION_input_text_string}```;\n                Responda: qual o item da lista?\n                Responda apenas com o item da lista que voc� selecionou.\n            ",
                        "actual_value": null,
                        "title": "Prompt base para classifica��o",
                        "description": "prompt base para classifica��o",
                        "items": null,
                        "child_properties": null
                    },
                    {
                        "name": "CD_CLASSIFICATION_system_prompt_string",
                        "type_property": "string",
                        "label_property": null,
                        "full_path": "CD_CLASSIFICATION_system_prompt_string",
                        "format_property": null,
                        "enum": null,
                        "required": true,
                        "default_value": "Sistema: Voc� � um assistente jur�dico de IA que fornece informa��es sobre of�cios judiciais. N�o deixe nenhuma informa��o passar. RESPONDA APENAS A CLASSIFICA��O APROPRIADA, NADA MAIS.",
                        "actual_value": null,
                        "title": "Texto de prompt do sistema",
                        "description": "Texto de prompt do sistema",
                        "items": null,
                        "child_properties": null
                    },
                    {
                        "name": "CD_CLASSIFICATION_list_classification",
                        "type_property": "array",
                        "label_property": null,
                        "full_path": "CD_CLASSIFICATION_list_classification",
                        "format_property": null,
                        "enum": null,
                        "required": true,
                        "default_value": [
                            "SEM PRAZO",
                            "PRAZO ACIMA DE 5 DIAS",
                            "PRAZO ATE 5 DIAS",
                            "REITERACAO",
                            "VALOR DE MULTA"
                        ],
                        "actual_value": null,
                        "title": "Array dos itens possiveis para classifica��oo",
                        "description": "Array dos itens possiveis para classifica��o",
                        "items": {
                            "type_item": "string",
                            "properties": null
                        },
                        "child_properties": []
                    },
                    {
                        "name": "CD_CLASSIFICATION_open_ai_chat_completion_body_object",
                        "type_property": "object",
                        "label_property": null,
                        "full_path": "CD_CLASSIFICATION_open_ai_chat_completion_body_object",
                        "format_property": null,
                        "enum": null,
                        "required": true,
                        "default_value": null,
                        "actual_value": null,
                        "title": "Corpo da requisi��o para a API de gera��o de chat da Open AI",
                        "description": "Corpo da requisi��o para a API de gera��o de chat da Open AI",
                        "items": null,
                        "child_properties": [
                            {
                                "name": "CD_CLASSIFICATION_engine_string",
                                "type_property": "string",
                                "label_property": null,
                                "full_path": "CD_CLASSIFICATION_open_ai_chat_completion_body_object.CD_CLASSIFICATION_engine_string",
                                "format_property": null,
                                "enum": [
                                    "gpt-35-turbo-16k",
                                    "gpt-4-32k"
                                ],
                                "required": true,
                                "default_value": "gpt-4-32k",
                                "actual_value": null,
                                "title": "Vers�o do modelo da Open AI",
                                "description": "Vers�o do modelo da Open AI",
                                "items": null,
                                "child_properties": null
                            },
                            {
                                "name": "CD_CLASSIFICATION_messages_array",
                                "type_property": "array",
                                "label_property": null,
                                "full_path": "CD_CLASSIFICATION_open_ai_chat_completion_body_object.CD_CLASSIFICATION_messages_array",
                                "format_property": null,
                                "enum": null,
                                "required": false,
                                "default_value": [],
                                "actual_value": null,
                                "title": "Array de mensagens para conversa��o",
                                "description": "Array de mensagens para conversa��o",
                                "items": {
                                    "type_item": "string",
                                    "properties": null
                                },
                                "child_properties": []
                            },
                            {
                                "name": "CD_CLASSIFICATION_temperature_number",
                                "type_property": "number",
                                "label_property": null,
                                "full_path": "CD_CLASSIFICATION_open_ai_chat_completion_body_object.CD_CLASSIFICATION_temperature_number",
                                "format_property": null,
                                "enum": null,
                                "required": true,
                                "default_value": 0,
                                "actual_value": null,
                                "title": "Par�metro de temperatura para gera��o de texto",
                                "description": "Par�metro de temperatura para gera��o de texto",
                                "items": null,
                                "child_properties": null
                            },
                            {
                                "name": "CD_CLASSIFICATION_max_tokens_number",
                                "type_property": "number",
                                "label_property": null,
                                "full_path": "CD_CLASSIFICATION_open_ai_chat_completion_body_object.CD_CLASSIFICATION_max_tokens_number",
                                "format_property": null,
                                "enum": null,
                                "required": true,
                                "default_value": 100,
                                "actual_value": null,
                                "title": "N�mero m�ximo de tokens a serem gerados",
                                "description": "N�mero m�ximo de tokens a serem gerados",
                                "items": null,
                                "child_properties": null
                            },
                            {
                                "name": "CD_CLASSIFICATION_top_p_number",
                                "type_property": "number",
                                "label_property": null,
                                "full_path": "CD_CLASSIFICATION_open_ai_chat_completion_body_object.CD_CLASSIFICATION_top_p_number",
                                "format_property": null,
                                "enum": null,
                                "required": true,
                                "default_value": 0.95,
                                "actual_value": null,
                                "title": "Par�metro de top-p sampling",
                                "description": "Par�metro de top-p sampling",
                                "items": null,
                                "child_properties": null
                            },
                            {
                                "name": "CD_CLASSIFICATION_frequency_penalty_number",
                                "type_property": "number",
                                "label_property": null,
                                "full_path": "CD_CLASSIFICATION_open_ai_chat_completion_body_object.CD_CLASSIFICATION_frequency_penalty_number",
                                "format_property": null,
                                "enum": null,
                                "required": true,
                                "default_value": 0,
                                "actual_value": null,
                                "title": "Penalidade de frequ�ncia para gera��o de texto",
                                "description": "Penalidade de frequ�ncia para gera��o de texto",
                                "items": null,
                                "child_properties": null
                            },
                            {
                                "name": "CD_CLASSIFICATION_presence_penalty_number",
                                "type_property": "number",
                                "label_property": null,
                                "full_path": "CD_CLASSIFICATION_open_ai_chat_completion_body_object.CD_CLASSIFICATION_presence_penalty_number",
                                "format_property": null,
                                "enum": null,
                                "required": true,
                                "default_value": 0,
                                "actual_value": null,
                                "title": "Penalidade de presen�a para gera��o de texto",
                                "description": "Penalidade de presen�a para gera��o de texto",
                                "items": null,
                                "child_properties": null
                            }
                        ]
                    }
                ]
            }
        }
    }'
	, @WSCOutputCollection0 = '{
        "output": {
            "json_schema": {
                "$schema": "http://json-schema.org/draft-07/schema#",
                "type": "object",
                "properties": {
                    "CD_CLASSIFICATION_output_text_string": {
                        "type": "string",
                        "default": "",
                        "title": "Output Text",
                        "description": "Texto de sa�da"
                    },
                    "CD_CLASSIFICATION_metadata": {
                        "type": "object",
                        "properties": {
                            "prompt_tokens_string": {
                                "type": "string",
                                "default": "",
                                "title": "Prompt Tokens",
                                "description": "Prompt Tokens"
                            },
                            "completion_tokens_string": {
                                "type": "string",
                                "default": "",
                                "title": "Completion Tokens",
                                "description": "Completion Tokens"
                            },
                            "total_tokens_string": {
                                "type": "string",
                                "default": "",
                                "title": "Total Tokens",
                                "description": "Total Tokens"
                            }
                        },
                        "required": [
                            "prompt_tokens_string",
                            "completion_tokens_string",
                            "total_tokens_string"
                        ]
                    }
                },
                "required": [
                    "CD_CLASSIFICATION_output_text_string",
                    "CD_CLASSIFICATION_metadata"
                ]
            },
            "json_schema_sample": {
                "CD_CLASSIFICATION_output_text_string": "Este � o texto sumarizado.",
                "CD_CLASSIFICATION_metadata": {
                    "prompt_tokens_string": "Estes s�o os tokens de prompt.",
                    "completion_tokens_string": "Estes s�o os tokens de conclus�o.",
                    "total_tokens_string": "100"
                }
            },
            "default_configuration": null,
            "property_configuration": {
                "properties": [
                    {
                        "name": "CD_CLASSIFICATION_output_text_string",
                        "type_property": "string",
                        "label_property": null,
                        "full_path": "CD_CLASSIFICATION_output_text_string",
                        "format_property": null,
                        "enum": null,
                        "required": true,
                        "default_value": "",
                        "actual_value": null,
                        "title": "Output Text",
                        "description": "Texto de sa�da",
                        "items": null,
                        "child_properties": null
                    },
                    {
                        "name": "CD_CLASSIFICATION_metadata",
                        "type_property": "object",
                        "label_property": null,
                        "full_path": "CD_CLASSIFICATION_metadata",
                        "format_property": null,
                        "enum": null,
                        "required": true,
                        "default_value": null,
                        "actual_value": null,
                        "title": null,
                        "description": null,
                        "items": null,
                        "child_properties": [
                            {
                                "name": "prompt_tokens_string",
                                "type_property": "string",
                                "label_property": null,
                                "full_path": "CD_CLASSIFICATION_metadata.prompt_tokens_string",
                                "format_property": null,
                                "enum": null,
                                "required": true,
                                "default_value": "",
                                "actual_value": null,
                                "title": "Prompt Tokens",
                                "description": "Prompt Tokens",
                                "items": null,
                                "child_properties": null
                            },
                            {
                                "name": "completion_tokens_string",
                                "type_property": "string",
                                "label_property": null,
                                "full_path": "CD_CLASSIFICATION_metadata.completion_tokens_string",
                                "format_property": null,
                                "enum": null,
                                "required": true,
                                "default_value": "",
                                "actual_value": null,
                                "title": "Completion Tokens",
                                "description": "Completion Tokens",
                                "items": null,
                                "child_properties": null
                            },
                            {
                                "name": "total_tokens_string",
                                "type_property": "string",
                                "label_property": null,
                                "full_path": "CD_CLASSIFICATION_metadata.total_tokens_string",
                                "format_property": null,
                                "enum": null,
                                "required": true,
                                "default_value": "",
                                "actual_value": null,
                                "title": "Total Tokens",
                                "description": "Total Tokens",
                                "items": null,
                                "child_properties": null
                            }
                        ]
                    }
                ]
            }
        },
        "partial_outputs": []
    }'
	, @WSCMapping0 = null


INSERT INTO [genai].[WorkflowConfigurations] 
(
	[Id]
	, [StatusEntityModel]
	, [Code]
	, [Description]
	, [Title]
	, [TenantId]
	, [ExecutionCount]
	, [KafkaTopicCallback]
	, [CreatorUserId]
	, [CreationTime]
	, [Type]
	, [WorkflowTypeId]
) VALUES (
	@WorkflowConfigurationId
	, @StatusEntityModel
	, @Code
	, @Description
	, @Title
	, @TenantId
	, @ExecutionCount
	, @KafkaTopicCallback
	, @CreatorUserId
	, @CreationTime
	, NULL
	, @WorkflowTypeId
)

INSERT INTO [genai].[WorkflowDetailConfigurations]
(
	[Id]
	, [WorkflowConfigurationId]
    , [Input]
    , [CreatorUserId]
    , [CreationTime]
) VALUES (
	NEWID()
	, @WorkflowConfigurationId
	, @InputCollection
	, @CreatorUserId
	, @CreationTime
)

INSERT INTO [genai].[WorkflowStepConfigurations]
(
	[Id]
	, [StatusEntityModel]
	, [Code]
	, [Description]
	, [Title]
	, [Order]
	, [WorkflowConfigurationId]
	, [ComponentConfigurationId]
	, [WorkflowStepConfigurationParentId]
	, [CreatorUserId]
	, [CreationTime]
) VALUES (
	@WSCId0
	, @StatusEntityModel
	, @WSCCode0
	, @WSCDescription0
	, @WSCTitle0
	, @WSCOrder0
	, @WorkflowConfigurationId
	, @WSCComponentConfigurationId0
	, @WSCParentId0
	, @CreatorUserId
	, @CreationTime
)

INSERT INTO [genai].[WorkflowStepDetailConfigurations]
(
	[Id]
	, [WorkflowStepConfigurationId]
	, [Input]
	, [Output]
	, [Mapping]
	, [CreatorUserId]
	, [CreationTime]
) VALUES (
	NEWID()
	, @WSCId0
	, @WSCInputCollection0
	, @WSCOutputCollection0
	, @WSCMapping0
	, @CreatorUserId
	, @CreationTime
)

SELECT * 
FROM [genai].[WorkflowConfigurations] WC WITH(NOLOCK)
LEFT JOIN [genai].[WorkflowDetailConfigurations] WDC WITH(NOLOCK) ON WDC.WorkflowConfigurationId = WC.Id
LEFT JOIN [genai].[WorkflowStepConfigurations] WSC WITH(NOLOCK) ON WSC.WorkflowConfigurationId = WC.Id
LEFT JOIN [genai].[WorkflowStepDetailConfigurations] WSDC WITH(NOLOCK) ON WSDC.WorkflowStepConfigurationId = WSC.Id
WHERE WC.Id = @WorkflowConfigurationId
--ROLLBACK
--COMMIT

