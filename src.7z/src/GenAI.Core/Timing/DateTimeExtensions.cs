﻿using System;

namespace GenAI.Core.Timing;

public static class DateTimeExtensions
{
    public static DateTime NowTimeZone(this DateTime now, string zone = "America/Sao_Paulo")
    {
        TimeZoneInfo timeZone = TimeZoneInfo.FindSystemTimeZoneById(zone);
        return TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, timeZone);
    }

    public static DateTime? ConvertToTimeZone(this DateTime? now, string zone = "America/Sao_Paulo")
    {
        if (now == null) return null;
        TimeZoneInfo timeZone = TimeZoneInfo.FindSystemTimeZoneById(zone);
        return TimeZoneInfo.ConvertTimeFromUtc((DateTime)now, timeZone);
    }

    public static DateTime ConvertToTimeZone(this DateTime now, string zone = "America/Sao_Paulo")
    {
        TimeZoneInfo timeZone = TimeZoneInfo.FindSystemTimeZoneById(zone);
        return TimeZoneInfo.ConvertTimeFromUtc(now, timeZone);
    }
}