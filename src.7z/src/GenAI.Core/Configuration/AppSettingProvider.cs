﻿using Abp.Configuration;
using GenAI.Crosscutting.Infra.Settings;
using System.Collections.Generic;

namespace GenAI.Core.Configuration
{
    public class AppSettingProvider : SettingProvider
    {
        public override IEnumerable<SettingDefinition> GetSettingDefinitions(SettingDefinitionProviderContext context)
        {
            return new[]
            {
                new SettingDefinition(AppSettingNames.UiTheme, "red", scopes: SettingScopes.Application | SettingScopes.Tenant | SettingScopes.User, isVisibleToClients: true),
                ///////Email////
                new SettingDefinition(Abp.Net.Mail.EmailSettingNames.Smtp.Host, GenAISettings.HostMail, scopes: SettingScopes.Application | SettingScopes.Tenant | SettingScopes.User, isVisibleToClients: true)
                ,new SettingDefinition(Abp.Net.Mail.EmailSettingNames.Smtp.UserName, GenAISettings.UserEmail, scopes: SettingScopes.Application | SettingScopes.Tenant | SettingScopes.User, isVisibleToClients: true)
                ,new SettingDefinition(Abp.Net.Mail.EmailSettingNames.Smtp.Password, GenAISettings.UserEmailPassword, scopes: SettingScopes.Application | SettingScopes.Tenant | SettingScopes.User, isVisibleToClients: true)
                ,new SettingDefinition(Abp.Net.Mail.EmailSettingNames.Smtp.Port, GenAISettings.PortMail, scopes: SettingScopes.Application | SettingScopes.Tenant | SettingScopes.User, isVisibleToClients: true)
                ,new SettingDefinition(Abp.Net.Mail.EmailSettingNames.Smtp.UseDefaultCredentials, "false", scopes: SettingScopes.Application | SettingScopes.Tenant | SettingScopes.User, isVisibleToClients: true)
                ,new SettingDefinition(Abp.Net.Mail.EmailSettingNames.Smtp.EnableSsl, "true", scopes: SettingScopes.Application | SettingScopes.Tenant | SettingScopes.User, isVisibleToClients: true)
            };
        }
    }
}


