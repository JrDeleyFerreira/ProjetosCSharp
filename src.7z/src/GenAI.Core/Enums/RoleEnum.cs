﻿
namespace GenAI.Core.Enums
{
    public enum RoleEnum
    {
        DIRECTOR = 6,
        GERENTE_GROUP_MANAGER = 7,
        CONSULTOR_SENIOR = 8,
        CONSULTOR = 9,
        ANALISTA_SENIOR = 10,
        ANALISTA_PLENO = 11,
        ANALISTA_JUNIOR = 12,
        ESTAGIARIO = 13,
        CONTRACTOR = 14
    }
}
