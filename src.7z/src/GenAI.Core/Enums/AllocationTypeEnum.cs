﻿
namespace GenAI.Core.Enums
{
    public enum AllocationTypeEnum
    {
        ASSESMENT = 2,
        DELIVERY = 3,
        SUSTENTACAO = 9
    }
}
