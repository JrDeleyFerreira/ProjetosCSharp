﻿namespace GenAI.Core.Enums
{
    public enum StatusEnum
    {
        Open = 6,
        Resolved = 1,
        PendingClient = 2,
        PendingInternal = 3,
        Reject = 4,
        Cancelled = 5
    }
}
