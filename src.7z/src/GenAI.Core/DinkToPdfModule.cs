﻿using Abp.Modules;
using Abp.Zero;
using DinkToPdf;
using DinkToPdf.Contracts;

namespace GenAI.Core
{
    [DependsOn(typeof(AbpZeroCoreModule))]
    public class DinkToPdfModule : AbpModule
    {
        public override void Initialize()
        {
            IocManager.RegisterAssemblyByConvention(typeof(DinkToPdfModule).Assembly);
        }

        public override void PostInitialize()
        {
            IocManager.IocContainer.Register(
                Castle.MicroKernel.Registration.Component
                    .For<IConverter>()
                    .UsingFactoryMethod(() => new SynchronizedConverter(new PdfTools()))
                    .LifestyleSingleton()
            );
        }
    }
}
