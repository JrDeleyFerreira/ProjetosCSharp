﻿using Abp.Extensions;
using System.Text.RegularExpressions;
using GenAI.Crosscutting.Infra.Extensions;

namespace GenAI.Core.Validation
{
    public static class ValidationHelper
    {
        public const string EmailRegex = @"^\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$";

        public static bool IsEmail(string value)
        {
            if (value.IsNullOrEmpty())
            {
                return false;
            }

            var regex = new Regex(EmailRegex);
            return regex.IsMatch(value);
        }

        public static bool IsValidCode(string codeEncrypted, string userCode)
        {
            string codeDecrypted = codeEncrypted.Decrypted();
            return userCode.ToUpper() == codeDecrypted;
        }
    }
}


