﻿using System.Collections.Generic;

namespace GenAI.Core.Resources;

public static class DataConstants
{
	public static readonly List<string> SpreadsheetTypeExtension = 
		new() { ".xlsx", ".xls", ".ods", ".csv", ".xlsm" };

	public const string MatrizSod = "matrizsod";
	public const string CollaboratorSheetName = "Colaboradores";
	public const string EmployeeSheetName = "Empregados";
}
