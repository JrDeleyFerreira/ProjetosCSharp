﻿using System;
using System.Threading.Tasks;
using Abp.Application.Services.Dto;
using GenAI.Core.Contracts.Services.Shared;
using GenAI.Crosscutting.Entities.Dto.ApiKeys;
using GenAI.Domain.Entities.ApiKey;

namespace GenAI.Core.Contracts.Services.ApiKey;

public interface IUserApiKeyDomainService : IGenAIDomainServiceBase<UserApiKey, Guid, UserApiKeyDto>
{
    Task<UserApiKeyDto> CreateUserApiKey(CreateUserApiKeyDto entity);
    Task<UserApiKeyDto> GetUserApiKeyByKey(string key);
    PagedResultDto<UserApiKeyDto> GetAllApiKeyPaged(FilterApiKeyDto filter);
    Task<bool> DeleteApiKeyAsync(Guid userApiKeyId);
    Guid? GetApiKeyByUser();

}