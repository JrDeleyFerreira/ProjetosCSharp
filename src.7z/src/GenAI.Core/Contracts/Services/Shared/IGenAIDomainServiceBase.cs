﻿using Abp.Application.Services.Dto;
using Abp.Domain.Entities;
using Abp.Domain.Services;
using GenAI.Crosscutting.Entities.Dto.Shared;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace GenAI.Core.Contracts.Services.Shared
{
    public interface IGenAIDomainServiceBase<TEntity> :
    IGenAIDomainServiceBase<TEntity, int, EntityDto<int>, EntityDto<int>>
    where TEntity : class, IEntity<int>
    {

    }
    public interface IGenAIDomainServiceBase<TEntity, TPrimaryKey> :
        IGenAIDomainServiceBase<TEntity, TPrimaryKey, EntityDto<TPrimaryKey>>
        where TEntity : class, IEntity<TPrimaryKey>
    {

    }
    public interface IGenAIDomainServiceBase<TEntity, TPrimaryKey, TEntityDto> :
        IGenAIDomainServiceBase<TEntity, TPrimaryKey, TEntityDto, TEntityDto>
        where TEntity : class, IEntity<TPrimaryKey>
        where TEntityDto : IEntityDto<TPrimaryKey>
    {

    }

    public interface IGenAIDomainServiceBase<TEntity, TPrimaryKey, TEntityDto, in TCreateInput> :
        IGenAIDomainServiceBase<TEntity, TPrimaryKey, TEntityDto, TCreateInput, TEntityDto>
        where TEntity : class, IEntity<TPrimaryKey>
        where TEntityDto : IEntityDto<TPrimaryKey>
    {

    }
    public interface IGenAIDomainServiceBase<TEntity, TPrimaryKey, TEntityDto, in TCreateInput, in TUpdateInput> :
        IGenAIDomainServiceBase<TEntity, TPrimaryKey, TEntityDto, TCreateInput, TUpdateInput, FilterPagedDto>
        where TEntity : class, IEntity<TPrimaryKey>
        where TEntityDto : IEntityDto<TPrimaryKey>
        where TUpdateInput : IEntityDto<TPrimaryKey>
    {
    }
    public interface IGenAIDomainServiceBase<TEntity, TPrimaryKey, TEntityDto, in TCreateInput, in TUpdateInput, in TFilterGetPagedInput> :
        IGenAIDomainServiceBase<TEntity, TPrimaryKey, TEntityDto, TCreateInput, TUpdateInput, TFilterGetPagedInput, EntityDto<TPrimaryKey>>
        where TEntity : class, IEntity<TPrimaryKey>
        where TEntityDto : IEntityDto<TPrimaryKey>
        where TUpdateInput : IEntityDto<TPrimaryKey>
        where TFilterGetPagedInput : FilterPagedDto
    {

    }

    public interface IGenAIDomainServiceBase<TEntity, TPrimaryKey, TEntityDto, in TCreateInput, in TUpdateInput, in TFilterGetPagedInput, TListDto> : IDomainService
        where TEntity : class, IEntity<TPrimaryKey>
        where TEntityDto : IEntityDto<TPrimaryKey>
        where TUpdateInput : IEntityDto<TPrimaryKey>
        where TFilterGetPagedInput : FilterPagedDto
        where TListDto : EntityDto<TPrimaryKey>, new()
    {
        Task<TPrimaryKey> CreateAndGetIdAsync(TEntity entity);
        Task<TPrimaryKey> CreateAndGetIdAsync(TCreateInput entityDto);
        Task<TEntity> CreateAsync(TEntity entity);
        Task<TEntity> CreateAsync(TCreateInput entityDto);
        Task<IEnumerable<TEntity>> CreateInMassAsync(IEnumerable<TEntity> entities);
        Task<IEnumerable<TEntity>> CreateInMassAsync(IEnumerable<TCreateInput> entitiesDto);
        void BulkUpdate(IList<TEntity> entities);
        void BulkInsert(IList<TEntity> entities);

        Task<TEntity> UpdateAsync(TEntity entity);
        Task<TEntity> UpdateAsync(TUpdateInput entityDto);
        Task<TEntity> UpdateAsync(TUpdateInput entityDto, TEntity entity);
        Task<IEnumerable<TEntity>> UpdateAsync(IEnumerable<TEntity> entities);

        Task DeleteAsync(TPrimaryKey id);
        Task DeleteAsync(TEntity entity);
        Task DeletesAsync(List<TPrimaryKey> ids);

        TEntity GetIncluding(TPrimaryKey id, params Expression<Func<TEntity, object>>[] propertySelectors);
        Task<IEnumerable<TEntity>> GetAllAsync();
        Task<IEnumerable<TEntity>> GetAllAsync(Func<TEntity, object> sortingExpression, bool ascending = true);
        IQueryable<TEntity> GetAll();
        IQueryable<TEntity> GetAll(Expression<Func<TEntity, object>> sortingExpression, bool ascending = true);

        Task<TEntity> GetAsync(TPrimaryKey id);
        TEntity GetSync(TPrimaryKey id);

        PagedResultDto<TEntityDto> GetAllPaged(IQueryable<TEntity> entities, int pageNumber, int itemsPerPage);
        PagedResultDto<TEntityDto> GetAllPaged(IQueryable<TEntity> entities, int pageNumber, int itemsPerPage, Expression<Func<TEntity, object>> sortingExpression, bool ascending = true);
        PagedResultDto<TEntityDto> GetAllPaged(TFilterGetPagedInput filter);

        PagedResultDto<TListDto> GetAllPaged(IQueryable<TListDto> entities, int pageNumber, int itemsPerPage);
        PagedResultDto<TListDto> GetAllPaged(IQueryable<TListDto> entities, int pageNumber, int itemsPerPage, Expression<Func<TListDto, object>> sortingExpression, bool ascending = true);
        PagedResultDto<TListDto> GetPaged(TFilterGetPagedInput filter);

        IQueryable<TEntity> GetOrder(IQueryable<TEntity> entities, string sortColumn = "Id", bool ascending = true);
        IQueryable<TEntity> GetOrder(IQueryable<TEntity> entities, Expression<Func<TEntity, object>> sortingExpression, bool ascending = true);
        IEnumerable<TEntity> GetOrder(IEnumerable<TEntity> entities, string sortColumn = "Id", bool ascending = true);
        IEnumerable<TEntity> GetOrder(IEnumerable<TEntity> entities, Func<TEntity, object> sortingExpression, bool ascending = true);

        IQueryable<TListDto> GetOrder(IQueryable<TListDto> entities, string sortColumn = "Id", bool ascending = true);
        IQueryable<TListDto> GetOrder(IQueryable<TListDto> entities, Expression<Func<TListDto, object>> sortingExpression, bool ascending = true);
        IEnumerable<TListDto> GetOrder(IEnumerable<TListDto> entities, string sortColumn = "Id", bool ascending = true);
        IEnumerable<TListDto> GetOrder(IEnumerable<TListDto> entities, Func<TListDto, object> sortingExpression, bool ascending = true);

        IQueryable<TEntity> CreateQueryFilter(TFilterGetPagedInput filter);
        IQueryable<TListDto> CreateFilter(TFilterGetPagedInput filter);

        int Count(IQueryable<TEntity> entities);
        Task<int> CountAsync(Expression<Func<TEntity, bool>> predicate);
        int Count(Expression<Func<TEntity, bool>> predicate);
    }
}
