﻿using Abp.Application.Services.Dto;
using GenAI.Crosscutting.Entities.Dto.Registrations;
using GenAI.Domain.Entities.Registrations;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace GenAI.Core.Contracts.Services.Registrations;

public interface IRegistrationDomainService
{
	IQueryable<Registration> GetRegistrations();
	Task<RegistrationResponseDto> Create(CreateRegistrationDto registrationDto);
	Task DeleteAsync(Guid id);
	Task<RegistrationDto> GetByIdAsync(Guid id);
	Task UpdateAsync(UpdateRegistrationRequestDto registrationDto);
	PagedResultDto<RegistrationDto> GetAllPaged(FilterRegistrationDto filter);
}
