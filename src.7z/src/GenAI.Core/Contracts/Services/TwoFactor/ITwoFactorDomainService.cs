﻿using Abp.Application.Services;
using Abp.Dependency;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenAI.Core.Contracts.Services.TwoFactor
{
    public interface ITwoFactorDomainService : ITransientDependency
    {
        Task<string> TwoFactorSendCode(string userEmail, string userName);
    }
}
