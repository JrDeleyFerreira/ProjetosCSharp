﻿using System.Collections.Generic;
using System.Net.Mail;
using System.Threading;
using System.Threading.Tasks;
using MimeKit;

namespace GenAI.Core.Contracts.Services.TwoFactor.Mail
{
    public interface IMailDomainService
    {
        Task SendAsync(string from, string recipients, string subject, string body, CancellationToken cancellationToken);

        Task SendAsync(MailMessage message, CancellationToken cancellationToken);
    }
}
