﻿using Abp.Application.Services.Dto;
using GenAI.Crosscutting.Entities.Dto.EmployeeSituations;
using GenAI.Domain.Entities.EmployeeSituations;
using Microsoft.AspNetCore.Http;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace GenAI.Core.Contracts.Services.EmployeeSituations;

public interface IEmployeeSituationDomainService
{
    IQueryable<EmployeeSituation> GetEmployeeSituations();
    Task<ResponseEmployeeSituationDto> InsertAsync(CreateEmployeeSituationDto employee);
    Task DeleteAsync(Guid id);
    Task<EmployeeSituationDto> GetByIdAsync(Guid id);
    Task UpdateAsync(UpdateEmployeeSituationDto updateEmployee);
    PagedResultDto<EmployeeSituationDto> GetAllPaged(FilterEmployeeSituationDto filter);
    Task ImportSpreadsheetAsync(IFormFile formImport, string referenceTime);
}
