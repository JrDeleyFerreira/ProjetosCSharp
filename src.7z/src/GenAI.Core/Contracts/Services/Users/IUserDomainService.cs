﻿using GenAI.Core.Contracts.Services.Shared;
using GenAI.Crosscutting.Entities.Dto.Users;
using GenAI.Domain.Entities;
using System;
using System.Threading.Tasks;

namespace GenAI.Core.Contracts.Services.Users;

public interface IUserDomainService : IGenAIDomainServiceBase<User, long, UserDto, CreateUserDto, UpdateUserDto, FilterUserDto>
{
    public Task<UserDto> GetUserWithTenants(long userId);
    Task<User> CreateGuestUserAsync(CreateUserDto entityDto);
    Task<User> UpdateStatusAsync(UpdateUserStatusDto entityDto);
}