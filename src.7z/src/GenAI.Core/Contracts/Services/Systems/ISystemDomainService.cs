﻿using Abp.Application.Services.Dto;
using GenAI.Crosscutting.Entities.Dto.Systems;
using GenAI.Domain.Entities.Systems;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace GenAI.Core.Contracts.Services.Systems
{
    public interface ISystemDomainService //: IGenAIDomainServiceBase<BusinessSystem, Guid, SystemDto>
    {
        IQueryable<BusinessSystem> GetSystems();
        Task<SystemResponseDto> Create(CreateSystemRequestDto systemDto);
        Task DeleteAsync(Guid id);
        PagedResultDto<SystemDto> GetAllPaged(FilterSystemDto filter);
        Task<SystemDto> GetByIdAsync(Guid id);
        Task UpdateAsync(UpdateSystemRequestDto systemDto);
    }
}
