﻿using Abp.Application.Services.Dto;
using GenAI.Crosscutting.Entities.Dto.Systems;
using System;
using System.Threading.Tasks;

namespace GenAI.Core.Contracts.Services.Systems
{
    public interface ISodMatrixDomainService
    {
        Task<SystemResponseDto> Create(CreateSodMatrixRequestDto sodMatrixDto);
        PagedResultDto<SodMatrixDto> GetAllPaged(FilterSodMatrixDto filter);
        Task DeleteAsync(Guid id);
        Task UpdateAsync(UpdateSodMatrixRequestDto sodMatrixDto);
        Task<SodMatrixDto> GetByIdAsync(Guid id);
    }
}
