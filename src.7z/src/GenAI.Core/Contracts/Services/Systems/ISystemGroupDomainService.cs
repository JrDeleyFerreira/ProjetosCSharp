﻿using Abp.Application.Services.Dto;
using GenAI.Crosscutting.Entities.Dto.Systems;
using System;
using System.Threading.Tasks;

namespace GenAI.Core.Contracts.Services.Systems
{
    public interface ISystemGroupDomainService
    {
        Task<SystemResponseDto> Create(CreateSystemGroupRequestDto systemDto);
        PagedResultDto<SystemGroupDto> GetAllPaged(FilterSystemGroupDto filter);
        Task DeleteAsync(Guid id);
        Task UpdateAsync(UpdateSystemGroupRequestDto systemGroupDto);
        Task<SystemGroupDto> GetByIdAsync(Guid id);
    }
}
