﻿using Abp.Application.Services.Dto;
using GenAI.Crosscutting.Entities.Dto.Employees;
using GenAI.Domain.Entities.Employees;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace GenAI.Core.Contracts.Services.Employees;

public interface IEmployeeDomainService
{
	IQueryable<Employee> GetEmployees();
	Task<ResponseEmployeeDto> InsertAsync(CreateEmployeeDto createEmployee);
	Task DeleteAsync(Guid id);
	Task<EmployeeDto> GetByIdAsync(Guid id);
	Task UpdateAsync(UpdateEmployeeDto updateEmployee);
	PagedResultDto<EmployeeDto> GetAllPaged(FilterEmployeeDto filter);
}
