﻿using GenAI.Core.Contracts.Services.Shared;
using GenAI.Domain.Entities.Langague;
using System.Linq;

namespace GenAI.Core.Contracts.Services.Language
{
    public interface IAppLanguageDomainService : IGenAIDomainServiceBase<AppLanguage, int>
    {
        IQueryable<AppLanguage> GetApplicationLanguages();
    }
}
