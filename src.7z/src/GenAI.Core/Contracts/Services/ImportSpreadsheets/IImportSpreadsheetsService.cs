﻿using IronXL;
using Microsoft.AspNetCore.Http;
using System.IO;
using System.Threading.Tasks;

namespace GenAI.Core.Contracts.Services.ImportSpreadsheets;

public interface IImportSpreadsheetsService
{
    MemoryStream TransformToStream(IFormFile formImport);

    (bool isValid, string colunmName) GetAndValidateColumnNames<TClass>(WorkBook workBook, string sheetName) 
		where TClass : class;

	Task SaveInBlobStorageAsync(IFormFile formImport, string entityName);

    bool HasTheExpectedColumnQuantity<TClass>(WorkBook workBook, string sheetName) where TClass : class;
}
