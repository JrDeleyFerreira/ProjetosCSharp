﻿using GenAI.Crosscutting.Entities.Dto.ImportedDocuments;
using System.Threading.Tasks;

namespace GenAI.Core.Contracts.Services.ImportedDocuments;

public interface IImportedDocumentDomainService
{
	Task InsertAsync(ImportedDocumentDto document);
	Task<bool> GetByKeyAsync(string entity, string name, string extension);
}
