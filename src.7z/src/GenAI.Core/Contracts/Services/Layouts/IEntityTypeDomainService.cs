﻿using GenAI.Crosscutting.Entities.Dto.Layouts;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace GenAI.Core.Contracts.Services.Layouts;

public interface IEntityTypeDomainService
{
	Task<List<EntityTypeDto>> GetAllEntityLayoutsAsync();

	Task<EntityTypeDto> GetEntityTypeById(Guid id);

	Task DeleteFileColumnLayoutAsync(Guid entityTypeId);

	Task UpdateEntityTypeAsync(UpdateEntityTypeDto updateEntityType);
}
