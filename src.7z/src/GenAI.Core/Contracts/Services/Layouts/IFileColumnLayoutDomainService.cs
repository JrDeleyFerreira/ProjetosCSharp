﻿using GenAI.Crosscutting.Entities.Dto.Layouts;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace GenAI.Core.Contracts.Services.Layouts;

public interface IFileColumnLayoutDomainService
{
	List<FileColumnLayoutDto> GetAllFileColumnLayoutsAsync();

	List<FileColumnLayoutDto> GetFileColumnLayoutsOfEntityAsync(Guid fileLayoutId);

	FileColumnLayoutDto GetFileColumnLayoutByIdAsync(Guid id);

	Task DeleteCorrespondingInformationAsync(Guid correspondingInformationId);

	Task UpdateCorrespondingInformationAsync(UpdateCorrespondingInformationDto updateCorrespondingInformation);

	Task UpdateFileColumnLayoutAsync(UpdateFileColumnLayoutDto updateFileColumnLayout);
}
