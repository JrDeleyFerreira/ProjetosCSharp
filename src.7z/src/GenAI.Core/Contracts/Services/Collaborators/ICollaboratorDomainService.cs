﻿using Abp.Application.Services.Dto;
using GenAI.Crosscutting.Entities.Dto.Collaborators;
using GenAI.Domain.Entities.Collaborators;
using Microsoft.AspNetCore.Http;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace GenAI.Core.Contracts.Services.Collaborators;

public interface ICollaboratorDomainService
{
	IQueryable<Collaborator> GetCollaborators();
	Task<ResponseCollaboratorDto> InsertAsync(CreateCollaboratorDto collaborator);
	Task DeleteAsync(Guid id);
	Task<CollaboratorDto>GetByIdAsync(Guid id);
	Task UpdateAsync(UpdateCollaboratorDto updateCollaborator);
	PagedResultDto<CollaboratorDto> GetAllPaged(FilterCollaboratorDto filter);
	Task ImportSpreadsheetAsync(IFormFile formImport);
}
