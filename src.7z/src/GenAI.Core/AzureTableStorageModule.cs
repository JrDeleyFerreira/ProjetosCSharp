﻿using Abp.Modules;
using Abp.Zero;
using Azure.Data.Tables;
using GenAI.Crosscutting.Infra.Settings;

namespace GenAI.Core
{
    [DependsOn(typeof(AbpZeroCoreModule))]
    public class AzureTableStorageModule: AbpModule
    {

        public override void Initialize()
        {
            IocManager.RegisterAssemblyByConvention(typeof(AzureTableStorageModule).Assembly);
        }
        public override void PostInitialize()
        {
            IocManager.IocContainer.Register(
                Castle.MicroKernel.Registration.Component
                    .For<TableServiceClient>()
                    .UsingFactoryMethod(() => new TableServiceClient(GenAISettings.StorageAccountConnectionString))
                    .LifestyleSingleton()
            );
        }



    }
}
