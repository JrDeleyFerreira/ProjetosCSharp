﻿using Abp.Modules;
using Abp.Zero;

namespace GenAI.Core
{
    [DependsOn(typeof(AbpZeroCoreModule))]
    public class GenAIDomainCosmosModule : AbpModule
    {

    }
}


