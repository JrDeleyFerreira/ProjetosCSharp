﻿using Abp.Domain.Services;
using Abp.Runtime.Session;
using GenAI.Crosscutting.Infra.ValidationResults;
using System;
using GenAI.Crosscutting.Infra.Extensions.Abp;
using Abp.Dependency;
using GenAI.Crosscutting.Infra.Logs;
using GenAI.Crosscutting.Infra.Settings;

namespace GenAI.Core.Impl.Services
{
    public abstract class BaseDomainService : DomainService
    {
        protected ValidationResults ValidationResults { get; set; }
        protected IAbpSession Session;
        protected Guid TenantId => Session.GetTenant().HasValue ? Session.GetTenant().Value : Guid.Empty;
        protected long UserId => Session.GetUserId();

        protected BaseDomainService()
        {
            ValidationResults = new ValidationResults();
            LocalizationSourceName = GenAIConsts.LocalizationMessagesSourceName;
            Session = IocManager.Instance.Resolve<IAbpSession>();
        }
    }
}