﻿using Abp.Application.Services.Dto;
using Abp.Domain.Repositories;
using Abp.UI;
using GenAI.Core.Contracts.Services.Systems;
using GenAI.Core.Impl.Services.Shared;
using GenAI.Core.Timing;
using GenAI.Crosscutting.Entities.Dto.Systems;
using GenAI.Domain.Entities.Systems;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace GenAI.Core.Impl.Services.Systems
{
    public class SodMatrixDomainService : GenAIDomainServiceBase<SodMatrix, Guid, SodMatrixDto>, ISodMatrixDomainService
    {
        private IRepository<SystemGroup, Guid> _systemGroupRepository;

        public SodMatrixDomainService(IRepository<SodMatrix, Guid> repository,
            IRepository<SystemGroup, Guid> systemGroupRepository) : base(repository)
        {
            _systemGroupRepository = systemGroupRepository;
        }

        public async Task<SystemResponseDto> Create(CreateSodMatrixRequestDto sodMatrixDto)
        {
            if (sodMatrixDto.FirstGroupId.Equals(Guid.Empty)) 
                throw new UserFriendlyException(L("SYSTEM_GROUP_ID_INVALID"));
            if (sodMatrixDto.SecondGroupId.Equals(Guid.Empty)) 
                throw new UserFriendlyException(L("SYSTEM_GROUP_ID_INVALID"));
            if (sodMatrixDto.FirstGroupId == sodMatrixDto.SecondGroupId)
                throw new UserFriendlyException(L("SAME_SOD_MATRIX_SELECTED"));

            bool hasOtherMatrixItemWithTheSameConfiguration = GetAll()
                .Where(x => (x.FirstGroupId == sodMatrixDto.FirstGroupId
                        && x.SecondGroupId == sodMatrixDto.SecondGroupId) ||
                    (x.FirstGroupId == sodMatrixDto.SecondGroupId
                        && x.SecondGroupId == sodMatrixDto.FirstGroupId)).Any();

            if (hasOtherMatrixItemWithTheSameConfiguration) 
                throw new UserFriendlyException(L("SOD_MATRIX_DUPLICATE"));

            bool noExistFirstGroup = !_systemGroupRepository.GetAll()
                .Where(x => x.Id == sodMatrixDto.FirstGroupId && x.IsActive).Any();

            bool noExistSecondGroup = !_systemGroupRepository.GetAll()
                .Where(x => x.Id == sodMatrixDto.SecondGroupId && x.IsActive).Any();

            if (noExistFirstGroup || noExistSecondGroup) 
                throw new UserFriendlyException(L("SYSTEM_GROUP_NOT_FOUND"));

            Guid id = Guid.NewGuid();

            await Repository.InsertAsync(new SodMatrix
            {
                Id = id,
                FirstGroupId = sodMatrixDto.FirstGroupId,
                SecondGroupId = sodMatrixDto.SecondGroupId,
                Comment = sodMatrixDto.Comment,
                CreationTime = DateTime.Now.NowTimeZone(),
                CreatorUserId = UserId,
                IsActive = true,
            });

            return new SystemResponseDto { Id = id };
        }

        public PagedResultDto<SodMatrixDto> GetAllPaged(FilterSodMatrixDto filter)
        {
            IQueryable<SodMatrix> query = Repository.GetAll();
            query = query.Include(x => x.FirstGroup).ThenInclude(x => x.System);
            query = query.Include(x => x.SecondGroup).ThenInclude(x => x.System);

            if (filter.IsActive.HasValue)
            {
                query = query.Where(x => x.IsActive == filter.IsActive.Value);
            }

            if (filter.SystemId.HasValue && !filter.GroupId.HasValue)
            {
                query = query.Where(x => x.FirstGroup.SystemId == filter.SystemId.Value
                    || x.SecondGroup.SystemId == filter.SystemId.Value);
            }

            if (filter.GroupId.HasValue)
            {
                query = query.Where(x => x.FirstGroupId == filter.GroupId.Value 
                    || x.SecondGroupId == filter.GroupId.Value);
            }

            query = GetOrder(query, filter.SortColumn, filter.IsAscending);
            return GetAllPaged(query, filter.Skip, filter.PageSize);
        }

        public override IQueryable<SodMatrix> GetOrder(IQueryable<SodMatrix> entities, string sortColumn = "CreationDate", bool ascending = true)
        {
            switch (sortColumn.ToUpper())
            {
                case "FIRSTGROUP":
                    return base.GetOrder(entities, o => o.FirstGroup.Description, ascending);
                case "SECONDGROUP":
                    return base.GetOrder(entities, o => o.SecondGroup.Description, ascending);
                default:
                    return base.GetOrder(entities, o => o.CreationTime, ascending);
            }
        }

        public override async Task DeleteAsync(Guid id)
        {
            SodMatrix matrixItem = await base.GetAsync(id);

            if (matrixItem == null) throw new UserFriendlyException(L("SOD_MATRIX_NOT_FOUND"));

            matrixItem.IsActive = false;
            matrixItem.DeletionTime = DateTime.Now.NowTimeZone();
            matrixItem.DeletionUserId = UserId;
            await base.UpdateAsync(matrixItem);
        }

        public async Task<SodMatrixDto> GetByIdAsync(Guid id)
        {
            SodMatrix matrixItem = await Repository.GetAll()
                .Include(x => x.FirstGroup)
                    .ThenInclude(x => x.System)
                .Include(x => x.SecondGroup)
                    .ThenInclude(x => x.System)
                .FirstOrDefaultAsync(x => x.Id == id);
            if (matrixItem == null) throw new UserFriendlyException(L("SOD_MATRIX_NOT_FOUND"));
            return MapToEntityDto(matrixItem);
        }

        public async Task UpdateAsync(UpdateSodMatrixRequestDto sodMatrixDto)
        {
            if (sodMatrixDto.FirstGroupId.Equals(Guid.Empty))
                throw new UserFriendlyException(L("SYSTEM_GROUP_ID_INVALID"));
            if (sodMatrixDto.SecondGroupId.Equals(Guid.Empty))
                throw new UserFriendlyException(L("SYSTEM_GROUP_ID_INVALID"));
            if (sodMatrixDto.FirstGroupId == sodMatrixDto.SecondGroupId)
                throw new UserFriendlyException(L("SAME_SOD_MATRIX_SELECTED"));

            bool hasOtherMatrixItemWithTheSameConfiguration = GetAll()
                .Where(x => ((x.FirstGroupId == sodMatrixDto.FirstGroupId
                        && x.SecondGroupId == sodMatrixDto.SecondGroupId) ||
                    (x.FirstGroupId == sodMatrixDto.SecondGroupId 
                        && x.SecondGroupId == sodMatrixDto.FirstGroupId)) && x.Id != sodMatrixDto.Id).Any();

            if (hasOtherMatrixItemWithTheSameConfiguration)
                throw new UserFriendlyException(L("SOD_MATRIX_DUPLICATE"));

            bool noExistFirstGroup = !_systemGroupRepository.GetAll()
                .Where(x => x.Id == sodMatrixDto.FirstGroupId && x.IsActive).Any();

            bool noExistSecondGroup = !_systemGroupRepository.GetAll()
                .Where(x => x.Id == sodMatrixDto.SecondGroupId && x.IsActive).Any();

            if (noExistFirstGroup || noExistSecondGroup)
                throw new UserFriendlyException(L("SYSTEM_GROUP_NOT_FOUND"));

            SodMatrix matrixItem = await base.GetAsync(sodMatrixDto.Id);

            if (matrixItem == null) throw new UserFriendlyException(L("SOD_MATRIX_NOT_FOUND"));

            matrixItem.IsActive = sodMatrixDto.IsActive;
            matrixItem.Comment = sodMatrixDto.Comment;
            matrixItem.FirstGroupId = sodMatrixDto.FirstGroupId;
            matrixItem.SecondGroupId = sodMatrixDto.SecondGroupId;
            matrixItem.LastModificationTime = DateTime.Now.NowTimeZone();
            matrixItem.LastModifierUserId = UserId;

            if (sodMatrixDto.IsActive)
            {
                matrixItem.DeletionTime = null;
                matrixItem.DeletionUserId = null;
            }
            else
            {
                matrixItem.DeletionTime = DateTime.Now.NowTimeZone();
                matrixItem.DeletionUserId = UserId;
            }

            await base.UpdateAsync(matrixItem);
        }
    }
}
