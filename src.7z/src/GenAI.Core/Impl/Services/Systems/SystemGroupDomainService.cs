﻿using Abp.Application.Services.Dto;
using Abp.Domain.Repositories;
using Abp.UI;
using GenAI.Core.Contracts.Services.Systems;
using GenAI.Core.Impl.Services.Shared;
using GenAI.Core.Timing;
using GenAI.Crosscutting.Entities.Dto.Systems;
using GenAI.Domain.Entities.Systems;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace GenAI.Core.Impl.Services.Systems
{
    public class SystemGroupDomainService : GenAIDomainServiceBase<SystemGroup, Guid, SystemGroupDto>, ISystemGroupDomainService
    {
        private IRepository<BusinessSystem, Guid> _systemRepository;

        public SystemGroupDomainService(IRepository<SystemGroup, Guid> repository,
            IRepository<BusinessSystem, Guid> systemRepository) : base(repository)
        {
            _systemRepository = systemRepository;
        }

        public async Task<SystemResponseDto> Create(CreateSystemGroupRequestDto systemDto)
        {
            if (string.IsNullOrEmpty(systemDto.Description)) throw new UserFriendlyException(L("SYSTEM_GROUP_DESCRIPTION_INVALID"));

            bool hasOtherGroupWithTheSameDescription = GetAll()
                .Where(x => x.Description.ToUpper() == systemDto.Description.ToUpper() 
                    && x.SystemId == systemDto.SystemId).Any();

            if (hasOtherGroupWithTheSameDescription) throw new UserFriendlyException(L("SYSTEM_GROUP_DESCRIPTION_DUPLICATE"));

            bool noExistSystem = !_systemRepository.GetAll().Where(x => x.Id == systemDto.SystemId && x.IsActive).Any();

            if(noExistSystem) throw new UserFriendlyException(L("SYSTEM_NOT_FOUND"));

            Guid id = Guid.NewGuid();

            SystemGroup system = await Repository.InsertAsync(new SystemGroup
            {
                Id = id,
                Description = systemDto.Description,
                SystemId = systemDto.SystemId,
                CreationTime = DateTime.Now.NowTimeZone(),
                CreatorUserId = UserId,
                IsActive = true,
            });

            return new SystemResponseDto { Id = id };
        }

        public PagedResultDto<SystemGroupDto> GetAllPaged(FilterSystemGroupDto filter)
        {
            IQueryable<SystemGroup> query = Repository.GetAll();
            query = query.Include(x => x.System);

            if (!string.IsNullOrEmpty(filter.Description))
            {
                query = query.Where(x => x.Description.ToUpper().Contains(filter.Description.ToUpper()));
            }

            if (filter.IsActive.HasValue)
            {
                query = query.Where(x => x.IsActive == filter.IsActive.Value);
            }

            if (filter.SystemId.HasValue)
            {
                query = query.Where(x => x.SystemId == filter.SystemId.Value);
            }

            query = GetOrder(query, filter.SortColumn, filter.IsAscending);
            return GetAllPaged(query, filter.Skip, filter.PageSize);
        }

        public override IQueryable<SystemGroup> GetOrder(IQueryable<SystemGroup> entities, string sortColumn = "Id", bool ascending = true)
        {
            switch (sortColumn.ToUpper())
            {
                case "DESCRIPTION":
                    return base.GetOrder(entities, o => o.Description, ascending);
                case "SYSTEM":
                    return base.GetOrder(entities, o => o.System.Description, ascending);
                case "CREATIONDATE":
                    return base.GetOrder(entities, o => o.CreationTime, ascending);
                default:
                    return base.GetOrder(entities, o => o.Description, ascending);
            }
        }

        public override async Task DeleteAsync(Guid id)
        {
            SystemGroup system = await base.GetAsync(id);

            if (system == null) throw new UserFriendlyException(L("SYSTEM_GROUP_NOT_FOUND"));

            system.IsActive = false;
            system.DeletionTime = DateTime.Now.NowTimeZone();
            system.DeletionUserId = UserId;
            await base.UpdateAsync(system);
        }

        public async Task<SystemGroupDto> GetByIdAsync(Guid id)
        {
            SystemGroup system = await Repository.GetAll()
                .Include(x => x.System)
                .FirstOrDefaultAsync(x => x.Id == id);
            if (system == null) throw new UserFriendlyException(L("SYSTEM_GROUP_NOT_FOUND"));
            return MapToEntityDto(system);
        }

        public async Task UpdateAsync(UpdateSystemGroupRequestDto systemGroupDto)
        {
            if (string.IsNullOrEmpty(systemGroupDto.Description)) throw new UserFriendlyException(L("SYSTEM_GROUP_DESCRIPTION_INVALID"));
            if (systemGroupDto.Id.Equals(Guid.Empty)) throw new UserFriendlyException(L("SYSTEM_GROUP_ID_INVALID"));

            bool hasOtherSystemWithTheSameDescription = Repository.GetAll()
                .Where(x => x.Description.ToUpper() == systemGroupDto.Description.ToUpper()
                    && x.SystemId == systemGroupDto.SystemId
                    && x.Id != systemGroupDto.Id).Any();

            if (hasOtherSystemWithTheSameDescription) throw new UserFriendlyException(L("SYSTEM_GROUP_DESCRIPTION_DUPLICATE"));

            SystemGroup systemGroup = await base.GetAsync(systemGroupDto.Id);

            if (systemGroup == null) throw new UserFriendlyException(L("SYSTEM_GROUP_NOT_FOUND"));

            systemGroup.IsActive = systemGroupDto.IsActive;
            systemGroup.Description = systemGroupDto.Description;
            systemGroup.SystemId = systemGroupDto.SystemId;
            systemGroup.LastModificationTime = DateTime.Now.NowTimeZone();
            systemGroup.LastModifierUserId = UserId;

            if (systemGroupDto.IsActive)
            {
                systemGroup.DeletionTime = null;
                systemGroup.DeletionUserId = null;
            }
            else
            {
                systemGroup.DeletionTime = DateTime.Now.NowTimeZone();
                systemGroup.DeletionUserId = UserId;
            }

            await base.UpdateAsync(systemGroup);
        }
    }
}
