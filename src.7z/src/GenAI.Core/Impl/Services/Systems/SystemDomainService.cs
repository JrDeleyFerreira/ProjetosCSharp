﻿using Abp.Application.Services.Dto;
using Abp.Domain.Repositories;
using Abp.UI;
using GenAI.Core.Contracts.Services.Systems;
using GenAI.Core.Impl.Services.Shared;
using GenAI.Core.Timing;
using GenAI.Crosscutting.Entities.Dto.Systems;
using GenAI.Domain.Entities.Systems;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace GenAI.Core.Impl.Services.Systems
{
    public class SystemDomainService : GenAIDomainServiceBase<BusinessSystem, Guid, SystemDto>, ISystemDomainService
    {
        public SystemDomainService(IRepository<BusinessSystem, Guid> repository) : base(repository)
        {
        }

        public IQueryable<BusinessSystem> GetSystems()
        {
            return Repository.GetAll();
        }

        public async Task<SystemResponseDto> Create(CreateSystemRequestDto systemDto)
        {
            if (string.IsNullOrEmpty(systemDto.Description)) throw new UserFriendlyException(L("SYSTEM_DESCRIPTION_INVALID"));

            bool hasOtherSystemWithTheSameDescription = GetAll()
                .Where(x => x.Description.ToUpper() == systemDto.Description.ToUpper()).Any();

            if (hasOtherSystemWithTheSameDescription) throw new UserFriendlyException(L("SYSTEM_DESCRIPTION_DUPLICATE"));

            Guid id = Guid.NewGuid();

            BusinessSystem system = await Repository.InsertAsync(new BusinessSystem
            {
                Description = systemDto.Description,
                CreationTime = DateTime.Now.NowTimeZone(),
                Id = id,
                CreatorUserId = UserId,
                IsActive = true,
            });

            return new SystemResponseDto { Id = id };
        }

        public PagedResultDto<SystemDto> GetAllPaged(FilterSystemDto filter)
        {
            IQueryable<BusinessSystem> query = GetSystems();

            if(!string.IsNullOrEmpty(filter.Description))
            {
                query = query.Where(x => x.Description.ToUpper().Contains(filter.Description.ToUpper()));
            }

            if (filter.IsActive.HasValue)
            {
                query = query.Where(x => x.IsActive == filter.IsActive.Value);
            }

            query = GetOrder(query, filter.SortColumn, filter.IsAscending);
            return GetAllPaged(query, filter.Skip, filter.PageSize);
        }

        public override IQueryable<BusinessSystem> GetOrder(IQueryable<BusinessSystem> entities, string sortColumn = "Id", bool ascending = true)
        {
            switch (sortColumn.ToUpper())
            {
                case "DESCRIPTION":
                    return base.GetOrder(entities, o => o.Description, ascending);
                case "CREATIONDATE":
                    return base.GetOrder(entities, o => o.CreationTime, ascending);
                default:
                    return base.GetOrder(entities, o => o.Description, ascending);
            }
        }

        public override async Task DeleteAsync(Guid id)
        {
            BusinessSystem system = await base.GetAsync(id);

            if (system == null) throw new UserFriendlyException(L("SYSTEM_NOT_FOUND"));

            system.IsActive = false;
            system.DeletionTime = DateTime.Now.NowTimeZone();
            system.DeletionUserId = UserId;
            await base.UpdateAsync(system);
        }

        public async Task<SystemDto> GetByIdAsync(Guid id)
        {
            BusinessSystem system = await base.GetAsync(id);
            if (system == null) throw new UserFriendlyException(L("SYSTEM_NOT_FOUND"));
            return MapToEntityDto(system);
        }

        public async Task UpdateAsync(UpdateSystemRequestDto systemDto)
        {
            if (string.IsNullOrEmpty(systemDto.Description)) throw new UserFriendlyException(L("SYSTEM_DESCRIPTION_INVALID"));
            if (systemDto.Id.Equals(Guid.Empty)) throw new UserFriendlyException(L("SYSTEM_ID_INVALID"));
            
            bool hasOtherSystemWithTheSameDescription = GetAll()
                .Where(x => x.Description.ToUpper() == systemDto.Description.ToUpper() 
                    && x.Id != systemDto.Id).Any();

            if (hasOtherSystemWithTheSameDescription) throw new UserFriendlyException(L("SYSTEM_DESCRIPTION_DUPLICATE"));

            BusinessSystem system = await base.GetAsync(systemDto.Id);

            if (system == null) throw new UserFriendlyException(L("SYSTEM_NOT_FOUND"));

            system.IsActive = systemDto.IsActive;
            system.Description = systemDto.Description;
            system.LastModificationTime = DateTime.Now.NowTimeZone();
            system.LastModifierUserId = UserId;

            if (systemDto.IsActive)
            {
                system.DeletionTime = null;
                system.DeletionUserId = null;
            }
            else
            {
                system.DeletionTime = DateTime.Now.NowTimeZone();
                system.DeletionUserId = UserId;
            }

            await base.UpdateAsync(system);
        }
    }
}
