﻿using Abp.Application.Services.Dto;
using Abp.Domain.Repositories;
using Abp.UI;
using GenAI.Core.Contracts.Services.EmployeeSituations;
using GenAI.Core.Contracts.Services.ImportedDocuments;
using GenAI.Core.Contracts.Services.ImportSpreadsheets;
using GenAI.Core.Impl.Services.Shared;
using GenAI.Core.Resources;
using GenAI.Core.Timing;
using GenAI.Crosscutting.Entities.Dto.EmployeeSituations;
using GenAI.Crosscutting.Entities.Dto.ImportedDocuments;
using GenAI.Crosscutting.Infra.Settings;
using GenAI.Domain.Entities.Employees;
using GenAI.Domain.Entities.EmployeeSituations;
using IronXL;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.TeamFoundation.Work.WebApi;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;

namespace GenAI.Core.Impl.Services.EmployeeSituations;

public class EmployeeSituationDomainService : GenAIDomainServiceBase<EmployeeSituation, Guid, EmployeeSituationDto>, IEmployeeSituationDomainService
{
    private readonly IImportSpreadsheetsService _importSpreadsheetsService;
    private readonly IImportedDocumentDomainService _importedDocumentDomainService;

    public EmployeeSituationDomainService(
        IRepository<EmployeeSituation, Guid> repository,
        IImportSpreadsheetsService importSpreadsheetsService,
        IImportedDocumentDomainService importedDocumentDomainService)
        : base(repository)
    {
        _importSpreadsheetsService = importSpreadsheetsService;
        _importedDocumentDomainService = importedDocumentDomainService;
    }

    public IQueryable<EmployeeSituation> GetEmployeeSituations()
        => Repository.GetAll();

    public async Task<ResponseEmployeeSituationDto> InsertAsync(CreateEmployeeSituationDto employee)
    {
        var hasOtherRegisterWithTheSameRegistration = await ValidateEmployeeFieldsAndExists(employee);
        if (hasOtherRegisterWithTheSameRegistration)
            throw new UserFriendlyException(L("RECORD_ALREADY_EXISTS"));

        var id = Guid.NewGuid();

        await Repository.InsertAsync(new EmployeeSituation
        {
            EmployeeCode = employee.EmployeeCode,
            Name = employee.Name,
            RhStatus = employee.RhStatus,
            PayrollStatus = employee.PayrollStatus,
            AdmissionDate = employee.AdmissionDate,
            EmploymentContract = employee.EmploymentContract,
            PositionCode = employee.PositionCode,
            PositionDescription = employee.PositionDescription,
            DepartmentCode = employee.DepartmentCode,
            DepartmentDescription = employee.DepartmentDescription,
            CostCenter = employee.CostCenter,
            Manager = employee.Manager,
            EstablishmentCode = employee.EstablishmentCode,
            EstablishmentCnpj = employee.EstablishmentCnpj,
            WorkplaceCode = employee.WorkplaceCode,
            WorkplaceDescription = employee.WorkplaceDescription,
            WorkplaceState = employee.WorkplaceState,
            WorkplaceCity = employee.WorkplaceCity,
			Email = employee.Email,
            ReferenceTime = DateTime.ParseExact(employee.ReferenceTime, "MM/yyyy", CultureInfo.InvariantCulture),
			IsActive = true,
            CreationTime = DateTime.Now.NowTimeZone(),
            CreatorUserId = UserId,
        });

        return new ResponseEmployeeSituationDto { Id = id };
    }

    public override async Task DeleteAsync(Guid id)
    {
        var employee = await base.GetAsync(id);

        employee.IsActive = false;
        employee.DeletionTime = DateTime.Now.NowTimeZone();
        employee.DeletionUserId = UserId;

        await base.UpdateAsync(employee);
    }

    public async Task<EmployeeSituationDto> GetByIdAsync(Guid id)
    {
        var employee = await base.GetAsync(id);
        return MapToEntityDto(employee);
    }

    public PagedResultDto<EmployeeSituationDto> GetAllPaged(FilterEmployeeSituationDto filter)
    {
        var query = GetEmployeeSituations();

        if (filter.EmployeeCode.HasValue)
            query = query.Where(x => x.EmployeeCode == filter.EmployeeCode.Value);

        if (!string.IsNullOrEmpty(filter.Name))
            query = query.Where(x => x.Name.Contains(filter.Name));

        if (!string.IsNullOrEmpty(filter.Email))
            query = query.Where(x => x.Email.Contains(filter.Email));

		if (!string.IsNullOrEmpty(filter.RhStatus))
			query = query.Where(x => x.RhStatus.Contains(filter.RhStatus));

		if (!string.IsNullOrEmpty(filter.PayrollStatus))
			query = query.Where(x => x.PayrollStatus.Contains(filter.PayrollStatus));

        if (!string.IsNullOrEmpty(filter.ReferenceTime))
        {
            var reference = DateTime.ParseExact(filter.ReferenceTime, "MM/yyyy", CultureInfo.InvariantCulture);
            query = query.Where(x => x.ReferenceTime.Month == reference.Month
                && x.ReferenceTime.Year == reference.Year);
        }

        if (filter.IsActive.HasValue)
            query = query.Where(x => x.IsActive == filter.IsActive);

        query = GetOrder(query, filter.SortColumn, filter.IsAscending);

        return GetAllPaged(query, filter.Skip, filter.PageSize);
    }

    public async Task UpdateAsync(UpdateEmployeeSituationDto updateEmployee)
    {
        var hasOtherRegisterWithTheSameRegistration = await ValidateEmployeeFieldsAndExists(updateEmployee);
        if (!hasOtherRegisterWithTheSameRegistration)
            throw new UserFriendlyException(L("EMPLOYEE_NOT_FOUND"));

        var referenceTime = DateTime.ParseExact(updateEmployee.ReferenceTime, "MM/yyyy", CultureInfo.InvariantCulture);

		var employee = await GetEmployeeSituations().FirstOrDefaultAsync(x => 
            x.EmployeeCode == updateEmployee.EmployeeCode && x.ReferenceTime == referenceTime);

        employee.EmployeeCode = updateEmployee.EmployeeCode;
        employee.Name = updateEmployee.Name;
        employee.RhStatus = updateEmployee.RhStatus;
        employee.PayrollStatus = updateEmployee.PayrollStatus;
        employee.AdmissionDate = updateEmployee.AdmissionDate;
        employee.EmploymentContract = updateEmployee.EmploymentContract;
        employee.PositionCode = updateEmployee.PositionCode;
        employee.PositionDescription = updateEmployee.PositionDescription;
        employee.DepartmentCode = updateEmployee.DepartmentCode;
        employee.DepartmentDescription = updateEmployee.DepartmentDescription;
        employee.CostCenter = updateEmployee.CostCenter;
        employee.Manager = updateEmployee.Manager;
        employee.EstablishmentCode = updateEmployee.EstablishmentCode;
        employee.EstablishmentCnpj = updateEmployee.EstablishmentCnpj;
        employee.WorkplaceCode = updateEmployee.WorkplaceCode;
        employee.WorkplaceDescription = updateEmployee.WorkplaceDescription;
        employee.WorkplaceState = updateEmployee.WorkplaceState;
        employee.WorkplaceCity = updateEmployee.WorkplaceCity;
        employee.Email = updateEmployee.Email;
        employee.ReferenceTime = referenceTime;

		employee.IsActive = updateEmployee.IsActive.Value;
        employee.LastModificationTime = DateTime.Now.NowTimeZone();
        employee.LastModifierUserId = UserId;

        if (updateEmployee.IsActive.HasValue)
        {
            employee.DeletionTime = null;
            employee.DeletionUserId = null;
        }
        else
        {
            employee.DeletionTime = DateTime.Now.NowTimeZone();
            employee.DeletionUserId = UserId;
        }

        await base.UpdateAsync(employee);
    }

    public async Task ImportSpreadsheetAsync(IFormFile formImport, string referenceTime)
    {
        var fileExtension = Path.GetExtension(formImport.FileName);

        if (!DataConstants.SpreadsheetTypeExtension.Contains(fileExtension))
            throw new UserFriendlyException(L("INVALID_FILE_EXTENSION"));

        try
        {
            var streamFile = _importSpreadsheetsService.TransformToStream(formImport);
            var workBook = new WorkBook(streamFile);

            //INFO: aqui eu criei mas vai perder função com as configurações pq o usuário pode cadastrar somente o que ele precisa da planilha
            if (!_importSpreadsheetsService.HasTheExpectedColumnQuantity<EmployeeSituationDto>(workBook, DataConstants.EmployeeSheetName))
                throw new UserFriendlyException(L("INVALID_COLUMNS_QUANTITY_FROM_SPREEDSHEET"));

            //INFO: aqui tem uma informação dentro do método
            var headerRow = _importSpreadsheetsService.GetAndValidateColumnNames<EmployeeSituationDto>
                (workBook, DataConstants.EmployeeSheetName);

            if (!headerRow.isValid)
                throw new UserFriendlyException(L("INVALID_COLUNM_NAME", headerRow.colunmName));

            var listEmployees = new List<EmployeeSituation>();
            var listToDoesNotCreate = new List<EmployeeSituation>();

            var workSheet = workBook.GetWorkSheet(DataConstants.EmployeeSheetName) ?? workBook.WorkSheets[0];
            var rowCounter = workSheet.RowCount;

            for (var index = 1; index < rowCounter; index++)
            {
                var recoveredLine = workSheet.GetRow(index).Select(c => c.Text).ToList();

                //Aqui vai ser substituído por uma verificação de null ou vazio com base na configuração
                //Ex: se matrícula e e-mail são obrigatórios, tem que procurar na configuração o que é matrícula e o que é email com base
                //na lista intitulada como CorrespondingInformations que pode ser representado no código como um Enum
                if (ChecksIfCellContentIsEmpty(recoveredLine))
                    continue;

                //Aqui você pode passar para o método de setValues
                _ = DateTime.TryParse(recoveredLine[4], out var data);
                _ = long.TryParse(recoveredLine[0], out var code);

                //Aqui vai usar o método SetValues da Classe de Configuração de Empregados
                var employee = new EmployeeSituation
                {
                    Id = Guid.NewGuid(),
                    EmployeeCode = code,
                    Name = recoveredLine[1],
                    RhStatus = recoveredLine[2],
                    PayrollStatus = recoveredLine[3],
                    AdmissionDate = data,
                    EmploymentContract = recoveredLine[5],
                    PositionCode = recoveredLine[6],
                    PositionDescription = recoveredLine[7],
                    DepartmentCode = recoveredLine[8],
                    DepartmentDescription = recoveredLine[9],
                    CostCenter = recoveredLine[10],
                    Manager = recoveredLine[11],
                    EstablishmentCode = recoveredLine[12],
                    EstablishmentCnpj = recoveredLine[13],
                    WorkplaceCode = recoveredLine[14],
                    WorkplaceDescription = recoveredLine[15],
                    WorkplaceState = recoveredLine[16],
                    WorkplaceCity = recoveredLine[17],
                    Email = recoveredLine[18],
                    ReferenceTime = DateTime.ParseExact(referenceTime, "MM/yyyy", CultureInfo.InvariantCulture),
					IsActive = true,
                    CreationTime = DateTime.Now.NowTimeZone(),
                    CreatorUserId = UserId,
                };

                listEmployees.Add(employee);
            }

            listToDoesNotCreate.AddRange(listEmployees.Where(employee=> GetEmployeeSituations()
                .FirstOrDefaultAsync(x => 
                    x.EmployeeCode == employee.EmployeeCode &&
                    x.ReferenceTime == employee.ReferenceTime)
                .Result is not null));

            listEmployees.RemoveAll(item => listToDoesNotCreate.Contains(item));

            if (listEmployees.Any())
            {
                await _importSpreadsheetsService.SaveInBlobStorageAsync(formImport, nameof(Employee));

                var fileName = Path.GetFileName(formImport.FileName);
                await _importedDocumentDomainService.InsertAsync(new ImportedDocumentDto
                {
                    FileName = fileName,
                    FileExtension = fileExtension,
                    EntityType = nameof(EmployeeSituation)
                });

                await base.BulkInsertAsync(listEmployees);
            }
        }
        catch (UserFriendlyException ex)
        {
            throw new UserFriendlyException($"{L("ERROR_IMPORTING_SPREADSHEET")} - {ex.Message}");
        }

        static bool ChecksIfCellContentIsEmpty(List<string> recoveredLine)
        {
            for (var cell = 1; cell < recoveredLine.Count; cell++)
            {
                if (cell == 4)
                    continue;
                if (recoveredLine[cell].Equals(string.Empty))
                    return true;
            }

            return false;
        }
    }

    public override IQueryable<EmployeeSituation> GetOrder(IQueryable<EmployeeSituation> entities, string sortColumn = "Id", bool ascending = true)
        => sortColumn.ToUpper() switch
        {
            "CODE" => base.GetOrder(entities, o => o.EmployeeCode, ascending),
            "NAME" => base.GetOrder(entities, o => o.Name, ascending),
			"RHSTATUS" => base.GetOrder(entities, o => o.RhStatus, ascending),
            "PAYROLLSTATUS" => base.GetOrder(entities, o => o.PayrollStatus, ascending),
			"ISACTIVE" => base.GetOrder(entities, o => o.IsActive, ascending),
            "EMAIL" => base.GetOrder(entities, o => o.Email, ascending),
            "REFERENCEDATE" => base.GetOrder(entities, o => o.ReferenceTime, ascending),
            "KEY" => base.GetOrder(entities, o => o.EmployeeCode, ascending),
            _ => base.GetOrder(entities, o => o.CreationTime, ascending),
        };


    #region Métodos privados

    private async Task<bool> ValidateEmployeeFieldsAndExists(object employee)
    {
        bool hasOtherRegisterWithTheSameRegistration = false;

        switch (employee)
        {
            case CreateEmployeeSituationDto:
            {
                var createEmployee = employee as CreateEmployeeSituationDto;

                var propertiesOfEntity = createEmployee.GetType().GetProperties()
					.Where(x => !x.Name.Equals(nameof(createEmployee.EmployeeCode)) &&
								!x.Name.Equals(nameof(createEmployee.AdmissionDate)) &&
								!x.Name.Equals(nameof(createEmployee.ReferenceTime)));

				var listOfFieldsEmpty = propertiesOfEntity
					.Where(p => string.IsNullOrEmpty(p.GetValue(employee)?.ToString()))
                    .Select(p => p.CustomAttributes.FirstOrDefault()?.NamedArguments.FirstOrDefault().ToString()!.Split("\"")[1])
                    .ToList();

                if (createEmployee.EmployeeCode == 0)
                    listOfFieldsEmpty.Add(createEmployee.EmployeeCode.GetType().CustomAttributes.FirstOrDefault()?.NamedArguments.FirstOrDefault().ToString()!.Split("\"")[1]);
                if (createEmployee.AdmissionDate == DateTime.MinValue)
                    listOfFieldsEmpty.Add(createEmployee.AdmissionDate.GetType().CustomAttributes.FirstOrDefault()?.NamedArguments.FirstOrDefault().ToString()!.Split("\"")[1]);

                if (listOfFieldsEmpty.Any())
                {
                    var fields = string.Join(", ", listOfFieldsEmpty);
                    throw new UserFriendlyException(L("FIELD_REQUIRED_TO_INCLUDE_ENTITY", fields));
                }

                hasOtherRegisterWithTheSameRegistration = await GetEmployeeSituations().AnyAsync(x => x.EmployeeCode == createEmployee.EmployeeCode);
                break;
            }
            default:
            {
                var updateEmployee = employee as UpdateEmployeeSituationDto;

                var propertiesOfEntity = updateEmployee.GetType().GetProperties()
                    .Where(x => !x.Name.Equals(nameof(updateEmployee.EmployeeCode)) &&
                                !x.Name.Equals(nameof(updateEmployee.AdmissionDate)) &&
                                !x.Name.Equals(nameof(updateEmployee.ReferenceTime)) &&
                                !x.Name.Equals(nameof(updateEmployee.IsActive)));

                var listOfFieldsEmpty = propertiesOfEntity
                    .Where(p => string.IsNullOrEmpty(p.GetValue(employee)?.ToString()))
                    .Select(p => p.CustomAttributes.FirstOrDefault()?.NamedArguments.FirstOrDefault().ToString()!.Split("\"")[1])
                    .ToList();

                LocalizationSourceName = GenAIConsts.LocalizationTextsSourceName;
                if (updateEmployee.EmployeeCode == 0)
                    listOfFieldsEmpty.Add("Key");
                if (updateEmployee.AdmissionDate == DateTime.MinValue)
                    listOfFieldsEmpty.Add("AdmissionDate");
				if (!updateEmployee.IsActive.HasValue)
					listOfFieldsEmpty.Add("Status");

				if (listOfFieldsEmpty.Any())
                {
                    var fields = string.Join(", ", listOfFieldsEmpty.Select(x => L(x)));
                    LocalizationSourceName = GenAIConsts.LocalizationMessagesSourceName;
                    throw new UserFriendlyException(L("FIELD_REQUIRED_TO_INCLUDE_ENTITY", fields));
                }

                hasOtherRegisterWithTheSameRegistration = await GetEmployeeSituations().AnyAsync(x => x.EmployeeCode == updateEmployee.EmployeeCode);
                break;
            }
        }

        return hasOtherRegisterWithTheSameRegistration;
    }

    #endregion Métodos privados
}


/// <summary>
/// Exemplo de código para o Wanderley usar na sprint 4 para a modificação da validação de Empregados por Layout
/// </summary>
public class EmployeeConfiguration
{
    public bool IsValid(List<(byte Position, FieldInfo infoType)> configurations, List<string> recoveredLine)
    {
        if(!AllFieldsWasConfigurated(configurations))
            return false;

        foreach (var configuration in configurations)
        {
            if (configuration.Position > recoveredLine.Count)
                return false;

            var cell = recoveredLine[configuration.Position];

            if (IsRequired(configuration.infoType))
            {
                if(string.IsNullOrEmpty(cell))
                    return false;
            }
        }
        return true;
    }

    public void SetValues(List<(byte Position, FieldInfo infoType)> configurations, List<string> recoveredLine, ref EmployeeT employee)
    {
        foreach (var configuration in configurations)
        {
            var cell = recoveredLine[configuration.Position];

            switch (configuration.infoType)
            {
                case FieldInfo.Email:
                    var emailField = typeof(EmployeeT).GetProperty("Email");
                    emailField.SetValue(employee, cell);
                    break;
                case FieldInfo.Name:
                    var nameField = typeof(EmployeeT).GetProperty("Name");
                    nameField.SetValue(employee, cell);
                    break;
            };
        }
    }

    private bool IsRequired(FieldInfo fieldInfo) 
    {
        PropertyInfo field;
        switch (fieldInfo)
        {
            case FieldInfo.Email:
                field = typeof(EmployeeT).GetProperty("Email");
                return field.CustomAttributes.Any(x => x.AttributeType == typeof(RequiredAttribute));
            case FieldInfo.Name:
                field = typeof(EmployeeT).GetProperty("Name");
                return field.CustomAttributes.Any(x => x.AttributeType == typeof(RequiredAttribute));
            default: return false;
        };
    }

    private bool AllFieldsWasConfigurated(List<(byte Position, FieldInfo infoType)> configurations)
    {
        var propertyFields = typeof(EmployeeT).GetProperties()
            .Where(x => x.CustomAttributes.Any(y => y.AttributeType == typeof(RequiredAttribute)) 
                && x.CustomAttributes.Any(y => y.AttributeType == typeof(EnumItemAttribute)))
            .ToList();

        foreach (PropertyInfo field in propertyFields)
        {
            var attribute = (EnumItemAttribute)Attribute.GetCustomAttribute(field, typeof(EnumItemAttribute));
            if(!configurations.Any(x => x.infoType == (FieldInfo)attribute.EnumValue))
                return false;
        }

        return true;
    }
}

public class EmployeeT
{
    [Required]
    [EnumItem(FieldInfo.Name)]
    public string Name { get; set; }

    [Required]
    [EnumItem(FieldInfo.Key)]
    public string Key {  get; set; }

    [EnumItem(FieldInfo.Email)]
    public string Email { get; set; }
}

public enum FieldInfo
{
    Name,
    Email,
    Key
}

[AttributeUsage(AttributeTargets.Property | AttributeTargets.Field, Inherited = true, AllowMultiple = false)]
public class EnumItemAttribute : Attribute
{
    public object EnumValue { get; }

    public EnumItemAttribute(object enumValue)
    {
        if (!enumValue.GetType().IsEnum)
        {
            throw new ArgumentException("O valor fornecido não é um item de enum.");
        }

        EnumValue = enumValue;
    }
}