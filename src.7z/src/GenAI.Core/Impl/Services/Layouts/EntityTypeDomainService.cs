﻿using Abp.Domain.Repositories;
using Abp.UI;
using GenAI.Core.Contracts.Services.Layouts;
using GenAI.Core.Impl.Services.Shared;
using GenAI.Core.Timing;
using GenAI.Crosscutting.Entities.Dto.Layouts;
using GenAI.Crosscutting.Infra.Extensions.Abp;
using GenAI.Domain.Entities.Layouts;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Dynamic.Core;
using System.Threading.Tasks;

namespace GenAI.Core.Impl.Services.Layouts;

public class EntityTypeDomainService : GenAIDomainServiceBase<EntityType, Guid, EntityTypeDto>, IEntityTypeDomainService
{
	private readonly IRepository<FileLayout, Guid> _fileLayoutRepository;
	private readonly IRepository<FileColumnLayout, Guid> _fileColumnLayoutRepository;
	private readonly IRepository<CorrespondingInformation, Guid> _correspondingInformationRepository;

	public EntityTypeDomainService(
		IRepository<EntityType, Guid> repository, 
		IRepository<FileLayout, Guid> fileLayoutRepository, 
		IRepository<FileColumnLayout, Guid> fileColumnLayoutRepository, 
		IRepository<CorrespondingInformation, Guid> correspondingInformationRepository)
	: base(repository)
	{
		_fileLayoutRepository = fileLayoutRepository;
		_fileColumnLayoutRepository = fileColumnLayoutRepository;
		_correspondingInformationRepository = correspondingInformationRepository;
	}


	public async Task<EntityTypeDto> GetEntityTypeById(Guid id)
	{
		var entityType = await base.GetAsync(id);
		return new EntityTypeDto
		{
			Id = entityType.Id,
			Key = entityType.Type.GetHashCode(),
			Name = entityType.Type.ToString(),
			Description = entityType.Description
		};
	}

	public async Task<List<EntityTypeDto>> GetAllEntityLayoutsAsync()
	{
		var entityTypes = await base.GetAllAsync();

		return entityTypes.Select(entityType => new EntityTypeDto
		{
			Id = entityType.Id,
			Key = entityType.Type.GetHashCode(),
			Name = entityType.Type.ToString(),
			Description = entityType.Description
		})
		.OrderBy(x => x.Key)
		.ToList();
	}

	public async Task DeleteFileColumnLayoutAsync(Guid entityTypeId)
	{
		var entityType = await base.GetAsync(entityTypeId);

		entityType.IsActive = false;
		entityType.DeletionTime = DateTime.Now.NowTimeZone();
		entityType.DeletionUserId = UserId;

		var filelayout = GetAndModifyFileLayoutPropertiesForDeletion(entityType);

		GetAndModifyFileColumnLayoutPropertiesForDeletion(filelayout, out var fileColumnLayouts, out var fileColumnLayout);

		var correspondingInformationList = GetAndModifyCorrespondingInformationPropertiesForDeletion(fileColumnLayouts);

		await base.UpdateAsync(entityType);
		await _fileLayoutRepository.UpdateAsync(filelayout.Result);
		await _fileColumnLayoutRepository.UpdateAsync(fileColumnLayout.Result);
		_correspondingInformationRepository.BulkUpdate(correspondingInformationList);
	}

	public async Task UpdateEntityTypeAsync(UpdateEntityTypeDto updateEntityType)
	{
		if (updateEntityType.Id == Guid.Empty)
			throw new UserFriendlyException(L("OBJECT_IDENTIFIER_NOT_FOUND"));
		if (string.IsNullOrEmpty(updateEntityType.Description))
			throw new UserFriendlyException(L("FIELD_REQUIRED_TO_INCLUDE_ENTITY", nameof(updateEntityType.Description)));

		var entityType = base.GetAsync(updateEntityType.Id).Result 
			?? throw new UserFriendlyException(L("ENTITY_TYPE_NOT_FOUND"));

		entityType.Description = updateEntityType.Description;
		entityType.IsActive = updateEntityType.IsActive;

		entityType.LastModificationTime = DateTime.Now.NowTimeZone();
		entityType.LastModifierUserId = UserId;

		if (updateEntityType.IsActive)
		{
			entityType.DeletionTime = null;
			entityType.DeletionUserId = null;
		}
		else
		{
			entityType.DeletionTime = DateTime.Now.NowTimeZone();
			entityType.DeletionUserId = UserId;

			var filelayout = GetAndModifyFileLayoutPropertiesForDeletion(entityType);

			GetAndModifyFileColumnLayoutPropertiesForDeletion(filelayout, out var fileColumnLayouts, out var fileColumnLayout);

			var correspondingInformationList = GetAndModifyCorrespondingInformationPropertiesForDeletion(fileColumnLayouts);

			await _fileLayoutRepository.UpdateAsync(filelayout.Result);
			await _fileColumnLayoutRepository.UpdateAsync(fileColumnLayout.Result);
			_correspondingInformationRepository.BulkUpdate(correspondingInformationList);
		}

		await base.UpdateAsync(entityType);
	}


	private List<CorrespondingInformation> GetAndModifyCorrespondingInformationPropertiesForDeletion(IIncludableQueryable<FileColumnLayout, CorrespondingInformation> fileColumnLayouts)
	{
		var correspondingInformations = fileColumnLayouts.Select(x => x.CorrespondingInformation).ToListAsync();

		var correspondingInformationList = new List<CorrespondingInformation>();
		foreach (var item in correspondingInformations.Result)
		{
			item.IsActive = false;
			item.DeletionTime = DateTime.Now.NowTimeZone();
			item.DeletionUserId = UserId;
			correspondingInformationList.Add(item);
		}

		return correspondingInformationList;
	}

	private void GetAndModifyFileColumnLayoutPropertiesForDeletion(Task<FileLayout> filelayout, out IIncludableQueryable<FileColumnLayout, CorrespondingInformation> fileColumnLayouts, out Task<FileColumnLayout> fileColumnLayout)
	{
		var resultFileColumnLayouts = _fileColumnLayoutRepository.GetAll();
		fileColumnLayouts = resultFileColumnLayouts.Where(x => x.FileLayoutId == filelayout.Result.Id).Include(x => x.CorrespondingInformation);
		fileColumnLayout = fileColumnLayouts.FirstOrDefaultAsync();

		fileColumnLayout.Result.IsActive = false;
		fileColumnLayout.Result.DeletionTime = DateTime.Now.NowTimeZone();
		fileColumnLayout.Result.DeletionUserId = UserId;
	}

	private Task<FileLayout> GetAndModifyFileLayoutPropertiesForDeletion(EntityType entityType)
	{
		var resultFilelayouts = _fileLayoutRepository.GetAll();
		var filelayouts = resultFilelayouts.Where(x => x.EntityTypeId == entityType.Id).Include(x => x.EntityType);
		var filelayout = filelayouts.FirstOrDefaultAsync();

		filelayout.Result.IsActive = false;
		filelayout.Result.DeletionTime = DateTime.Now.NowTimeZone();
		filelayout.Result.DeletionUserId = UserId;
		return filelayout;
	}
}
