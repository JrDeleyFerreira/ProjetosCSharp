﻿using Abp.Domain.Repositories;
using Abp.UI;
using GenAI.Core.Contracts.Services.Layouts;
using GenAI.Core.Impl.Services.Shared;
using GenAI.Core.Timing;
using GenAI.Crosscutting.Entities.Dto.Layouts;
using GenAI.Crosscutting.Infra.Extensions.Abp;
using GenAI.Domain.Entities.Layouts;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GenAI.Core.Impl.Services.Layouts;

public class FileColumnLayoutDomainService : GenAIDomainServiceBase<FileColumnLayout, Guid, FileColumnLayoutDto>, IFileColumnLayoutDomainService
{
	private readonly IRepository<CorrespondingInformation, Guid> _correspondingInformationRepository;

	public FileColumnLayoutDomainService(
		IRepository<FileColumnLayout, Guid> repository,
		IRepository<CorrespondingInformation, Guid> correspondingInformationRepository)
	: base(repository)
	{
		_correspondingInformationRepository = correspondingInformationRepository;
	}


	public FileColumnLayoutDto GetFileColumnLayoutByIdAsync(Guid id)
	{
		var response = Repository.GetAll();
		response = response.Where(x => x.Id == id).Include(x => x.CorrespondingInformation);
		response = response.Include(x => x.FileLayout).ThenInclude(x => x.EntityType);
		response = response.Include(x => x.FileLayout).ThenInclude(x => x.System);

		return response.Select(x => new FileColumnLayoutDto
		{
			EntityDescription = x.FileLayout.EntityType.Description,
			SystemDescription = x.FileLayout.System.Description ?? string.Empty,
			ColumnKey = x.CorrespondingInformation.EntityProperties.GetHashCode(),
			ColumnName = x.CorrespondingInformation.EntityProperties.ToString(),
			ColumnDescription = x.CorrespondingInformation.Description,
			FileColumnName = x.Name,
			FileColumnPosition = x.Position,
			Id = x.Id
		})
		.FirstOrDefault();
	}

	public List<FileColumnLayoutDto> GetAllFileColumnLayoutsAsync()
	{
		var response = Repository.GetAll();
		response = response.Include(x => x.CorrespondingInformation);
		response = response.Include(x => x.FileLayout).ThenInclude(x => x.EntityType);
		response = response.Include(x => x.FileLayout).ThenInclude(x => x.System);

		return response.Select(x => new FileColumnLayoutDto
		{
			EntityDescription = x.FileLayout.EntityType.Description,
			SystemDescription = x.FileLayout.System.Description ?? string.Empty,
			ColumnKey = x.CorrespondingInformation.EntityProperties.GetHashCode(),
			ColumnName = x.CorrespondingInformation.EntityProperties.ToString(),
			ColumnDescription = x.CorrespondingInformation.Description,
			FileColumnName = x.Name,
			FileColumnPosition = x.Position,
			Id = x.Id
		})
		.OrderBy(x => x.FileColumnPosition)
		.ToList();
	}

	public List<FileColumnLayoutDto> GetFileColumnLayoutsOfEntityAsync(Guid fileLayoutId)
	{
		var response = Repository.GetAll();
		response = response.Where(x => x.FileLayoutId == fileLayoutId).Include(x => x.CorrespondingInformation);
		response = response.Include(x => x.FileLayout).ThenInclude(x => x.EntityType);
		response = response.Include(x => x.FileLayout).ThenInclude(x => x.System);

		return response.Select(x => new FileColumnLayoutDto
		{
			EntityDescription = x.FileLayout.EntityType.Description,
			SystemDescription = x.FileLayout.System.Description ?? string.Empty,
			ColumnKey = x.CorrespondingInformation.EntityProperties.GetHashCode(),
			ColumnName = x.CorrespondingInformation.EntityProperties.ToString(),
			ColumnDescription = x.CorrespondingInformation.Description,
			FileColumnName = x.Name,
			FileColumnPosition = x.Position,
			Id = x.Id
		})
		.OrderBy(x => x.FileColumnPosition)
		.ToList();
	}

	public async Task DeleteCorrespondingInformationAsync(Guid correspondingInformationId)
	{
		var correspondingInformation = await _correspondingInformationRepository.GetAsync(correspondingInformationId);

		correspondingInformation.IsActive = false;
		correspondingInformation.DeletionTime = DateTime.Now.NowTimeZone();
		correspondingInformation.DeletionUserId = UserId;

		var fileColunLayouts = Repository.GetAll();
		fileColunLayouts = fileColunLayouts.Where(x => x.CorrespondingInformationId == correspondingInformationId);
		var fileColumn = fileColunLayouts.FirstOrDefaultAsync().Result;

		fileColumn.IsActive = false;
		fileColumn.DeletionTime = DateTime.Now.NowTimeZone();
		fileColumn.DeletionUserId = UserId;

		await _correspondingInformationRepository.UpdateAsync(correspondingInformation);
		await base.UpdateAsync(fileColumn);
	}

	public async Task UpdateCorrespondingInformationAsync(UpdateCorrespondingInformationDto updateCorrespondingInformation)
	{
		if (updateCorrespondingInformation.Id == Guid.Empty)
			throw new UserFriendlyException(L("OBJECT_IDENTIFIER_NOT_FOUND"));
		if (string.IsNullOrEmpty(updateCorrespondingInformation.Description))
			throw new UserFriendlyException(L("FIELD_REQUIRED_TO_INCLUDE_ENTITY", nameof(updateCorrespondingInformation.Description)));

		var response = await _correspondingInformationRepository.GetAsync(updateCorrespondingInformation.Id)
			?? throw new UserFriendlyException(L("CORRESPONDING_INFORMATION_NOT_FOUND"));

		response.Description = updateCorrespondingInformation.Description;
		response.IsActive = updateCorrespondingInformation.IsActive;
		
		response.LastModificationTime = DateTime.Now.NowTimeZone();
		response.LastModifierUserId = UserId;

		if (updateCorrespondingInformation.IsActive)
		{
			response.DeletionTime = null;
			response.DeletionUserId = null;
		}
		else
		{
			response.DeletionTime = DateTime.Now.NowTimeZone();
			response.DeletionUserId = UserId;
		}

		await _correspondingInformationRepository.UpdateAsync(response);
	}

	public async Task UpdateFileColumnLayoutAsync(UpdateFileColumnLayoutDto updateFileColumnLayout)
	{
		if (updateFileColumnLayout.Id == Guid.Empty)
			throw new UserFriendlyException(L("OBJECT_IDENTIFIER_NOT_FOUND"));
		if (string.IsNullOrEmpty(updateFileColumnLayout.FileColumnName))
			throw new UserFriendlyException(L("FIELD_REQUIRED_TO_INCLUDE_ENTITY", nameof(updateFileColumnLayout.FileColumnName)));
		if (updateFileColumnLayout.FileColumnPosition <= 0)
			throw new UserFriendlyException(L("FIELD_REQUIRED_TO_INCLUDE_ENTITY", nameof(updateFileColumnLayout.FileColumnPosition)));

		var response = Repository.GetAll();
		var fileColumnResponse = response.Where(x => x.Id == updateFileColumnLayout.Id).Include(x => x.CorrespondingInformation);

		var fileColumnLayout = fileColumnResponse.FirstOrDefaultAsync().Result
			?? throw new UserFriendlyException(L("FILE_COLUMN_LAYOUT_NOT_FOUND"));

		fileColumnLayout.Name = updateFileColumnLayout.FileColumnName;
		fileColumnLayout.Position = updateFileColumnLayout.FileColumnPosition;
		fileColumnLayout.IsActive = updateFileColumnLayout.IsActive;
		
		fileColumnLayout.LastModificationTime = DateTime.Now.NowTimeZone();
		fileColumnLayout.LastModifierUserId = UserId;

		if (updateFileColumnLayout.IsActive)
		{
			fileColumnLayout.DeletionTime = null;
			fileColumnLayout.DeletionUserId = null;

			if (updateFileColumnLayout.UpdateCorrespondingInformation.Any())
				foreach (var item in updateFileColumnLayout.UpdateCorrespondingInformation)
					await UpdateCorrespondingInformationAsync(item);
		}
		else
		{
			fileColumnLayout.DeletionTime = DateTime.Now.NowTimeZone();
			fileColumnLayout.DeletionUserId = UserId;
			
			var fileColumns = response.Where(x => x.FileLayoutId == fileColumnLayout.FileLayoutId).Include(x => x.CorrespondingInformation);

			var correspondingInformation = fileColumns.Select(x => x.CorrespondingInformation).ToListAsync();

			var correspondingInformationList = new List<CorrespondingInformation>();
			foreach (var item in correspondingInformation.Result)
			{
				item.IsActive = false;
				item.DeletionTime = DateTime.Now.NowTimeZone();
				item.DeletionUserId = UserId;
				correspondingInformationList.Add(item);
			}
			_correspondingInformationRepository.BulkUpdate(correspondingInformationList);
		}

		await base.UpdateAsync(fileColumnLayout);
	}
}
