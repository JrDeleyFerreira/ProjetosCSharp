﻿using GenAI.Core.Contracts.Services.ImportSpreadsheets;
using GenAI.Core.Resources;
using GenAI.Crosscutting.Infra.Services;
using IronXL;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace GenAI.Core.Impl.Services.ImportSpreadsheets;

public class ImportSpreadsheetsService : BaseDomainService, IImportSpreadsheetsService
{
	public readonly IBlobService _blobService;

	public ImportSpreadsheetsService(IBlobService blobService) => _blobService = blobService;

	public bool HasTheExpectedColumnQuantity<TClass>(WorkBook workBook, string sheetName) where TClass : class
    {
		return GetHeaderRow(workBook, sheetName).Count == GetFieldNames<TClass>().Count;
    }

    public (bool isValid, string colunmName) GetAndValidateColumnNames<TClass>(WorkBook workBook, string sheetName) 
		where TClass : class
	{
		List<string> headerRow = GetHeaderRow(workBook, sheetName);
        var fieldNames = GetFieldNames<TClass>();

		//TODO: modificar essa verificação aqui para atender ao Layout
		//1 - Ter as informações de Posição e Nome do Layout informados via parâmetro, pode ser uma lista de tupla
		//2 - Verificar se na posição (index) informada pelo layout tem uma coluna com o mesmo nome que o configurado 
		for (var index = 0; index < fieldNames.Count; index++)
			if (!fieldNames.Contains(headerRow[index].Trim()) || !fieldNames[index].Equals(headerRow[index].Trim()))
				return (false, headerRow[index].Trim());

		return (true, string.Empty);
	}

	public MemoryStream TransformToStream(IFormFile formImport)
	{
		using var stream = new MemoryStream();
		formImport?.CopyTo(stream);
		var listaBytes = stream.ToArray();
		return new MemoryStream(listaBytes);
	}

	public async Task SaveInBlobStorageAsync(IFormFile formImport, string entityName)
	{
		var fileName = Path.GetFileName(formImport.FileName);
		var filePath = $"{entityName}/{Guid.NewGuid()}/{fileName}";
		var containerName = DataConstants.MatrizSod;

		await _blobService.CreateContainerIfNotExistsAsync(containerName);
		await _blobService.UploadFileToBlobAsync(formImport, filePath, containerName);
	}

	#region MÉTODOS PRIVADOS

	private List<string> GetFieldNames<TClass>() where TClass : class
	{
		var fieldNames = new List<string>();
		var propsEntity = typeof(TClass).GetProperties();

		fieldNames.AddRange(propsEntity
			.Where(property => property.CustomAttributes.FirstOrDefault()?.NamedArguments.FirstOrDefault()
				.ToString() is not null)
			.Select(property => property.CustomAttributes.FirstOrDefault()?.NamedArguments.FirstOrDefault()
				.ToString()!.Split("\"")[1]));

		return fieldNames;
	}

	private List<string> GetHeaderRow(WorkBook workBook, string sheetName)
	{
		var sheet = workBook.GetWorkSheet(sheetName) ?? workBook.WorkSheets[0];
		var headerRow = sheet.GetRow(0).Select(cell => cell.Text).ToList();
		return headerRow;
	} 

	#endregion
}
