﻿using Abp.Authorization;
using GenAI.Core.Impl.Services.Users;
using GenAI.Domain.Entities;

namespace GenAI.Core.Impl.Services.Authorization
{
    public class PermissionChecker : PermissionChecker<Role, User>
    {
        public PermissionChecker(UserManager userManager)
            : base(userManager)
        {
        }
    }
}


