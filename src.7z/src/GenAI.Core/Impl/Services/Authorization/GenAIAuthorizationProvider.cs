﻿using Abp.Authorization;
using Abp.Localization;
using Abp.MultiTenancy;
using GenAI.Crosscutting.Infra.Settings;

namespace GenAI.Core.Impl.Services.Authorization
{
    public class GenAIAuthorizationProvider : AuthorizationProvider
    {
        public override void SetPermissions(IPermissionDefinitionContext context)
        {
            context.CreatePermission(PermissionNames.Pages_Users, L("Users"));
            context.CreatePermission(PermissionNames.Pages_Roles, L("Roles"));
            context.CreatePermission(PermissionNames.Pages_Tenants, L("Tenants"), multiTenancySides: MultiTenancySides.Host);
            context.CreatePermission(PermissionNames.Analysts, L("Analysts"));
            context.CreatePermission(PermissionNames.Pages_Forecast, L("Forecasts"));
            context.CreatePermission(PermissionNames.Page_Admin, L("Admin"));
        }

        private static ILocalizableString L(string name)
        {
            return new LocalizableString(name, GenAIConsts.LocalizationLabelsSourceName);
        }
    }
}


