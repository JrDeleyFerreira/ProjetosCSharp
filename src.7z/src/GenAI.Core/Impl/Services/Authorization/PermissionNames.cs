﻿namespace GenAI.Core.Impl.Services.Authorization
{
    public static class PermissionNames
    {
        public const string Pages_Tenants = "Pages.Tenants";
        public const string Pages_Users = "Pages.Users";
        public const string Pages_Roles = "Pages.Roles";
        public const string Pages_Forecast = "Page.Forecast";
        public const string Page_Admin = "Page.Admin";

        public const string Analysts = "Analysts";
    }
}


