﻿using Abp.Application.Services.Dto;
using Abp.Domain.Repositories;
using Abp.UI;
using GenAI.Core.Contracts.Services.Collaborators;
using GenAI.Core.Contracts.Services.ImportedDocuments;
using GenAI.Core.Contracts.Services.ImportSpreadsheets;
using GenAI.Core.Impl.Services.Shared;
using GenAI.Core.Resources;
using GenAI.Core.Timing;
using GenAI.Crosscutting.Entities.Dto.Collaborators;
using GenAI.Crosscutting.Entities.Dto.ImportedDocuments;
using GenAI.Domain.Entities.Collaborators;
using IronXL;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace GenAI.Core.Impl.Services.Collaborators;

public class CollaboratorDomainService : GenAIDomainServiceBase<Collaborator, Guid, CollaboratorDto>, ICollaboratorDomainService
{
	private readonly IImportSpreadsheetsService _importSpreadsheetsService;
	private readonly IImportedDocumentDomainService _importedDocumentDomainService;

	public CollaboratorDomainService(
		IRepository<Collaborator, Guid> repository,
		IImportSpreadsheetsService importSpreadsheetsService,
		IImportedDocumentDomainService importedDocumentDomainService)
		: base(repository)
	{
		_importSpreadsheetsService = importSpreadsheetsService;
		_importedDocumentDomainService = importedDocumentDomainService;
	}

	public IQueryable<Collaborator> GetCollaborators()
		=> Repository.GetAll();

	public async Task<ResponseCollaboratorDto> InsertAsync(CreateCollaboratorDto collaborator)
	{
		var hasOtherRegisterWithTheSameRegistration = await ValidateCollaboratorFieldsAndExists(collaborator);

		if (hasOtherRegisterWithTheSameRegistration)
			throw new UserFriendlyException(L("RECORD_ALREADY_EXISTS"));

		var id = Guid.NewGuid();

		await Repository.InsertAsync(new Collaborator
		{
			Id = id,
			Key = collaborator.Key,
			Name = collaborator.Name,
			Supplier = collaborator.Supplier,
			Responsible = collaborator.Responsible,
			ContractExpirationDate = collaborator.ContractExpirationDate,
			Email = collaborator.Email,
			IsActive = true,
			CreationTime = DateTime.Now.NowTimeZone(),
			CreatorUserId = UserId,
		});

		return new ResponseCollaboratorDto { Id = id };
	}

	public override async Task DeleteAsync(Guid id)
	{
		var collaborator = await base.GetAsync(id) ?? throw new UserFriendlyException(L("COLLABORATOR_NOT_FOUND"));

		collaborator.IsActive = false;
		collaborator.DeletionTime = DateTime.Now.NowTimeZone();
		collaborator.DeletionUserId = UserId;

		await base.UpdateAsync(collaborator);
	}

	public PagedResultDto<CollaboratorDto> GetAllPaged(FilterCollaboratorDto filter)
	{
		var query = GetCollaborators();

		if (!string.IsNullOrEmpty(filter.Key))
			query = query.Where(x => x.Key.ToUpper().Contains(filter.Key.ToUpper()));

		if (!string.IsNullOrEmpty(filter.Name))
			query = query.Where(x => x.Name.ToUpper().Contains(filter.Name.ToUpper()));

		if (!string.IsNullOrEmpty(filter.Supplier))
			query = query.Where(x => x.Supplier.ToUpper().Contains(filter.Supplier.ToUpper()));

		if (!string.IsNullOrEmpty(filter.Responsible))
			query = query.Where(x => x.Responsible.ToUpper().Contains(filter.Responsible.ToUpper()));

		if (filter.IsActive.HasValue)
			query = query.Where(x => x.IsActive == filter.IsActive);

		query = GetOrder(query, filter.SortColumn, filter.IsAscending);

		return GetAllPaged(query, filter.Skip, filter.PageSize);
	}

	public async Task<CollaboratorDto> GetByIdAsync(Guid id)
	{
		var collaborator = await base.GetAsync(id) ?? throw new UserFriendlyException(L("COLLABORATOR_NOT_FOUND"));
        return MapToEntityDto(collaborator);
	}

	public async Task UpdateAsync(UpdateCollaboratorDto updateCollaborator)
	{
		var hasOtherRegisterWithTheSameRegistration = await ValidateCollaboratorFieldsAndExists(updateCollaborator);

		if (!hasOtherRegisterWithTheSameRegistration)
			throw new UserFriendlyException(L("COLLABORATOR_NOT_FOUND"));

		var collaborator = await GetCollaborators()
			.FirstOrDefaultAsync(x => x.Id == updateCollaborator.Id);

		collaborator.Key = updateCollaborator.Key;
		collaborator.Name = updateCollaborator.Name;
		collaborator.Responsible = updateCollaborator.Responsible;
		collaborator.Supplier = updateCollaborator.Supplier;
		collaborator.ContractExpirationDate = updateCollaborator.ContractExpirationDate;
		collaborator.Email = updateCollaborator.Email;
		collaborator.IsActive = updateCollaborator.IsActive;
		collaborator.LastModificationTime = DateTime.Now.NowTimeZone();
		collaborator.LastModifierUserId = UserId;

		if (updateCollaborator.IsActive)
		{
			collaborator.DeletionTime = null;
			collaborator.DeletionUserId = null;
		}
		else
		{
			collaborator.DeletionTime = DateTime.Now.NowTimeZone();
			collaborator.DeletionUserId = UserId;
		}

		await base.UpdateAsync(collaborator);
	}

	public async Task ImportSpreadsheetAsync(IFormFile formImport)
	{
		var fileExtension = Path.GetExtension(formImport.FileName);

		if (!DataConstants.SpreadsheetTypeExtension.Contains(fileExtension))
			throw new UserFriendlyException(L("INVALID_FILE_EXTENSION"));

		try
		{
			var streamFile = _importSpreadsheetsService.TransformToStream(formImport);
			var workBook = new WorkBook(streamFile);

            if (!_importSpreadsheetsService.HasTheExpectedColumnQuantity<CollaboratorDto>(workBook, DataConstants.EmployeeSheetName))
                throw new UserFriendlyException(L("INVALID_COLUMNS_QUANTITY_FROM_SPREEDSHEET"));

            var headerRow = _importSpreadsheetsService.GetAndValidateColumnNames<CollaboratorDto>
				(workBook, DataConstants.CollaboratorSheetName);

			if (!headerRow.isValid)
				throw new UserFriendlyException(L("INVALID_COLUNM_NAME", headerRow.colunmName));

			var listCollaborators = new List<Collaborator>();
			var listToDoesNotCreate = new List<Collaborator>();

			var workSheet = workBook.GetWorkSheet(DataConstants.CollaboratorSheetName) ?? workBook.WorkSheets[0];
			var rowCounter = workSheet.RowCount;

			for (var index = 1; index < rowCounter; index++)
			{
				var recoveredLine = workSheet.GetRow(index).Select(c => c.Text).ToList();

                if (recoveredLine[0].Equals(string.Empty) || recoveredLine[1].Equals(string.Empty) ||
                    recoveredLine[2].Equals(string.Empty) || recoveredLine[3].Equals(string.Empty))
                    continue;

                bool isDateConverted = DateTime.TryParse(recoveredLine[4], out var data);

				var collaborator = new Collaborator
				{
					Id = Guid.NewGuid(),
					Key = recoveredLine[0],
					Name = recoveredLine[1],
					Supplier = recoveredLine[2],
					Responsible = recoveredLine[3],
					ContractExpirationDate = (isDateConverted && !string.IsNullOrEmpty(recoveredLine[4])) ? data : null,
					Email = recoveredLine[5],
					IsActive = true,
					CreationTime = DateTime.Now.NowTimeZone(),
					CreatorUserId = UserId,
				};

				listCollaborators.Add(collaborator);
			}

            listToDoesNotCreate.AddRange(listCollaborators.Where(collaborator
                => GetCollaborators().FirstOrDefaultAsync(x
                    => x.Key.ToUpper().Equals(collaborator.Key.ToUpper())).Result is not null));

            var listToInactivate = GetCollaborators()
                .Where(x => !listCollaborators.Select(y => y.Key.ToUpper()).Contains(x.Key.ToUpper()))
                .ToList();

            listCollaborators.RemoveAll(item => listToDoesNotCreate.Contains(item));

            await _importSpreadsheetsService.SaveInBlobStorageAsync(formImport, nameof(Collaborator));

            var fileName = Path.GetFileName(formImport.FileName);
            await _importedDocumentDomainService.InsertAsync(new ImportedDocumentDto
            {
                FileName = fileName,
                FileExtension = fileExtension,
                EntityType = nameof(Collaborator)
            });

            if (listCollaborators.Any())
			{
				await base.BulkInsertAsync(listCollaborators);
			}

            if (listToDoesNotCreate.Any())
            {
                var listToUpdate = GetCollaborators()
					.Where(x => listToDoesNotCreate.Select(y => y.Key.ToUpper())
						.Contains(x.Key.ToUpper()))
					.ToList();

                listToUpdate.ForEach(x =>
                {
                    var item = listToDoesNotCreate.FirstOrDefault(y => y.Key.ToLower().Equals(x.Key.ToLower()));

                    x.Key = item.Key;
                    x.Name = item.Name;
                    x.Responsible = item.Responsible;
                    x.Supplier = item.Supplier;
                    x.ContractExpirationDate = item.ContractExpirationDate;
                    x.Email = item.Email;

                    x.LastModifierUserId = UserId;
                    x.LastModificationTime = DateTime.Now.NowTimeZone();
                    x.IsActive = true;

                    x.DeletionUserId = null;
                    x.DeletionTime = null;
                    x.IsActive = true;
                });

                base.BulkUpdate(listToUpdate);
            }

            if (listToInactivate.Any())
            {
                listToInactivate.ForEach(x =>
                {
                    x.DeletionUserId = UserId;
                    x.DeletionTime = DateTime.Now.NowTimeZone();
                    x.IsActive = false;
                });

                base.BulkUpdate(listToInactivate);
            }
        }
		catch (UserFriendlyException ex)
		{
			throw new UserFriendlyException($"{L("ERROR_IMPORTING_SPREADSHEET")} - {ex.Message}");
		}
	}

	public override IQueryable<Collaborator> GetOrder(IQueryable<Collaborator> entities, string sortColumn = "Id", bool ascending = true)
	{
		return sortColumn.ToUpper() switch
		{
			"KEY" => base.GetOrder(entities, o => o.Key, ascending),
			"NAME" => base.GetOrder(entities, o => o.Name, ascending),
			"SUPPLIER" => base.GetOrder(entities, o => o.Supplier, ascending),
			"RESPONSIBLE" => base.GetOrder(entities, o => o.Responsible, ascending),
			"ISACTIVE" => base.GetOrder(entities, o => o.IsActive, ascending),
			_ => base.GetOrder(entities, o => o.CreationTime, ascending),
		};
	}

	#region Métodos Privados

	private async Task<bool> ValidateCollaboratorFieldsAndExists(object collaborator)
	{
		bool hasOtherRegisterWithTheSameRegistration = false;

		switch (collaborator)
		{
			case CreateCollaboratorDto:
			{
				var createCollaborator = collaborator as CreateCollaboratorDto;

                if (string.IsNullOrEmpty(createCollaborator.Key))
					throw new UserFriendlyException(L("KEY_REQUIRED"));
                if (string.IsNullOrEmpty(createCollaborator.Name))
                    throw new UserFriendlyException(L("NAME_REQUIRED"));
                if (string.IsNullOrEmpty(createCollaborator.Supplier))
                    throw new UserFriendlyException(L("SUPPLIER_REQUIRED"));
                if (string.IsNullOrEmpty(createCollaborator.Responsible))
                    throw new UserFriendlyException(L("RESPONSIBLE_REQUIRED"));

				hasOtherRegisterWithTheSameRegistration = await GetCollaborators()
					.AnyAsync(x => x.Key.ToUpper().Equals(createCollaborator.Key.ToUpper()));

				break;
			}
			default:
			{
				var updateCollaborator = collaborator as UpdateCollaboratorDto;

                if (string.IsNullOrEmpty(updateCollaborator.Key))
                    throw new UserFriendlyException(L("KEY_REQUIRED"));
                if (string.IsNullOrEmpty(updateCollaborator.Name))
                    throw new UserFriendlyException(L("NAME_REQUIRED"));
                if (string.IsNullOrEmpty(updateCollaborator.Supplier))
                    throw new UserFriendlyException(L("SUPPLIER_REQUIRED"));
                if (string.IsNullOrEmpty(updateCollaborator.Responsible))
                    throw new UserFriendlyException(L("RESPONSIBLE_REQUIRED"));

                hasOtherRegisterWithTheSameRegistration = await GetCollaborators()
					.AnyAsync(x => x.Key.ToUpper().Equals(updateCollaborator.Key.ToUpper()));

				break;
			}
		}

		return hasOtherRegisterWithTheSameRegistration;
	}

	#endregion Métodos Privados
}
