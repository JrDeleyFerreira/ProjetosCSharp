﻿using Abp.Domain.Repositories;
using GenAI.Core.Contracts.Services.ImportedDocuments;
using GenAI.Core.Impl.Services.Shared;
using GenAI.Core.Timing;
using GenAI.Crosscutting.Entities.Dto.ImportedDocuments;
using GenAI.Domain.Entities.ImportedDocuments;
using Microsoft.EntityFrameworkCore;
using System;
using System.Threading.Tasks;

namespace GenAI.Core.Impl.Services.ImportedDocuments;

public class ImportedDocumentDomainService : GenAIDomainServiceBase<ImportedDocument, Guid, ImportedDocumentDto>,
	IImportedDocumentDomainService
{
	public ImportedDocumentDomainService(IRepository<ImportedDocument, Guid> repository) : base(repository)	{ }

	public async Task<bool> GetByKeyAsync(string entity, string name, string extension)
		=> await Repository.GetAll().AnyAsync
		(
			x => 
				x.EntityType.ToUpper().Equals(entity.ToUpper()) && 
				x.FileName.ToUpper().Equals(name.ToUpper()) && 
				x.FileExtension.ToLower().Equals(extension.ToLower())
		);
	
	
	public async Task InsertAsync(ImportedDocumentDto document)
		=> await Repository.InsertAsync(new ImportedDocument
			{
				Id = Guid.NewGuid(),
				EntityType = document.EntityType,
				FileName = document.FileName,
				FileExtension = document.FileExtension,
				CreationTime = DateTime.Now.NowTimeZone(),
				CreatorUserId = UserId,
			});

}
