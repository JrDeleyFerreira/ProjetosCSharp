﻿using Abp;
using Abp.Runtime.Session;
using Abp.UI;
using GenAI.Core.Contracts.Services.TwoFactor;
using GenAI.Core.Contracts.Services.TwoFactor.Mail;
using GenAI.Crosscutting.Infra.Extensions;
using GenAI.Crosscutting.Infra.Settings;
using System;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;

namespace GenAI.Core.Impl.Services.TwoFactor
{
    internal class TwoFactorDomainService : AbpServiceBase, ITwoFactorDomainService
    {
        private readonly IMailDomainService _mailService;
        private readonly IAbpSession _abpSession;

        public TwoFactorDomainService(IMailDomainService mailService, IAbpSession abpSession)
        {
            _mailService = mailService;
            _abpSession = abpSession;
            LocalizationSourceName = GenAIConsts.LocalizationMessagesSourceName;
        }

        public async Task<string> TwoFactorSendCode(string userEmail, string userName)
        {
                return await SendMailRegisterAsync(userEmail, userName);
        }

        public static string GetCode()
        {
            Random random = new Random();
            string codigo = "";

            for (int i = 0; i < 7; i++)
            {
                char letra = (char)('A' + random.Next(26));
                int numero = random.Next(1, 10);

                codigo += letra.ToString() + numero.ToString();
            }

            return codigo.Substring(0, 7);
        }
        private async Task<string> SendMailRegisterAsync(string userEmail, string userName)
        {
            var code = GetCode().ToString();

            await _mailService.SendAsync(await ComposesMessageNewRegistrants(userEmail, userName, code), default);

            return code.Encrypted();

        }

        private async Task<MailMessage> ComposesMessageNewRegistrants(string userEmail, string userName, string code)
        {
            var bodyContent = Properties.ResourceMail.send_code
               .Replace("[Template.Logo]", $"{GenAISettings.AppClientRootAddress}/assets/images/logo_affinity.png")
               .Replace("[Token.Mail.Subject]", L("TOKEN_MAIL_SUBJECT"))
               .Replace("[Template.Line0]", L("TOKEN_MAIL_TITLE"))
               .Replace("[Template.Line1]", L("TOKEN_MAIL_HELLO") + $", {userName}.")
               .Replace("[Template.Line2]", L("TOKEN_MAIL_MESSAGE"))
               .Replace("[COD]", code)
               .Replace("[Template.FooterLine]", L("TOKEN_MAIL_FOOTER"));

            var message = new MailMessage
            {
                Body = bodyContent,
                BodyEncoding = Encoding.UTF8,
                From = new MailAddress(GenAISettings.UserEmail, "Affinity Compass"),
                IsBodyHtml = true,
                Subject = L("TOKEN_MAIL_SUBJECT", code),
                SubjectEncoding = Encoding.UTF8
            };

            message.To.Add(new MailAddress(userEmail, $"{userName}"));

            return message;
        }
    }
}
