﻿using GenAI.Core.Contracts.Services.TwoFactor.Mail;
using GenAI.Crosscutting.Infra.Settings;
using MailKit;
using MimeKit;
using MimeKit.Text;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using MailKit.Security;

namespace GenAI.Core.Impl.Services.TwoFactor.Mail
{
    public class MailDomainService : IMailDomainService
    {
        private readonly ProtocolSettings _settings;

        public event EventHandler MessageSent;
        public MailDomainService()
        {
        }

        public MailDomainService(string host, int port, string userName = "", string password = "")
        {
            _settings = new ProtocolSettings
            {
                Host = host,
                Password = password,
                Port = port,
                Username = userName
            };
        }

        public MailDomainService(string host, int port, string protocol, string userName = "", string password = "")
        {
            _settings = new ProtocolSettings
            {
                Host = host,
                Password = password,
                Port = port,
                Username = userName,
                Protocol = protocol
            };
        }

        private void Send(MimeMessage message)
        {
            MailKit.Net.Smtp.SmtpClient smtpClient = BuildSenderClient(((MailboxAddress)message.From.First()).Address);
            smtpClient.MessageSent += delegate (object s, MessageSentEventArgs e)
            {
                MessageSent?.Invoke(s, e);
            };
            smtpClient.Send(message);
            smtpClient.Disconnect(quit: true);
        }

        public async Task SendAsync(string from, string recipients, string subject, string body, CancellationToken cancellationToken)
        {
            await SendAsync(CreateMessage(from, recipients, subject, body), cancellationToken);
        }

        public async Task SendAsync(MailMessage message, CancellationToken cancellationToken)
        {
            await SendAsync((MimeMessage)message, cancellationToken);
        }

        private async Task SendAsync(MimeMessage message, CancellationToken cancellationToken)
        {
            MailKit.Net.Smtp.SmtpClient client = BuildSenderClient(((MailboxAddress)message.From.First()).Address);
            client.MessageSent += delegate (object s, MessageSentEventArgs e)
            {
                MessageSent?.Invoke(s, e);
            };
            await client.SendAsync(message, cancellationToken);
            client.Disconnect(quit: true);
        }

        private MimeMessage CreateMessage(string from, string recipients, string subject, string body)
        {
            MimeMessage mimeMessage = new MimeMessage();
            mimeMessage.From.Add(new MailboxAddress(from));
            mimeMessage.To.AddRange(from x in recipients.Replace(",", ";").Split(';')
                                    select new MailboxAddress(x));
            mimeMessage.Subject = subject;
            mimeMessage.Body = new TextPart(TextFormat.Plain)
            {
                Text = body
            };
            return mimeMessage;
        }

        private MailKit.Net.Smtp.SmtpClient BuildSenderClient(string settingsKey)
        {
            NetworkCredential networkCredential = null;
            ProtocolSettings protocolSettings;
            if (_settings == null)
            {
                protocolSettings = MailConfigSettings.GetSendProtocolSettings(settingsKey).settings;
            }
            else
            {
                ProtocolSettings settings = _settings;
                protocolSettings = settings;
            }

            if (!string.IsNullOrEmpty(protocolSettings.Username) && !string.IsNullOrEmpty(protocolSettings.Password))
            {
                networkCredential = new NetworkCredential(protocolSettings.Username, protocolSettings.Password);
            }

            MailKit.Net.Smtp.SmtpClient smtpClient = new MailKit.Net.Smtp.SmtpClient();
            smtpClient.MessageSent += delegate (object s, MessageSentEventArgs e)
            {
                MessageSent?.Invoke(s, e);
            };
            smtpClient.Connect(protocolSettings.Host, protocolSettings.Port, SecureSocketOptions.SslOnConnect);
            if (networkCredential != null)
            {
                smtpClient.Authenticate(networkCredential);
            }

            return smtpClient;
        }
    }
}
