﻿using Abp.Application.Services.Dto;
using Abp.Dependency;
using Abp.Domain.Entities;
using Abp.Domain.Repositories;
using Abp.IdentityFramework;
using Abp.Linq.Extensions;
using Abp.Runtime.Session;
using GenAI.Core.Contracts.Services.Shared;
using GenAI.Crosscutting.Entities.Dto.Shared;
using GenAI.Crosscutting.Infra.Extensions.Abp;
using GenAI.Crosscutting.Infra.Settings;
using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace GenAI.Core.Impl.Services.Shared
{
    
    public abstract class GenAIDomainServiceBase<TEntity> :
        GenAIDomainServiceBase<TEntity, int, EntityDto<int>, EntityDto<int>>
        where TEntity : class, IEntity<int>
    {
        protected GenAIDomainServiceBase(IRepository<TEntity, int> repository) : base(repository)
        {

        }
    }
    public abstract class GenAIDomainServiceBase<TEntity, TPrimaryKey> :
        GenAIDomainServiceBase<TEntity, TPrimaryKey, EntityDto<TPrimaryKey>, EntityDto<TPrimaryKey>>
        where TEntity : class, IEntity<TPrimaryKey>
    {
        protected GenAIDomainServiceBase(IRepository<TEntity, TPrimaryKey> repository) : base(repository)
        {

        }
    }
    public abstract class GenAIDomainServiceBase<TEntity, TPrimaryKey, TEntityDto> :
        GenAIDomainServiceBase<TEntity, TPrimaryKey, TEntityDto, TEntityDto>
        where TEntity : class, IEntity<TPrimaryKey>
        where TEntityDto : IEntityDto<TPrimaryKey>
    {
        protected GenAIDomainServiceBase(IRepository<TEntity, TPrimaryKey> repository) : base(repository)
        {

        }
    }
    public abstract class GenAIDomainServiceBase<TEntity, TPrimaryKey, TEntityDto, TCreateInput> :
        GenAIDomainServiceBase<TEntity, TPrimaryKey, TEntityDto, TCreateInput, TEntityDto>
        where TEntity : class, IEntity<TPrimaryKey>
        where TEntityDto : IEntityDto<TPrimaryKey>
    {
        protected GenAIDomainServiceBase(IRepository<TEntity, TPrimaryKey> repository) : base(repository)
        {

        }
    }
    public abstract class GenAIDomainServiceBase<TEntity, TPrimaryKey, TEntityDto, TCreateInput, TUpdateDto> :
        GenAIDomainServiceBase<TEntity, TPrimaryKey, TEntityDto, TCreateInput, TUpdateDto, FilterPagedDto>
        where TEntity : class, IEntity<TPrimaryKey>
        where TEntityDto : IEntityDto<TPrimaryKey>
        where TUpdateDto : IEntityDto<TPrimaryKey>
    {
        protected GenAIDomainServiceBase(IRepository<TEntity, TPrimaryKey> repository) : base(repository)
        {

        }
    }
    public abstract class GenAIDomainServiceBase<TEntity, TPrimaryKey, TEntityDto, TCreateInput, TUpdateDto, TFilterGetPagedInput> :
        GenAIDomainServiceBase<TEntity, TPrimaryKey, TEntityDto, TCreateInput, TUpdateDto, TFilterGetPagedInput, EntityDto<TPrimaryKey>>
        where TEntity : class, IEntity<TPrimaryKey>
        where TEntityDto : IEntityDto<TPrimaryKey>
        where TUpdateDto : IEntityDto<TPrimaryKey>
        where TFilterGetPagedInput : FilterPagedDto
    {
        protected GenAIDomainServiceBase(IRepository<TEntity, TPrimaryKey> repository) : base(repository)
        {

        }
    }
    public abstract class GenAIDomainServiceBase<TEntity, TPrimaryKey, TEntityDto, TCreateInput, TUpdateInput, TFilterGetPagedInput, TListDto> :
        CrudDomainServiceBase<TEntity, TPrimaryKey, TEntityDto, TCreateInput, TUpdateInput>,
        IGenAIDomainServiceBase<TEntity, TPrimaryKey, TEntityDto, TCreateInput, TUpdateInput, TFilterGetPagedInput, TListDto>
        where TEntity : class, IEntity<TPrimaryKey>
        where TEntityDto : IEntityDto<TPrimaryKey>
        where TUpdateInput : IEntityDto<TPrimaryKey>
        where TFilterGetPagedInput : FilterPagedDto
        where TListDto : EntityDto<TPrimaryKey>, new()
    {
        protected IAbpSession Session;
        protected Guid TenantId => Session.GetTenant().HasValue ? Session.GetTenant().Value : Guid.Empty;
        protected long UserId => Session.GetUserId();

        protected GenAIDomainServiceBase(IRepository<TEntity, TPrimaryKey> repository) : base(repository)
        {
            LocalizationSourceName = GenAIConsts.LocalizationMessagesSourceName;
            Session = IocManager.Instance.Resolve<IAbpSession>();
        }

        public virtual async Task<TPrimaryKey> CreateAndGetIdAsync(TEntity entity)
        {
            return await Repository.InsertAndGetIdAsync(entity);
        }
        public virtual async Task<TPrimaryKey> CreateAndGetIdAsync(TCreateInput entityDto)
        {
            TEntity entity = MapToEntity(entityDto);
            return await Repository.InsertAndGetIdAsync(entity);
        }
        public virtual async Task<TEntity> CreateAsync(TEntity entity)
        {
            return await Repository.InsertAsync(entity);
        }
        public virtual async Task<TEntity> CreateAsync(TCreateInput entityDto)
        {
            TEntity entity = MapToEntity(entityDto);
            return await Repository.InsertAsync(entity);
        }
        public virtual async Task<IEnumerable<TEntity>> CreateInMassAsync(IEnumerable<TEntity> entities)
        {
            await BulkInsertAsync(entities.ToList());
            return entities;
        }
        public virtual async Task<IEnumerable<TEntity>> CreateInMassAsync(IEnumerable<TCreateInput> entitiesDto)
        {
            IEnumerable<TEntity> entities = ObjectMapper.Map<IEnumerable<TEntity>>(entitiesDto);
            entities = await CreateInMassAsync(entities);
            return entities;
        }

        public virtual async Task<TEntity> UpdateAsync(TEntity entity)
        {
            return await Repository.UpdateAsync(entity);
        }
        public virtual async Task<IEnumerable<TEntity>> UpdateAsync(IEnumerable<TEntity> entities)
        {
            var tasks = await Task.WhenAll(entities.Select(async e => await UpdateAsync(e)));
            var ret = tasks.Where(result => result != null).ToList();

            return ret;

        }
        public virtual async Task<TEntity> UpdateAsync(TUpdateInput entityDto, TEntity entity)
        {
            MapToEntity(entityDto, entity);
            return await Repository.UpdateAsync(entity);
        }
        public virtual async Task<TEntity> UpdateAsync(TUpdateInput entityDto)
        {
            TEntity entity = await GetAsync(entityDto.Id);
            MapToEntity(entityDto, entity);
            return await Repository.UpdateAsync(entity);
        }

        public virtual TEntity GetIncluding(TPrimaryKey id, params Expression<Func<TEntity, object>>[] propertySelectors)
        {
            IQueryable<TEntity> entity = Repository.GetAllIncluding(propertySelectors);
            return entity.FirstOrDefault(x => x.Id.Equals(id));
        }

        public virtual async Task DeleteAsync(TPrimaryKey id)
        {
            TEntity entity = await GetAsync(id);
            await Repository.DeleteAsync(entity);
        }

        public virtual async Task DeleteAsync(TEntity entity)
        {
            await Repository.DeleteAsync(entity);
        }

        public virtual async Task<TEntity> GetAsync(TPrimaryKey id)
        {
            return await Repository.GetAsync(id);
        }
        public virtual TEntity GetSync(TPrimaryKey id)
        {
            return Repository.Get(id);
        }

        public virtual async Task<IEnumerable<TEntity>> GetAllAsync()
        {
            return await Repository.GetAllListAsync();
        }
        public virtual async Task<IEnumerable<TEntity>> GetAllAsync(Func<TEntity, object> sortingExpression, bool ascending = true)
        {
            var entities = await GetAllAsync();
            entities = GetOrder(entities, sortingExpression, ascending);
            return entities;
        }
        public virtual IQueryable<TEntity> GetAll()
        {
            return Repository.GetAll();
        }

        public virtual IQueryable<TEntity> GetAll(Expression<Func<TEntity, object>> sortingExpression, bool ascending = true)
        {
            return GetOrder(GetAll(), sortingExpression, ascending);
        }
        public virtual PagedResultDto<TEntityDto> GetAllPaged(IQueryable<TEntity> entities, int pageNumber, int itemsPerPage)
        {
            var totalCount = Count(entities);
            var query = entities.PageBy(pageNumber, itemsPerPage);

            return new PagedResultDto<TEntityDto> { TotalCount = totalCount, Items = query.AsEnumerable().Select(MapToEntityDto).ToList() };
        }
        public virtual PagedResultDto<TEntityDto> GetAllPaged(IQueryable<TEntity> entities, int pageNumber, int itemsPerPage, Expression<Func<TEntity, object>> sortingExpression, bool ascending = true)
        {
            var totalCount = Count(entities);
            var query = entities.PageBy(pageNumber, itemsPerPage);
            query = GetOrder(query, sortingExpression, ascending);
            return new PagedResultDto<TEntityDto> { TotalCount = totalCount, Items = query.AsEnumerable().Select(MapToEntityDto).ToList() };
        }
        public virtual PagedResultDto<TEntityDto> GetAllPaged(TFilterGetPagedInput filter)
        {
            IQueryable<TEntity> entities = CreateQueryFilter(filter);
            PagedResultDto<TEntityDto> result = GetAllPaged(entities, filter.PageNumber, filter.PageSize);
            return result;
        }
        public virtual PagedResultDto<TListDto> GetPaged(TFilterGetPagedInput filter)
        {
            IQueryable<TListDto> entities = CreateFilter(filter);
            PagedResultDto<TListDto> result = GetAllPaged(entities, filter.PageNumber, filter.PageSize);
            return result;
        }
        public virtual PagedResultDto<TListDto> GetAllPaged(IQueryable<TListDto> entities, int pageNumber, int itemsPerPage)
        {
            IQueryable<TListDto> query = entities.PageBy(pageNumber, itemsPerPage);
            int totalCount = entities.Count();

            return new PagedResultDto<TListDto> { TotalCount = totalCount, Items = query.ToList() };
        }
        public virtual PagedResultDto<TListDto> GetAllPaged(IQueryable<TListDto> entities, int pageNumber, int itemsPerPage, Expression<Func<TListDto, object>> sortingExpression, bool ascending = true)
        {
            IQueryable<TListDto> query = entities.PageBy(pageNumber, itemsPerPage);
            query = GetOrder(query, sortingExpression, ascending);
            int totalCount = entities.Count();
            return new PagedResultDto<TListDto> { TotalCount = totalCount, Items = query.ToList() };
        }
        public virtual int Count(Expression<Func<TEntity, bool>> predicate)
        {
            return Repository.Count(predicate);
        }
        public virtual async Task<int> CountAsync(Expression<Func<TEntity, bool>> predicate)
        {
            return await Repository.CountAsync(predicate);
        }

        public virtual int Count(IQueryable<TEntity> entities)
        {
            return entities.Count();
        }

        public virtual IQueryable<TEntity> CreateQueryFilter(TFilterGetPagedInput filter)
        {
            IQueryable<TEntity> query = GetAll();
            query = GetOrder(query);
            return query;
        }
        public virtual IQueryable<TListDto> CreateFilter(TFilterGetPagedInput filter)
        {
            IQueryable<TListDto> query = GetAll().Select(s => new TListDto());
            query = GetOrder(query);
            return query;
        }
        public virtual IQueryable<TEntity> GetOrder(IQueryable<TEntity> entities, string sortColumn = "Id", bool ascending = true)
        {
            return GetOrder(entities, o => o.Id, ascending);
        }
        public virtual IQueryable<TEntity> GetOrder(IQueryable<TEntity> entities, Expression<Func<TEntity, object>> sortingExpression, bool ascending = true)
        {
            return ascending ? entities.OrderBy(sortingExpression) : entities.OrderByDescending(sortingExpression);
        }

        public virtual IEnumerable<TEntity> GetOrder(IEnumerable<TEntity> entities, string sortColumn = "Id", bool ascending = true)
        {
            return GetOrder(entities, o => o.Id, ascending);
        }
        public virtual IEnumerable<TEntity> GetOrder(IEnumerable<TEntity> entities, Func<TEntity, object> sortingExpression, bool ascending = true)
        {
            return ascending ? entities.OrderBy(sortingExpression) : entities.OrderByDescending(sortingExpression);
        }

        public virtual IQueryable<TListDto> GetOrder(IQueryable<TListDto> entities, string sortColumn = "Id", bool ascending = true)
        {
            return GetOrder(entities, o => o.Id, ascending);
        }
        public virtual IQueryable<TListDto> GetOrder(IQueryable<TListDto> entities, Expression<Func<TListDto, object>> sortingExpression, bool ascending = true)
        {
            return ascending ? entities.OrderBy(sortingExpression) : entities.OrderByDescending(sortingExpression);
        }

        public virtual IEnumerable<TListDto> GetOrder(IEnumerable<TListDto> entities, string sortColumn = "Id", bool ascending = true)
        {
            return GetOrder(entities, o => o.Id, ascending);
        }
        public virtual IEnumerable<TListDto> GetOrder(IEnumerable<TListDto> entities, Func<TListDto, object> sortingExpression, bool ascending = true)
        {
            return ascending ? entities.OrderBy(sortingExpression) : entities.OrderByDescending(sortingExpression);
        }
        protected TDestination Map<TDestination>(object obj) where TDestination : class
        {
            return ObjectMapper.Map<TDestination>(obj);
        }

        public virtual void BulkUpdate(IList<TEntity> entities)
        {
            Repository.BulkUpdate(entities);
        }

        public virtual void BulkInsert(IList<TEntity> entities)
        {
            Repository.BulkInsert(entities);
        }
        public virtual async Task BulkInsertAsync(IList<TEntity> entities)
        {
            await Repository.BulkInsertAsync(entities);
        }

        public virtual async Task DeletesAsync(List<TPrimaryKey> ids)
        {
            foreach (TPrimaryKey id in ids)
            {
                await Repository.DeleteAsync(id);
            }
        }
        protected virtual void CheckErrors(IdentityResult identityResult)
        {
            identityResult.CheckErrors(LocalizationManager);
        }
    }
}
