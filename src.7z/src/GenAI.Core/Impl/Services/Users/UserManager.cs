﻿using Abp.Authorization;
using Abp.Authorization.Users;
using Abp.Configuration;
using Abp.Domain.Repositories;
using Abp.Domain.Uow;
using Abp.Localization;
using Abp.Organizations;
using Abp.Runtime.Caching;
using GenAI.Core.Impl.Services.Roles;
using GenAI.Domain.Entities;
using GenAI.Domain.Entities.Tokens;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace GenAI.Core.Impl.Services.Users
{
    public class UserManager : AbpUserManager<Role, User>
    {
        private readonly IRepository<Token, Guid> _TokenRepository;
        private readonly IWebHostEnvironment _Env;

        public UserManager(
            RoleManager roleManager,
            UserStore store,
            IOptions<IdentityOptions> optionsAccessor,
            IPasswordHasher<User> passwordHasher,
            IEnumerable<IUserValidator<User>> userValidators,
            IEnumerable<IPasswordValidator<User>> passwordValidators,
            ILookupNormalizer keyNormalizer,
            IdentityErrorDescriber errors,
            IServiceProvider services,
            ILogger<UserManager<User>> logger,
            IPermissionManager permissionManager,
            IUnitOfWorkManager unitOfWorkManager,
            ICacheManager cacheManager,
            IRepository<OrganizationUnit, long> organizationUnitRepository,
            IRepository<UserOrganizationUnit, long> userOrganizationUnitRepository,
            IRepository<Token, Guid> tokenRepository,
            IOrganizationUnitSettings organizationUnitSettings,
            ISettingManager settingManager,
            IWebHostEnvironment env,
            ILanguageManager languageManager,
            IRepository<UserLogin, long> userLoginRepository
            )
            : base(
                roleManager,
                store,
                optionsAccessor,
                passwordHasher,
                userValidators,
                passwordValidators,
                keyNormalizer,
                errors,
                services,
                logger,
                permissionManager,
                unitOfWorkManager,
                cacheManager,
                organizationUnitRepository,
                userOrganizationUnitRepository,
                organizationUnitSettings,
                settingManager, userLoginRepository)
        {
            _TokenRepository = tokenRepository;
            _Env = env;
            LocalizationSourceName = "Messages";
        }
        public async Task<Token> CreateToken(Token token)
        {
            token.Id = Guid.NewGuid();
            token.Created = DateTime.Now;
            return await _TokenRepository.InsertAsync(token);
        }
        public async Task<Token> GetToken(Guid id)
        {
            return await _TokenRepository.GetAsync(id);
        }

        public async Task<bool> IsAdmin(long userId)
        {
            var user = await GetUserByIdAsync(userId);
            var roles = await GetRolesAsync(user);

            return roles.Contains("Admin");
        }

        public async Task<bool> IsCurador(long userId)
        {
            var user = await GetUserByIdAsync(userId);
            var roles = await GetRolesAsync(user);

            return roles.Contains("Curador");
        }
    }
}


