﻿using Abp.Application.Services.Dto;
using Abp.Domain.Repositories;
using Abp.Linq.Extensions;
using Abp.UI;
using GenAI.Core.Contracts.Services.Users;
using GenAI.Core.Impl.Services.Shared;
using GenAI.Crosscutting.Entities.Dto.Users;
using GenAI.Crosscutting.Infra.Settings;
using GenAI.Crosscutting.Infra.Util;
using GenAI.Domain.Entities;
using GenAI.Domain.Entities.Tenants;
using Microsoft.EntityFrameworkCore;
using Microsoft.Identity.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Threading.Tasks;

namespace GenAI.Core.Impl.Services.Users;

public class UserDomainService : GenAIDomainServiceBase<User, long, UserDto, CreateUserDto, UpdateUserDto, FilterUserDto>, IUserDomainService
{
    private readonly UserManager _UserManager;
    private readonly Microsoft.Graph.GraphServiceClient _GraphClient;
    private readonly IRepository<TenantUser> _TenantUserRepository;
    public UserDomainService(
        IRepository<User, long> repository,
        UserManager userManager,
        IRepository<TenantUser> tenantUserRepository
        ) : base(repository)
    {
        _UserManager = userManager;
        _TenantUserRepository = tenantUserRepository;
        _GraphClient = GetAuthenticatedClient();
    }

    public override async Task<User> CreateAsync(CreateUserDto entityDto)
    {        
        User user = GetUserObj(entityDto);
        await ValidateCreateUser(user);

        string password = PasswordGenerator.GeneratePassword(true, true, true, true, 8);
        user = await CreateUserAsync(user, password, entityDto.RoleNames);
        await SendInvitation(entityDto.EmailAddress);

        return user;

    }
    public override async Task<User> UpdateAsync(UpdateUserDto entityDto)
    {
        User user = await _UserManager.GetUserByIdAsync(entityDto.Id);
        user.Name = entityDto.Name;
        user.EmailAddress = entityDto.EmailAddress;
        user.UserName = entityDto.UserName;
        user.IsActive = entityDto.IsActive;

        await UpdateUserAsync(entityDto, entityDto.Id);

        return user;
    }
    
    public async Task<User> UpdateStatusAsync(UpdateUserStatusDto entityDto)
    {
        
        User user = await _UserManager.GetUserByIdAsync(entityDto.Id);
        user.IsActive = entityDto.IsActive;

        CheckErrors(await _UserManager.UpdateAsync(user));
    
        return user;
    }
    private Microsoft.Graph.GraphServiceClient GetAuthenticatedClient()
    {
        string clientId = GenAISettings.AzureAdClientId;
        string tenantId = GenAISettings.AzureAdTenantId;
        string clientSecret = GenAISettings.AzureAdClientSecret;
        string[] scopes = new string[] { "https://graph.microsoft.com/.default" };

        IConfidentialClientApplication confidentialClient = ConfidentialClientApplicationBuilder
            .Create(clientId)
            .WithAuthority($"https://login.microsoftonline.com/{tenantId}/v2.0")
            .WithClientSecret(clientSecret)
            .Build();

        Microsoft.Graph.GraphServiceClient graphServiceClient =
            new(new Microsoft.Graph.DelegateAuthenticationProvider(async (requestMessage) =>
                {
                    AuthenticationResult authResult = await confidentialClient.AcquireTokenForClient(scopes).ExecuteAsync();
                    requestMessage.Headers.Authorization =
                        new AuthenticationHeaderValue("Bearer", authResult.AccessToken);
                })
            );
        return graphServiceClient;
    }
    private async Task SendInvitation(string email)
    {
        try
        {
            Microsoft.Graph.Invitation invitation = new Microsoft.Graph.Invitation
            {
                InvitedUserEmailAddress = email,
                InviteRedirectUrl = GenAISettings.AppClientRootAddress
            };

            Microsoft.Graph.Invitation statusInvitation = await _GraphClient.Invitations
                .Request().AddAsync(invitation);

            if (statusInvitation.Status == "PendingAcceptance" || statusInvitation.Status == "Completed")
            {
                Microsoft.Graph.User userToAdd = await _GraphClient.Users[statusInvitation.InvitedUser.Id].Request().GetAsync();
                await _GraphClient.Groups[GenAISettings.AzureAdGroupId].Members.References.Request().AddAsync(userToAdd);
            }
        }
        catch (Exception)
        {
            // ignored
        }
    }
    private async Task ValidateCreateUser(User userDto)
    {
        var user = await _UserManager.FindByEmailAsync(userDto.EmailAddress);
        if (user is not null)
        { 
            throw new UserFriendlyException(L("USER_ALREADY_EXIST")); 
        }
    }

    private async Task<User> CreateUserAsync(User user, string password, string[] roleNames, bool disableValidations = false)
    {
        if (disableValidations)
        {
            _UserManager.UserValidators.Clear();
        }
        try
        {
            var userCreated = await _UserManager.CreateAsync(user, password);
            CheckErrors(userCreated);
            if (roleNames != null)
            {
                CheckErrors(await _UserManager.SetRolesAsync(user, roleNames));
            }
            return user;
        }
        catch (Exception r)
        {

            throw new UserFriendlyException(r.Message, r);
        }
        

    }
    private async Task<User> UpdateUserAsync(UpdateUserDto entityDto, long userId)
    {
        User user = await _UserManager.GetUserByIdAsync(userId);
        user.Name = entityDto.Name;
        user.EmailAddress = entityDto.EmailAddress;
        user.UserName = entityDto.UserName;
        user.IsActive = entityDto.IsActive;
        CheckErrors(await _UserManager.UpdateAsync(user));

        if (entityDto.RoleNames != null)
        {
            CheckErrors(await _UserManager.SetRolesAsync(user, entityDto.RoleNames));
        }
        return user;
    }

    public override async Task<User> GetAsync(long id)
    {
        User user = await _UserManager.GetUserByIdAsync(id);
        return user;
    }

    private User GetUserObj(CreateUserDto entityDto)
    {
        User user = new()
        {
            EmailAddress = entityDto.EmailAddress,
            Name = entityDto.Name,
            UserName = entityDto.UserName,
            TenantId = Session.TenantId,
            IsEmailConfirmed = true,
            Surname = entityDto.Surname
        };
        return user;
    }
    public override PagedResultDto<UserDto> GetAllPaged(FilterUserDto filter)
    {
        IQueryable<User> users = CreateQueryFilter(filter);
        users = GetOrder(users, filter.SortColumn, filter.IsAscending);

        PagedResultDto<UserDto> pagedResultDto = GetAllPaged(users, filter.Skip, filter.PageSize);

        return pagedResultDto;
    }
    public override IQueryable<User> CreateQueryFilter(FilterUserDto filter)
    {
        IQueryable<User> users = null;
        if (_UserManager.IsAdmin(UserId).Result)
        {
            users = Repository.GetAll()
                .WhereIf(!string.IsNullOrEmpty(filter.UserName), p => p.UserName == filter.UserName)
                .WhereIf(!string.IsNullOrEmpty(filter.Email), p => p.EmailAddress == filter.Email)
                .WhereIf(!string.IsNullOrEmpty(filter.Name), p => EF.Functions.Like(p.Name, $"%{filter.Name}%"));
        }
        else
        {
            users = _TenantUserRepository.GetAllIncluding(n => n.User)
                .Where(n => n.TenantId == TenantId)
                .Select(n => n.User)
                .WhereIf(!string.IsNullOrEmpty(filter.UserName), p => p.UserName == filter.UserName)
                .WhereIf(!string.IsNullOrEmpty(filter.Email), p => p.EmailAddress == filter.Email)
                .WhereIf(!string.IsNullOrEmpty(filter.Name), p => EF.Functions.Like(p.Name, $"%{filter.Name}%"));
        }

        return users;
    }

    public async Task<UserDto> GetUserWithTenants(long userId)
    {
        User user = await GetAsync(userId);
        IList<string> roles = await _UserManager.GetRolesAsync(user);
        UserDto userDto = Map<UserDto>(user);
        userDto.RoleNames = roles.ToArray();
        return userDto;

    }

    public override IQueryable<User> GetOrder(IQueryable<User> entities, string sortColumn = "Id", bool ascending = true)
    {
        switch (sortColumn.ToUpper())
        {
            case "NAME":
                return base.GetOrder(entities, o => o.Name, ascending);
            case "EID":
                return base.GetOrder(entities, o => o.UserName, ascending);
            case "EMAIL":
                return base.GetOrder(entities, o => o.EmailAddress, ascending);
            default:
                return base.GetOrder(entities, o => o.Name, ascending);
        }
    }

    public async Task<User> CreateGuestUserAsync(CreateUserDto entityDto)
    {
        var user = ObjectMapper.Map<User>(entityDto);
        user.IsEmailConfirmed = true;
        string password = PasswordGenerator.GeneratePassword(true, true, true, true, 8);
        user = await CreateUserAsync(user, password, entityDto.RoleNames, true);
        return user;

    }

}