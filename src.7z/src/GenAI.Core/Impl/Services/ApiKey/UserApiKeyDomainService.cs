﻿    using System;
using System.Linq;
using System.Threading.Tasks;
using Abp.Application.Services.Dto;
using Abp.Domain.Repositories;
using Abp.Linq.Extensions;
using Abp.UI;
using GenAI.Core.Contracts.Services.ApiKey;
using GenAI.Core.Impl.Services.Shared;
using GenAI.Core.Impl.Services.Users;
using GenAI.Core.Timing;
using GenAI.Crosscutting.Entities.Dto.ApiKeys;
using GenAI.Crosscutting.Infra.Util;
using GenAI.Domain.Entities.ApiKey;
using Microsoft.EntityFrameworkCore;

namespace GenAI.Core.Impl.Services.ApiKey;

public class UserApiKeyDomainService : GenAIDomainServiceBase<UserApiKey, Guid, UserApiKeyDto>, IUserApiKeyDomainService
{
    private readonly IRepository<UserApiKey, Guid> _UserApiKeyRepository;
    private readonly UserManager _UserManager;
    public UserApiKeyDomainService(IRepository<UserApiKey, Guid> userApiKeyRepository, UserManager userManager) : base(userApiKeyRepository)
    {
        _UserApiKeyRepository = userApiKeyRepository;
        _UserManager = userManager;
    }
    public async Task<UserApiKeyDto> CreateUserApiKey(CreateUserApiKeyDto entity)
    {
        var dbUserApiKey = await DeleteDuplicateApiKey(entity);

        UserApiKey userApiKey = ObjectMapper.Map<UserApiKey>(entity);
        userApiKey.Id = Guid.NewGuid();
        userApiKey.UserId = UserId;
        userApiKey.Key = Util.GenerateApiKey(Guid.NewGuid(), DateTime.Now.NowTimeZone(), UserId);

        userApiKey = await _UserApiKeyRepository.InsertAsync(userApiKey);
        return ObjectMapper.Map<UserApiKeyDto>(userApiKey);
    }

    public async Task<bool> DeleteApiKeyAsync(Guid userApiKeyId)
    {
        var apiKey = await ValidateApiKeyExist(userApiKeyId);

        if (apiKey != null)
        {

            await Repository.DeleteAsync(apiKey);

            return true;

        }

        throw new UserFriendlyException(L("USER_APIKEY_NOT_FOUND"));
    }

    public Task<UserApiKeyDto> GetUserApiKeyByKey(string key)
    {
        UserApiKey userApiKey = _UserApiKeyRepository.FirstOrDefault(x => x.Key.Equals(key));
        if (userApiKey == null) throw new UserFriendlyException(L("API_KEY_INVALID"));
        if (userApiKey.Expiration < DateTime.Today) throw new UserFriendlyException(L("API_KEY_EXPIRED"));

        return Task.FromResult(ObjectMapper.Map<UserApiKeyDto>(userApiKey));
    }

    public PagedResultDto<UserApiKeyDto> GetAllApiKeyPaged(FilterApiKeyDto filter)
    {
        IQueryable<UserApiKey> apiKeys = CreateQueryApiKeyFilter(filter);
        apiKeys = GetOrder(apiKeys, filter.SortColumn, filter.IsAscending);

        PagedResultDto<UserApiKeyDto> pagedResultDto = GetAllPaged(apiKeys, filter.Skip, filter.PageSize);

        return pagedResultDto;
    }

    public IQueryable<UserApiKey> CreateQueryApiKeyFilter(FilterApiKeyDto filter)
    {
        IQueryable<UserApiKey> apiKeys = null;
        DateTime expirationEnd = getExpirationEnd(filter);
        if (_UserManager.IsAdmin(UserId).Result)
        {
            apiKeys = _UserApiKeyRepository.GetAll().Include(x => x.User)
                .WhereIf(!string.IsNullOrEmpty(filter.Name), p => EF.Functions.Like(p.Name, $"%{filter.Name}%"));
        }
        else
        {
            apiKeys = _UserApiKeyRepository.GetAll()
                .Include(x => x.User)
                .Where(x => x.UserId == UserId)              
                .WhereIf(!string.IsNullOrEmpty(filter.Name), p => EF.Functions.Like(p.Name, $"%{filter.Name}%"));
                
        }

        return apiKeys.Where(y => y.Expiration >= filter.ExpirationStart && y.Expiration <= expirationEnd);
    }

    private static DateTime getExpirationEnd(FilterApiKeyDto filter)
    {
        if (filter.ExpirationStart == DateTime.MinValue && filter.ExpirationEnd == DateTime.MinValue)
        {
            return DateTime.MaxValue;
        }
        else if (filter.ExpirationStart != DateTime.MinValue && filter.ExpirationEnd == DateTime.MinValue) 
        {
            return filter.ExpirationStart;
        }
        else
        {
            return filter.ExpirationEnd;
        }
    }

    public override IQueryable<UserApiKey> GetOrder(IQueryable<UserApiKey> entities, string sortColumn = "Id", bool ascending = true)
    {
        switch (sortColumn.ToUpper())
        {
            case "NAME":
                return base.GetOrder(entities, o => o.Name, ascending);
            default:
                return base.GetOrder(entities, o => o.Name, ascending);
        }
    }

    private async Task<bool> DeleteDuplicateApiKey(CreateUserApiKeyDto apiKey)
    {

        var listApiKey = await _UserApiKeyRepository.GetAllListAsync(p => p.UserId == UserId);
        foreach (var key in listApiKey)
        {
            await _UserApiKeyRepository.DeleteAsync(key);
        }
        return true;
    }

    private async Task<UserApiKey> ValidateApiKeyExist(Guid userApiKeyId)
    {
        var apiKeyExist = await base.Repository.FirstOrDefaultAsync(p => p.Id == userApiKeyId);

        if (apiKeyExist == null) throw new UserFriendlyException(L("USER_APIKEY_NOT_FOUND"));

        return apiKeyExist;
    }

    public Guid? GetApiKeyByUser()
    {
        var apiKey = _UserApiKeyRepository.GetAllListAsync(p => p.UserId == UserId).Result.FirstOrDefault();
        if(apiKey == null)
        {
            return null;
        }
        return apiKey.Id;
    }
}