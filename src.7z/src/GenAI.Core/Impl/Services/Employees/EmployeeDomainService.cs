﻿using Abp.Application.Services.Dto;
using Abp.Domain.Repositories;
using Abp.UI;
using GenAI.Core.Contracts.Services.Employees;
using GenAI.Core.Impl.Services.Shared;
using GenAI.Core.Timing;
using GenAI.Crosscutting.Entities.Dto.Employees;
using GenAI.Domain.Entities.Employees;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace GenAI.Core.Impl.Services.Employees;

public class EmployeeDomainService : GenAIDomainServiceBase<Employee, Guid, EmployeeDto>, IEmployeeDomainService
{
	public EmployeeDomainService(IRepository<Employee, Guid> repository) : base(repository) { }

	public IQueryable<Employee> GetEmployees()
		=> Repository.GetAll();

	public async Task<ResponseEmployeeDto> InsertAsync(CreateEmployeeDto createEmployee)
	{
		var hasOtherRegisterWithTheSameRegistration = await ValidateEmployeeFieldsAndExists(createEmployee);
		if (hasOtherRegisterWithTheSameRegistration)
			throw new UserFriendlyException(L("RECORD_ALREADY_EXISTS"));

		var id = Guid.NewGuid();

		await Repository.InsertAsync(new Employee
		{
			Id = id,
			EmployeeCode = createEmployee.EmployeeCode,
			Registration = createEmployee.Registration,
			Name = createEmployee.Name,
			AdmissionDate = createEmployee.AdmissionDate,
			EmploymentContract = createEmployee.EmploymentContract,
			Email = createEmployee.Email,
			IsActive = true,
			CreationTime = DateTime.Now.NowTimeZone(),
			CreatorUserId = UserId
		});

		return new ResponseEmployeeDto { Id = id };
	}

	public override async Task DeleteAsync(Guid id)
	{
		var employee = await Repository.GetAsync(id);

		employee.IsActive = false;
		employee.DeletionTime = DateTime.Now.NowTimeZone();
		employee.DeletionUserId = UserId;

		await base.UpdateAsync(employee);
	}

	public async Task<EmployeeDto> GetByIdAsync(Guid id)
	{
		var employee = await base.GetAsync(id);
		return MapToEntityDto(employee);
	}

	public PagedResultDto<EmployeeDto> GetAllPaged(FilterEmployeeDto filter)
	{
		var query = GetEmployees();

		if (filter.EmployeeCode != 0)
			query = query.Where(x => x.EmployeeCode == filter.EmployeeCode);

		if (!string.IsNullOrEmpty(filter.Name))
			query = query.Where(x => x.Name.Contains(filter.Name));

		if (!string.IsNullOrEmpty(filter.Email))
			query = query.Where(x => x.Email.Contains(filter.Email));

		if (filter.IsActive.HasValue)
			query = query.Where(x => x.IsActive == filter.IsActive);

		query = GetOrder(query, filter.SortColumn, filter.IsAscending);

		return GetAllPaged(query, filter.Skip, filter.PageSize);

	}

	public async Task UpdateAsync(UpdateEmployeeDto updateEmployee)
	{
		var hasOtherRegisterWithTheSameRegistration = await ValidateEmployeeFieldsAndExists(updateEmployee);
		if (!hasOtherRegisterWithTheSameRegistration)
			throw new UserFriendlyException(L("RECORD_ALREADY_EXISTS"));

		var employee = await GetEmployees().FirstOrDefaultAsync(x => x.EmployeeCode == updateEmployee.EmployeeCode);

		employee.Registration = updateEmployee.Registration;
		employee.Name = updateEmployee.Name;
		employee.EmploymentContract = updateEmployee.EmploymentContract;
		employee.Email = updateEmployee.Email;

		employee.IsActive = updateEmployee.IsActive;
		employee.LastModificationTime = DateTime.Now.NowTimeZone();
		employee.LastModifierUserId = UserId;

		if (updateEmployee.IsActive)
		{
			employee.DeletionTime = null;
			employee.DeletionUserId = null;
		}
		else
		{
			employee.DeletionTime = DateTime.Now.NowTimeZone();
			employee.DeletionUserId = UserId;
		}

		await base.UpdateAsync(employee);
	}

	public override IQueryable<Employee> GetOrder(IQueryable<Employee> entities, string sortColumn = "Id", bool ascending = true)
		=> sortColumn.ToUpper() switch
		{
			"EMPLOYEECODE" => base.GetOrder(entities, o => o.EmployeeCode, ascending),
			"NAME" => base.GetOrder(entities, o => o.Name, ascending),
			"EMAIL" => base.GetOrder(entities, o => o.Email, ascending),
			"ISACTIVE" => base.GetOrder(entities, o => o.IsActive, ascending),
			_ => base.GetOrder(entities, o => o.CreationTime, ascending),
		};


	#region Métodos privados

	private async Task<bool> ValidateEmployeeFieldsAndExists(object employee)
	{
		bool hasOtherRegisterWithTheSameRegistration = false;

		switch (employee)
		{
			case CreateEmployeeDto createEmployee:
			{
				var propertiesOfEntity = createEmployee.GetType().GetProperties()
						.Where(x =>
							!x.Name.Equals(nameof(createEmployee.EmployeeCode)) ||
							!x.Name.Equals(nameof(createEmployee.AdmissionDate)));

				var listOfFieldsEmpty = propertiesOfEntity
						.Where(p => string.IsNullOrWhiteSpace(p.GetValue(employee)?.ToString()))
						.Select(p => p.Name)
						.ToList();

				if (createEmployee.EmployeeCode == 0)
					listOfFieldsEmpty.Add(nameof(createEmployee.EmployeeCode));
				if (createEmployee.AdmissionDate == DateTime.MinValue)
					listOfFieldsEmpty.Add(nameof(createEmployee.AdmissionDate));

				if (listOfFieldsEmpty.Any())
				{
					var fields = string.Join(", ", listOfFieldsEmpty);
					throw new UserFriendlyException(L("FIELD_REQUIRED_TO_INCLUDE_ENTITY", fields));
				}

				hasOtherRegisterWithTheSameRegistration = await GetEmployees().AnyAsync(x => x.EmployeeCode == createEmployee.EmployeeCode);
				break;
			}
			case UpdateEmployeeDto updateEmployee:
			{
				var propertiesOfEntity = updateEmployee.GetType().GetProperties()
						.Where(x =>
							!x.Name.Equals(nameof(updateEmployee.EmployeeCode)) ||
							!x.Name.Equals(nameof(updateEmployee.AdmissionDate)));

				var listOfFieldsEmpty = propertiesOfEntity
						.Where(p => string.IsNullOrWhiteSpace(p.GetValue(employee)?.ToString()))
						.Select(p => p.Name)
						.ToList();

				if (updateEmployee.EmployeeCode == 0)
					listOfFieldsEmpty.Add(nameof(updateEmployee.EmployeeCode));
				if (updateEmployee.AdmissionDate == DateTime.MinValue)
					listOfFieldsEmpty.Add(nameof(updateEmployee.AdmissionDate));

				if (listOfFieldsEmpty.Any())
				{
					var fields = string.Join(", ", listOfFieldsEmpty);
					throw new UserFriendlyException(L("FIELD_REQUIRED_TO_INCLUDE_ENTITY", fields));
				}

				hasOtherRegisterWithTheSameRegistration = await GetEmployees().AnyAsync(x => x.EmployeeCode == updateEmployee.EmployeeCode);
				break;
			}
		}

		return hasOtherRegisterWithTheSameRegistration;
	}
	
	#endregion Métodos privados
}