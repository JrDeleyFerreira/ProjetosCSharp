﻿using Abp.Domain.Repositories;
using GenAI.Core.Contracts.Services.Language;
using GenAI.Core.Impl.Services.Shared;
using GenAI.Domain.Entities.Langague;
using System.Linq;

namespace GenAI.Core.Impl.Services.Language
{
    public class AppLanguageDomainService : GenAIDomainServiceBase<AppLanguage, int>, IAppLanguageDomainService
    {
        public AppLanguageDomainService(IRepository<AppLanguage> repository) : base (repository)
        {
        }

        public IQueryable<AppLanguage> GetApplicationLanguages() 
        {
            return Repository.GetAll().Where(x => x.IsDisabledDocument == false);
        }

    }
}
