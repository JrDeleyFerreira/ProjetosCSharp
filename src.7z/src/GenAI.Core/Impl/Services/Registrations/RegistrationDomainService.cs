﻿using Abp.Application.Services.Dto;
using Abp.Domain.Repositories;
using Abp.UI;
using GenAI.Core.Contracts.Services.Registrations;
using GenAI.Core.Impl.Services.Shared;
using GenAI.Core.Timing;
using GenAI.Crosscutting.Entities.Dto.Registrations;
using GenAI.Domain.Entities.Registrations;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace GenAI.Core.Impl.Services.Registrations;

public class RegistrationDomainService : GenAIDomainServiceBase<Registration, Guid, RegistrationDto>, IRegistrationDomainService
{
	public RegistrationDomainService(IRepository<Registration, Guid> repository) : base(repository)	{ }

	public IQueryable<Registration> GetRegistrations() => 
		Repository.GetAll();

	public async Task<RegistrationResponseDto> Create(CreateRegistrationDto registrationDto)
    {
        ValidateToCreate(registrationDto);

        var id = Guid.NewGuid();

        await Repository.InsertAsync(new Registration
        {
            ValiaRegistration = registrationDto.ValiaRegistration,
            OfficialRegistration = registrationDto.OfficialRegistration,
            CreationTime = DateTime.Now.NowTimeZone(),
            Id = id,
            CreatorUserId = UserId,
            IsActive = true,
        });

        return new RegistrationResponseDto { Id = id };
    }

    public override async Task DeleteAsync(Guid id)
	{
		var registration = await base.GetAsync(id) ?? throw new UserFriendlyException(L("REGISTRATION_NOT_FOUND"));
		registration.IsActive = false;
		registration.DeletionTime = DateTime.Now.NowTimeZone();
		registration.DeletionUserId = UserId;
		await base.UpdateAsync(registration);
	}

	public PagedResultDto<RegistrationDto> GetAllPaged(FilterRegistrationDto filter)
	{
		var query = GetRegistrations();

		if (!string.IsNullOrEmpty(filter.ValiaRegistration))
			query = query.Where(x => x.ValiaRegistration.ToUpper().Contains(filter.ValiaRegistration.ToUpper()));

		if (!string.IsNullOrEmpty(filter.OfficialRegistration))
			query = query.Where(x => x.OfficialRegistration.ToUpper().Contains(filter.OfficialRegistration.ToUpper()));

		if (filter.IsActive.HasValue)
			query = query.Where(x => x.IsActive == filter.IsActive.Value);

		query = GetOrder(query, filter.SortColumn, filter.IsAscending);

		return GetAllPaged(query, filter.Skip, filter.PageSize);
	}

	public async Task<RegistrationDto> GetByIdAsync(Guid id)
	{
		var registration = await base.GetAsync(id) ?? throw new UserFriendlyException(L("REGISTRATION_NOT_FOUND"));
		return MapToEntityDto(registration);
	}

	public async Task UpdateAsync(UpdateRegistrationRequestDto registrationDto)
    {
        ValidateToUpdate(registrationDto);

        var register = await base.GetAsync(registrationDto.Id);

        if (register == null)
            throw new UserFriendlyException(L("REGISTRATION_NOT_FOUND"));

        register.ValiaRegistration = registrationDto.ValiaRegistration;
        register.OfficialRegistration = registrationDto.OfficialRegistration;
        register.IsActive = registrationDto.IsActive;
        register.LastModificationTime = DateTime.Now.NowTimeZone();
        register.LastModifierUserId = UserId;

        if (registrationDto.IsActive)
        {
            register.DeletionTime = null;
            register.DeletionUserId = null;
        }
        else
        {
            register.DeletionTime = DateTime.Now.NowTimeZone();
            register.DeletionUserId = UserId;
        }

        await base.UpdateAsync(register);
    }

    public override IQueryable<Registration> GetOrder(IQueryable<Registration> entities, string sortColumn = "Id", bool ascending = true)
	{
		return sortColumn.ToUpper() switch
		{
			"VALIAREGISTRATION" => base.GetOrder(entities, o => o.ValiaRegistration, ascending),
			"OFFICIALREGISTRATION" => base.GetOrder(entities, o => o.OfficialRegistration, ascending),
			"CREATIONTIME" => base.GetOrder(entities, o => o.CreationTime, ascending),
			_ => base.GetOrder(entities, o => o.CreationTime, ascending),
		};
	}

    #region MÉTODOS PRIVADOS

    private void ValidateToCreate(CreateRegistrationDto registrationDto)
    {
        if (string.IsNullOrEmpty(registrationDto.ValiaRegistration))
            throw new UserFriendlyException(L("VALIA_REGISTRATION_REQUIRED"));
        if (string.IsNullOrEmpty(registrationDto.OfficialRegistration))
            throw new UserFriendlyException(L("OFFICIAL_REGISTRATION_REQUIRED"));

        var register = GetRegistrations()
            .Where(x => x.ValiaRegistration.ToUpper().Equals(registrationDto.ValiaRegistration.ToUpper())
                || x.OfficialRegistration.ToUpper().Equals(registrationDto.OfficialRegistration.ToUpper()))
            .FirstOrDefault();

        if (register != null)
        {
            if (registrationDto.ValiaRegistration.ToUpper() == register.ValiaRegistration.ToUpper())
                throw new UserFriendlyException(L("VALIA_REGISTRATION_DUPLICATE"));
            if (registrationDto.OfficialRegistration.ToUpper() == register.OfficialRegistration.ToUpper())
                throw new UserFriendlyException(L("OFFICIAL_REGISTRATION_DUPLICATE"));
        }
    }

    private void ValidateToUpdate(UpdateRegistrationRequestDto registrationDto)
    {
        if (string.IsNullOrEmpty(registrationDto.ValiaRegistration))
            throw new UserFriendlyException(L("VALIA_REGISTRATION_REQUIRED"));
        if (string.IsNullOrEmpty(registrationDto.OfficialRegistration))
            throw new UserFriendlyException(L("OFFICIAL_REGISTRATION_REQUIRED"));

        var register = GetRegistrations()
            .Where(x => (x.ValiaRegistration.ToUpper().Equals(registrationDto.ValiaRegistration.ToUpper())
                || x.OfficialRegistration.ToUpper().Equals(registrationDto.OfficialRegistration.ToUpper()))
                && x.Id != registrationDto.Id)
            .FirstOrDefault();

        if(register != null)
        {
            if(registrationDto.ValiaRegistration.ToUpper() == register.ValiaRegistration.ToUpper())
                throw new UserFriendlyException(L("VALIA_REGISTRATION_DUPLICATE"));
            if(registrationDto.OfficialRegistration.ToUpper() == register.OfficialRegistration.ToUpper())
                throw new UserFriendlyException(L("OFFICIAL_REGISTRATION_DUPLICATE"));
        }
    }
    
    #endregion
}
