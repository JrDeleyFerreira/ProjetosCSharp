﻿using System;

namespace GenAI.CrossCutting.Infra.Excel
{
    public class Class1
    {
    }
}
