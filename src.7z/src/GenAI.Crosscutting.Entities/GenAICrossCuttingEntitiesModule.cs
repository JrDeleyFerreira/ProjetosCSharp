﻿using Abp.AutoMapper;
using Abp.Modules;
using Abp.Reflection.Extensions;
using System.Reflection;

namespace GenAI.Crosscutting.Entities
{
    public class GenAICrossCuttingEntitiesModule : AbpModule
    {
        public override void Initialize()
        {
            Assembly thisAssembly = typeof(GenAICrossCuttingEntitiesModule).GetAssembly();

            Configuration.Modules.AbpAutoMapper().Configurators.Add(
                // Scan the assembly for classes which inherit from AutoMapper.Profile
                cfg => cfg.AddMaps(thisAssembly)
            );
        }
    }
}
