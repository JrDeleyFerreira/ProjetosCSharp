﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenAI.Crosscutting.Entities.Constants
{
    public sealed class WorkItemType
    {
        public readonly string Epic = "Epic";
        public readonly string Feature = "Feature";
        public readonly string UserStory = "User Story";
        public readonly string Issue = "Issue";
        public readonly string ProductBacklogItem = "Product Backlog Item";
        public readonly string Requirement = "Requirement";
        public readonly string Task = "Task";
        public readonly string Bug = "Bug";
    }
}
