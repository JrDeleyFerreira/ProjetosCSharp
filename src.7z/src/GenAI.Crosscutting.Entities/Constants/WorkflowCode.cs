﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenAI.Crosscutting.Entities.Constants
{
    public sealed class WorkflowCode
    {
        public static readonly string CLASSIFICATION = "CD_WRFL_CLASSIFICATION";
        public static readonly string SUMMARIZATION = "CD_WRFL_SAMPLE_SUMMARIZATION";
        public static readonly string INDEXER = "CD_WRFL_INDEXER";
        private WorkflowCode()
        {
            
        }

        public sealed class WorkflowStepProperty
        {
            // CLASSIFICATION
            public static readonly string CD_CLASSIFICATION_TEXT_CLASSIFICATION = "CD_CLASSIFICATION_text_classification";
            public static readonly string CD_CLASSIFICATION_INPUT_PROMPT_STRING = "CD_CLASSIFICATION_input_prompt_string";
            public static readonly string CD_CLASSIFICATION_INPUT_LIST_STRING = "CD_CLASSIFICATION_input_list_string";

            // SUMMARIZATION
            public static readonly string CD_SUMMARIZATION_INPUT_TEXT_STRING = "CD_SUMMARIZATION_input_text_string";

        }
    }
}
