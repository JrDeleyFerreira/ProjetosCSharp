﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenAI.Crosscutting.Entities.Constants
{
    public static class WorkItemFields
    {
        public const string Title = "/fields/System.Title";
        public const string Description = "/fields/System.Description";
        public const string State = "/fields/System.State";
        public const string AreaPath = "/fields/System.AreaPath";
        public const string IterationPath = "/fields/System.IterationPath";
        public const string Priority = "/fields/Microsoft.VSTS.Common.Priority";
        public const string WorkItemType = "/fields/System.WorkItemType";
        public const string AssignedTo = "/fields/System.AssignedTo";
        public const string Tags = "/fields/System.Tags";
        public const string ReproSteps = "/fields/Microsoft.VSTS.TCM.ReproSteps";
        public const string Severity = "/fields/Microsoft.VSTS.Common.Severity";
        public const string BusinessValue = "/fields/Microsoft.VSTS.Common.BusinessValue";
        public const string Effort = "/fields/Microsoft.VSTS.Scheduling.Effort";
        public const string AcceptanceCriteria = "/fields/Microsoft.VSTS.Common.AcceptanceCriteria";
    }
}
