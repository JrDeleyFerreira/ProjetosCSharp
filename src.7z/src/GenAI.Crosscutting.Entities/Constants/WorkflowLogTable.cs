﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenAI.Crosscutting.Entities.Constants
{
    public class WorkflowLogTable
    {
        public static readonly string LOG_WORKFLOWS = "LogWorkflows";
    }
}
