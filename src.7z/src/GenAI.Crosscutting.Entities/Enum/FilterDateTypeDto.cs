﻿namespace GenAI.Crosscutting.Entities.Enum
{
    public enum FilterDateTypeDto
    {
        Dmy = 1,
        Mdy = 2
    }
}

