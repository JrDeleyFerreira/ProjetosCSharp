﻿using System.ComponentModel;

namespace GenAI.Crosscutting.Entities.Enum
{
    public enum IndicatorFilter
    {
        [Description("OverdueIndicator")]
        Overdue = 1,
        [Description("BlockedIndicator")]
        Blocked = 2,
        [Description("NegotiatedIndicator")]
        Negotiated = 3,
        [Description("FollowUpIndicator")]
        FollowUp = 4,
        [Description("ContactIndicator")]
        NewClient = 5
    }
}


