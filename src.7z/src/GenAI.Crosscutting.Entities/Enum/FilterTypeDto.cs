﻿namespace GenAI.Crosscutting.Entities.Enum
{
    public enum FilterTypeDto
    {
        String,
        Int,
        Date,
        Double
    }
}

