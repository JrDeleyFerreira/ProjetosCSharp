﻿using System.ComponentModel;

namespace GenAI.Crosscutting.Entities.Enum
{
    public enum LanguageFilter
    {
        [Description("PT")]
        PT,
        [Description("EN")]
        EN
    }
}


