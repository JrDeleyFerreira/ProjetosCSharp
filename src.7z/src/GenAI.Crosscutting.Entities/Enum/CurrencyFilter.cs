﻿using System.ComponentModel;

namespace GenAI.Crosscutting.Entities.Enum
{
    public enum CurrencyFilter
    {
        [Description("BRL")]
        BRL,
        [Description("USD")]
        USD
    }
}


