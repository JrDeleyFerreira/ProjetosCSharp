﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenAI.Crosscutting.Entities.Enum
{
    public enum StatusForm
    {
        New = 0,
        Active = 1,
        Completed = 2
    }
}
