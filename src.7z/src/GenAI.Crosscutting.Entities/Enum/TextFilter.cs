﻿using System.ComponentModel;

namespace GenAI.Crosscutting.Entities.Enum
{
    public enum TextFilter
    {
        [Description("TextDescription")]
        TextDescription
    }
}


