﻿namespace GenAI.Crosscutting.Entities.Enum
{
    public enum SapStatus
    {
        Started,
        Finished
    }
}


