﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenAI.Crosscutting.Entities.Enum
{
    public enum QuestionStatus
    {
        Pending = 0,
        Answered = 1,
    }
}
