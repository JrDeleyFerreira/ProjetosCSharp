﻿namespace GenAI.Crosscutting.Entities.Enum
{
    public enum FilterIncludeDto
    {
        Exclude,
        Include
    }
}


