﻿namespace GenAI.Crosscutting.Entities.Enum
{
    public enum TypeHours
    {
        Hour = 1,
        PercentageMonth = 2
    }
}
