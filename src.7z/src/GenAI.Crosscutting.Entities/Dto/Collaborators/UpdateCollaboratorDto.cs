﻿using System;

namespace GenAI.Crosscutting.Entities.Dto.Collaborators;

public class UpdateCollaboratorDto
{
    public Guid Id { get; set; }
    public string Key { get; set; }
    public string Name { get; set; }
	public string Supplier { get; set; }
	public string Responsible { get; set; }
	public DateTime? ContractExpirationDate { get; set; }
	public string Email { get; set; }
    public bool IsActive { get; set; }
}
