﻿using Abp.Application.Services.Dto;
using Abp.AutoMapper;
using GenAI.Domain.Entities.Collaborators;
using System;
using System.ComponentModel.DataAnnotations;

namespace GenAI.Crosscutting.Entities.Dto.Collaborators;

[AutoMapFrom(typeof(Collaborator))]
public class CollaboratorDto : EntityDto<Guid>
{
	[Display(Name = "Chave")]
	public string Key { get; set; }

	[Display(Name = "Nome")]
	public string Name { get; set; }

	[Display(Name = "Fornecedor")]
	public string Supplier { get; set; }

	[Display(Name = "Responsável")]
	public string Responsible { get; set; }

	[Display(Name = "Data de Previsão de Vencimento do Contrato")]
	public DateTime? ContractExpirationDate { get; set; }

	[Display(Name = "Email")]
	public string Email { get; set; }

	public bool IsActive { get; set; }
	public DateTime CreationTime { get; set; }
}
