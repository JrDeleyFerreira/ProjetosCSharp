﻿using System;

namespace GenAI.Crosscutting.Entities.Dto.Collaborators;

public class ResponseCollaboratorDto
{
	public Guid Id { get; set; }
}
