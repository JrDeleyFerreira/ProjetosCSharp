﻿using System;
using Abp.Application.Services.Dto;
using Abp.AutoMapper;
using GenAI.Domain.Entities.ApiKey;

namespace GenAI.Crosscutting.Entities.Dto.ApiKeys;
[AutoMapFrom(typeof(UserApiKey))]
public class UserApiKeyDto : EntityDto<Guid>
{
    public string Name { get; set; }
    public string UserName { get; set; }
    public string Key { get; set; }
    public long UserId { get; set; }
    public DateTime Expiration { get; set; }
}