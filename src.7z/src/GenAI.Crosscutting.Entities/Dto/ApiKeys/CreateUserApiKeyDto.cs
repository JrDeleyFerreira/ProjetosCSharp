﻿using System;
using Abp.AutoMapper;
using GenAI.Domain.Entities.ApiKey;

namespace GenAI.Crosscutting.Entities.Dto.ApiKeys;
[AutoMapTo(typeof(UserApiKey))]
public class CreateUserApiKeyDto
{
    public string Name { get; set; }
    public DateTime Expiration { get; set; }
}