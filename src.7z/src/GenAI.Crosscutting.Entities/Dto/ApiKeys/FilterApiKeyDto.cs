﻿using GenAI.Crosscutting.Entities.Dto.Shared;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenAI.Crosscutting.Entities.Dto.ApiKeys
{
    public class FilterApiKeyDto : FilterPagedDto
    {
        public string Name { get; set; }
        public DateTime ExpirationStart { get; set; }
        public DateTime ExpirationEnd { get; set; }
    }
}
