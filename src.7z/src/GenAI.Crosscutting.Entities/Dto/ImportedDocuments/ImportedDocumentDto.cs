﻿using Abp.Application.Services.Dto;
using Abp.AutoMapper;
using GenAI.Domain.Entities.ImportedDocuments;
using System;

namespace GenAI.Crosscutting.Entities.Dto.ImportedDocuments;

[AutoMapFrom(typeof(ImportedDocument))]
public class ImportedDocumentDto : EntityDto<Guid>
{
    public string EntityType { get; set; }
    public string FileName { get; set; }
    public string FileExtension { get; set; }
}
