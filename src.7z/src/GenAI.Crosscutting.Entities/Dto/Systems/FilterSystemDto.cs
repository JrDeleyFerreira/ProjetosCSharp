﻿using GenAI.Crosscutting.Entities.Dto.Shared;

namespace GenAI.Crosscutting.Entities.Dto.Systems
{
    public class FilterSystemDto : FilterPagedDto
    {
        public string Description { get; set; }
        public bool? IsActive { get; set; }
    }
}
