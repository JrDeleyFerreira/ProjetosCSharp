﻿using GenAI.Crosscutting.Entities.Dto.Shared;
using System;

namespace GenAI.Crosscutting.Entities.Dto.Systems
{
    public class FilterSodMatrixDto : FilterPagedDto
    {
        public Guid? SystemId { get; set; }
        public Guid? GroupId { get; set; }
        public bool? IsActive { get; set; }
    }
}
