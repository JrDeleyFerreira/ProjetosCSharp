﻿using GenAI.Crosscutting.Entities.Dto.Shared;
using System;

namespace GenAI.Crosscutting.Entities.Dto.Systems
{
    public class FilterSystemGroupDto : FilterPagedDto
    {
        public string Description { get; set; }
        public bool? IsActive { get; set; }
        public Guid? SystemId { get; set; }
    }
}
