﻿using Abp.Application.Services.Dto;
using Abp.AutoMapper;
using GenAI.Domain.Entities.Systems;
using System;

namespace GenAI.Crosscutting.Entities.Dto.Systems
{
    [AutoMapFrom(typeof(BusinessSystem))]
    public class SystemDto : EntityDto<Guid>
    {
        public string Description { get; set; }
        public DateTime CreationTime { get; set; }
        public bool IsActive { get; set; }
    }
}
