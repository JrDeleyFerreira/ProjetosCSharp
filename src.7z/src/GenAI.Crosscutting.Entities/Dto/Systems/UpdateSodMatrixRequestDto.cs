﻿using System;

namespace GenAI.Crosscutting.Entities.Dto.Systems
{
    public class UpdateSodMatrixRequestDto
    {
        public Guid Id { get; set; }
        public Guid FirstGroupId { get; set; }
        public Guid SecondGroupId { get; set; }
        public string Comment { get; set; }
        public bool IsActive { get; set; }
    }
}
