﻿using System;

namespace GenAI.Crosscutting.Entities.Dto.Systems
{
    public class CreateSystemGroupRequestDto
    {
        public string Description { get; set; }
        public Guid SystemId { get; set; }
    }
}
