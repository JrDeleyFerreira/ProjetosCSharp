﻿using Abp.Application.Services.Dto;
using Abp.AutoMapper;
using GenAI.Domain.Entities.Systems;
using System;

namespace GenAI.Crosscutting.Entities.Dto.Systems
{
    [AutoMapFrom(typeof(SodMatrix))]
    public class SodMatrixDto : EntityDto<Guid>
    {
        public Guid FirstGroupId { get; set; }
        public Guid SecondGroupId { get; set; }
        public string Comment { get; set; }
        public bool IsActive { get; set; }
        public DateTime CreationTime { get; set; }

        public SystemGroupDto FirstGroup { get; set; }
        public SystemGroupDto SecondGroup { get; set; }
    }
}
