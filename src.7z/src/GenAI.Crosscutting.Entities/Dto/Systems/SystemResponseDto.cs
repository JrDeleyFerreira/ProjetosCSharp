﻿using System;

namespace GenAI.Crosscutting.Entities.Dto.Systems
{
    public class SystemResponseDto
    {
        public Guid Id { get; set; }
    }
}
