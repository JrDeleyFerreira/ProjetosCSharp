﻿using System;

namespace GenAI.Crosscutting.Entities.Dto.Systems
{
    public class CreateSodMatrixRequestDto
    {
        public Guid FirstGroupId { get; set; }
        public Guid SecondGroupId { get; set; }
        public string Comment { get; set; }
    }
}
