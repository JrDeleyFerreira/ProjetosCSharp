﻿namespace GenAI.Crosscutting.Entities.Dto.Systems
{
    public class CreateSystemRequestDto
    {
        public string Description { get; set; }
    }
}
