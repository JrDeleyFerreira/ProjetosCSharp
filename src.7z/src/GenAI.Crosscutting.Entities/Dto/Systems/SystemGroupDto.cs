﻿using Abp.Application.Services.Dto;
using Abp.AutoMapper;
using GenAI.Domain.Entities.Systems;
using System;

namespace GenAI.Crosscutting.Entities.Dto.Systems
{
    [AutoMapFrom(typeof(SystemGroup))]
    public class SystemGroupDto : EntityDto<Guid>
    {
        public string Description { get; set; }
        public Guid SystemId { get; set; }
        public DateTime CreationTime { get; set; }
        public bool IsActive { get; set; }
        public SystemDto System { get; set; }
    }
}
