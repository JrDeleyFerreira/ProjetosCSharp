﻿namespace GenAI.Crosscutting.Entities.Dto.Shared
{
    public abstract class FilterPagedDto
    {
        public string SortColumn { get; set; }
        public string SortOrder { get; set; }
        public int PageNumber { get; set; }
        public int PageSize { get; set; }
        public int Skip
        {
            get
            {

                int skip = PageSize * ((PageNumber + 1) - 1);

                return skip < 0 ? 0 : skip;
            }
        }
        public bool IsAscending => string.IsNullOrEmpty(SortOrder) || SortOrder.ToUpper().Equals("ASC");
    }
}


