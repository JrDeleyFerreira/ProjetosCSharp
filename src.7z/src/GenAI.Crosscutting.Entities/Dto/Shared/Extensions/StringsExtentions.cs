﻿using GenAI.Crosscutting.Entities.Dto.Shared.Exceptions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace GenAI.Crosscutting.Entities.Dto.Shared.Extensions
{
    public static class StringsExtentions
    {
        public static string ConvertToSnakeCase(this string obj)
        {
            if (obj == null)
            {
                throw new GenAiArgumentNullException();
            }
            var result = Regex.Replace(obj, @"[^a-zA-Z0-9]+", "_");
            return result.ToLower();
        }

    }
}
