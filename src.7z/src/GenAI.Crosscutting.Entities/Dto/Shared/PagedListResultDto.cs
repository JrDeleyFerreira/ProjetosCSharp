﻿using System.Collections.Generic;

namespace GenAI.Crosscutting.Entities.Dto.Shared
{
    public class PagedListResultDto<TEntity, TPrimaryKey>
    {
        public List<TEntity> Items { get; set; }

        public int TotalCount { get; set; }

        public PagedListResultDto()
        {

        }
        public PagedListResultDto(List<TEntity> list, int count)
        {
            Items = list;
            TotalCount = count;
        }
    }
}


