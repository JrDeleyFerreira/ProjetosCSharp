﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace GenAI.Crosscutting.Entities.Dto.Shared
{
    public class Month
    {
        public Month(DateTime firstDay, decimal hoursDay)
        {
            FirstDay = firstDay;
            WorkingDays = new List<DateTime>();
            WorkingDaysInterval = new List<DateTime>();
            HoursDay = hoursDay;
        }
        public decimal HoursDay { get; set; }
        public int MonthNumber => FirstDay.Month;
        public string MonthFormat => FirstDay.ToString("MMM/yyyy");
        public int TotalDays => DateTime.DaysInMonth(FirstDay.Year, MonthNumber);
        public int TotalWorkingDays => WorkingDays.Count;
        public int TotalWorkingDaysInterval => WorkingDaysInterval.Count;
        public DateTime FirstDay { get; set; }
        public DateTime LastDay => new DateTime(FirstDay.Year, FirstDay.Month, TotalDays);
        public DateTime FirstWorkingDay => WorkingDaysInterval.FirstOrDefault();
        public DateTime LastWorkingDay => WorkingDaysInterval.LastOrDefault();
        public List<DateTime> WorkingDays { get; set; }
        public List<DateTime> WorkingDaysInterval { get; set; }
        public List<DateTime> FullDays => ListDaysInterval(FirstDay, LastDay);
        public decimal WorkingHours => TotalWorkingDays * HoursDay;
        public decimal TotalHoursFirstPeriod => WorkingDays.Count(n => n >= FirstDay && n <= new DateTime(FirstDay.Year, MonthNumber, 15)) * HoursDay;
        public decimal TotalHoursSecondPeriod => WorkingDays.Count(n => n >= new DateTime(FirstDay.Year, MonthNumber, 16) && n <= LastDay) * HoursDay;
        public bool SplitPeriod => FirstWorkingDay.Day < 15 && LastWorkingDay.Day > 15;

        private List<DateTime> ListDaysInterval(DateTime initDate, DateTime endDate)
        {
            List<DateTime> dates = new List<DateTime>();
            dates.Add(initDate);

            if (initDate == endDate) return dates;

            while (initDate < endDate)
            {
                initDate = initDate.AddDays(1);
                dates.Add(initDate);
            }
            return dates;
        }
    }
}
