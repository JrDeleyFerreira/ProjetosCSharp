﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenAI.Crosscutting.Entities.Dto.Shared.Exceptions
{
    public class WorkflowTriggerGetWorkflowStartNewTemplateException: Exception
    {
        public WorkflowTriggerGetWorkflowStartNewTemplateException(string msg): base(msg)
        {
            
        }
    }
}
