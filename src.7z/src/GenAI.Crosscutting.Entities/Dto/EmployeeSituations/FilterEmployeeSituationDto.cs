﻿using GenAI.Crosscutting.Entities.Dto.Shared;

namespace GenAI.Crosscutting.Entities.Dto.EmployeeSituations;

public class FilterEmployeeSituationDto : FilterPagedDto
{
    public long? EmployeeCode { get; set; }
    public string Name { get; set; }
    public string RhStatus { get; set; }
    public string PayrollStatus { get; set; }
    public string ReferenceTime { get; set; }
    public bool? IsActive { get; set; }
    public string Email { get; set; }
}
