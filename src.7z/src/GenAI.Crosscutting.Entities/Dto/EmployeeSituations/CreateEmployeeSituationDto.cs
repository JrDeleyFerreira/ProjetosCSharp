﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace GenAI.Crosscutting.Entities.Dto.EmployeeSituations;

public sealed class CreateEmployeeSituationDto
{
	[Display(Name = "ID")]
	public long EmployeeCode { get; set; }

	[Display(Name = "Nome do Empregado")]
	public string Name { get; set; }

	[Display(Name = "Status RH")]
	public string RhStatus { get; set; }

	[Display(Name = "Status Folha")]
	public string PayrollStatus { get; set; }

	[Display(Name = "Data de Admissão")]
	public DateTime AdmissionDate { get; set; }

	[Display(Name = "Situação")]
	public string EmploymentContract { get; set; }

	[Display(Name = "Código da Posição")]
	public string PositionCode { get; set; }

	[Display(Name = "Descrição da Posição")]
	public string PositionDescription { get; set; }

	[Display(Name = "Cód. Departamento Empregado")]
	public string DepartmentCode { get; set; }

	[Display(Name = "Descrição do Departamento Empregado")]
	public string DepartmentDescription { get; set; }

	[Display(Name = "Centro de Custo")]
	public string CostCenter { get; set; }

	[Display(Name = "Gestor")]
	public string Manager { get; set; }

	[Display(Name = "Código Lotação (ID Estabelecimento)")]
	public string EstablishmentCode { get; set; }

	[Display(Name = "Descrição Lotação (CNPJ)")]
	public string EstablishmentCnpj { get; set; }

	[Display(Name = "Código Local de Trabalho")]
	public string WorkplaceCode { get; set; }

	[Display(Name = "Descrição Local de Trabalho")]
	public string WorkplaceDescription { get; set; }

	[Display(Name = "Estado do Local de Trabalho")]
	public string WorkplaceState { get; set; }

	[Display(Name = "Município do Local de Trabalho")]
	public string WorkplaceCity { get; set; }

	[Display(Name = "E-mail Comercial")]
	public string Email { get; set; }

	[Display(Name = "Mês de referência")]
	[JsonIgnore]
	public string ReferenceTime { get; set; }
}
