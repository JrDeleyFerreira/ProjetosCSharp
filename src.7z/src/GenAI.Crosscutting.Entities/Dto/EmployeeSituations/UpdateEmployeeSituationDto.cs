﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace GenAI.Crosscutting.Entities.Dto.EmployeeSituations;

public sealed class UpdateEmployeeSituationDto
{
	[Display(Name = "Key")]
	public long EmployeeCode { get; set; }

	[Display(Name = "Name")]
	public string Name { get; set; }

	[Display(Name = "RhState")]
	public string RhStatus { get; set; }

	[Display(Name = "PayrollState")]
	public string PayrollStatus { get; set; }

	[Display(Name = "AdmissionDate")]
	public DateTime AdmissionDate { get; set; }

	[Display(Name = "EmploymentContract")]
	public string EmploymentContract { get; set; }

	[Display(Name = "PositionCode")]
	public string PositionCode { get; set; }

	[Display(Name = "PositionDescription")]
	public string PositionDescription { get; set; }

	[Display(Name = "DepartmentCode")]
	public string DepartmentCode { get; set; }

	[Display(Name = "DepartmentDescription")]
	public string DepartmentDescription { get; set; }

	[Display(Name = "CostCenter")]
	public string CostCenter { get; set; }

	[Display(Name = "Manager")]
	public string Manager { get; set; }

	[Display(Name = "EstablishmentCode")]
	public string EstablishmentCode { get; set; }

	[Display(Name = "EstablishmentCnpj")]
	public string EstablishmentCnpj { get; set; }

	[Display(Name = "WorkplaceCode")]
	public string WorkplaceCode { get; set; }

	[Display(Name = "WorkplaceDescription")]
	public string WorkplaceDescription { get; set; }

	[Display(Name = "WorkplaceState")]
	public string WorkplaceState { get; set; }

	[Display(Name = "WorkplaceCity")]
	public string WorkplaceCity { get; set; }

	[Display(Name = "Email")]
	public string Email { get; set; }

	[Display(Name = "Reference")]
	[JsonIgnore]
	public string ReferenceTime { get; set; }

	[Display(Name = "Status")]
	public bool? IsActive { get; set; }
}
