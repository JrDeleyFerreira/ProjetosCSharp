﻿using System;

namespace GenAI.Crosscutting.Entities.Dto.EmployeeSituations;

public sealed class ResponseEmployeeSituationDto
{
    public Guid Id { get; set; }
}
