﻿using Abp.AutoMapper;
using GenAI.Domain.Entities.Tenants;
using System;

namespace GenAI.Crosscutting.Entities.Dto.Tenants
{
    [AutoMapTo(typeof(TenantUser))]
    public class CreateTenantUserDto
    {
        public Guid TenantId { get; set; }
        public long UserId { get; set; }
    }
}
