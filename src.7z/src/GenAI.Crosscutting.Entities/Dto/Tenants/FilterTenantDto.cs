﻿using GenAI.Crosscutting.Entities.Dto.Shared;

namespace GenAI.Crosscutting.Entities.Dto.Users;

public class FilterTenantDto : FilterPagedDto
{
    public string Name { get; set; }

}