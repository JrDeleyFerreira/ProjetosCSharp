﻿using Abp.AutoMapper;
using GenAI.Domain.Entities.Langague;

namespace GenAI.Crosscutting.Entities.Dto.Language
{
    [AutoMapFrom(typeof(AppLanguage))]
    public class AppLanguageDto
    {
        public string Name { get; set; }

        public string DisplayName { get; set; }
    }
}
