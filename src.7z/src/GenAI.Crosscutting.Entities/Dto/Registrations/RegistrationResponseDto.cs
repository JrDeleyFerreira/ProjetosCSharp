﻿using System;

namespace GenAI.Crosscutting.Entities.Dto.Registrations;

public class RegistrationResponseDto
{
	public Guid Id { get; set; }
}
