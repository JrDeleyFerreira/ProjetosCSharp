﻿using GenAI.Crosscutting.Entities.Dto.Shared;
using System;

namespace GenAI.Crosscutting.Entities.Dto.Registrations;

public class FilterRegistrationDto : FilterPagedDto
{
	public string ValiaRegistration { get; set; }
	public string OfficialRegistration { get; set; }
	public bool? IsActive { get; set; }
	public DateTime CreationTime { get; set; }
}
