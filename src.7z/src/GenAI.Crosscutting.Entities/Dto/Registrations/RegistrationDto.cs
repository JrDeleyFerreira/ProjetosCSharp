﻿using Abp.Application.Services.Dto;
using Abp.AutoMapper;
using System;

namespace GenAI.Crosscutting.Entities.Dto.Registrations;

[AutoMapFrom(typeof(Domain.Entities.Registrations.Registration))]
public class RegistrationDto : EntityDto<Guid>
{
    public string ValiaRegistration { get; set; }
    public string OfficialRegistration { get; set; }
    public bool IsActive { get; set; }
    public DateTime CreationTime { get; set; }
}
