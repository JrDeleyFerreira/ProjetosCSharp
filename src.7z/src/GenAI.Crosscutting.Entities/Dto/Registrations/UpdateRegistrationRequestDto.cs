﻿using System;

namespace GenAI.Crosscutting.Entities.Dto.Registrations;

public class UpdateRegistrationRequestDto
{
    public Guid Id { get; set; }
	public string ValiaRegistration { get; set; }
	public string OfficialRegistration { get; set; }
	public bool IsActive { get; set; }
}
