﻿namespace GenAI.Crosscutting.Entities.Dto.Registrations;

public class CreateRegistrationDto
{
	public string ValiaRegistration { get; set; }
	public string OfficialRegistration { get; set; }
}
