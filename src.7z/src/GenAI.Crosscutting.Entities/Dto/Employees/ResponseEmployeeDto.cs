﻿using System;

namespace GenAI.Crosscutting.Entities.Dto.Employees;

public sealed class ResponseEmployeeDto
{
	public Guid Id { get; set; }
}
