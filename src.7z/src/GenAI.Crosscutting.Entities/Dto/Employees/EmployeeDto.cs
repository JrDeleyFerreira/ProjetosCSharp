﻿using Abp.Application.Services.Dto;
using Abp.AutoMapper;
using GenAI.Domain.Entities.Employees;
using System;

namespace GenAI.Crosscutting.Entities.Dto.Employees;

[AutoMapFrom(typeof(Employee))]
public class EmployeeDto : EntityDto<Guid>
{
    public long EmplyeeCode { get; set; }
    public string Registration { get; set; }
	public string Name { get; set; }
	public DateTime AdmissionDate { get; set; }
	public string EmploymentContract { get; set; }
	public string Email { get; set; }
}
