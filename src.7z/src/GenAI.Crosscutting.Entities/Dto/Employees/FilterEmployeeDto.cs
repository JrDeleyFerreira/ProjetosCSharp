﻿using GenAI.Crosscutting.Entities.Dto.Shared;

namespace GenAI.Crosscutting.Entities.Dto.Employees;

public class FilterEmployeeDto : FilterPagedDto
{
	public long EmployeeCode { get; set; }
    public string Name { get; set; }
	public bool? IsActive { get; set; }
    public string Email { get; set; }
}
