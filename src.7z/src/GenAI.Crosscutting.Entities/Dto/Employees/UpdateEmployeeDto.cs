﻿using System;

namespace GenAI.Crosscutting.Entities.Dto.Employees;

public sealed class UpdateEmployeeDto
{
	public long EmployeeCode { get; set; }
	public string Registration { get; set; }
	public string Name { get; set; }
	public DateTime AdmissionDate { get; set; }
	public string EmploymentContract { get; set; }
	public string Email { get; set; }
	public bool IsActive { get; set; }
}
