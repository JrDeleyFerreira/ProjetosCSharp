﻿using Abp.Application.Services.Dto;
using Abp.AutoMapper;
using GenAI.Domain.Entities;
using GenAI.Domain.Entities.Enums;

namespace GenAI.Crosscutting.Entities.Dto.Users
{
    [AutoMapTo(typeof(User))]
    public class UpdateUserDto : EntityDto<long>
    {
        public long Pid { get; set; }
        public int LevelId { get; set; }
        public string UserName { get; set; }
        public string Name { get; set; }
        public string EmailAddress { get; set; }
        public bool IsActive { get; set; }
        public string Surname => Name.Split(' ')[Name.Split(' ').Length - 1];
        public int RegionId { get; set; }
        public int CompanyId { get; set; }
        public string[] RoleNames { get; set; }
        public decimal ActivityRate { get; set; }
        public decimal IndLt { get; set; }
        public decimal IndSt { get; set; }
        public decimal DirLt { get; set; }
        public decimal DirSt { get; set; }
        public GenderEnum Gender { get; set; }

        public void Normalize()
        {
            if (RoleNames == null)
            {
                RoleNames = new string[0];
            }
        }
    }
}
