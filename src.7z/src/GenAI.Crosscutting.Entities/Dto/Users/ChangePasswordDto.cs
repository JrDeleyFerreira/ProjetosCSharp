﻿
namespace GenAI.Crosscutting.Entities.Dto.Users
{
    public class ChangePasswordDto
    {
        public string CurrentPassword { get; set; }

        public string NewPassword { get; set; }
        public string ConfimPassword { get; set; }
    }
}


