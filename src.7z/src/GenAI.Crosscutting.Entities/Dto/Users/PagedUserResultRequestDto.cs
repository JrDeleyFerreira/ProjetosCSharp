﻿using Abp.Application.Services.Dto;

namespace GenAI.Crosscutting.Entities.Dto.Users
{
    //custom PagedResultRequestDto
    public class PagedUserResultRequestDto : PagedResultRequestDto
    {
        public string Keyword { get; set; }
        public bool? IsActive { get; set; }
    }
}


