﻿using Abp.Application.Services.Dto;
using Abp.AutoMapper;
using GenAI.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;

namespace GenAI.Crosscutting.Entities.Dto.Users
{
    [AutoMapFrom(typeof(User))]
    public class UserDto : EntityDto<long>
    {
        public string UserName { get; set; }
        public string Name { get; set; }
        public string Surname { get; set; }
        public string EmailAddress { get; set; }
        public bool IsActive { get; set; }
        public string FullName { get; set; }
        public DateTime? LastLoginTime { get; set; }
        public DateTime CreationTime { get; set; }
        public string[] RoleNames { get; set; }
        public IList<string> RolesNormalizedName => RoleNames?.Select(n => n.ToUpper()).ToList();   
    }
}


