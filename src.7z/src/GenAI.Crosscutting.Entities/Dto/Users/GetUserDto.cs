﻿using Abp.Application.Services.Dto;

namespace GenAI.Crosscutting.Entities.Dto.Users;

public class GetUserDto : EntityDto<long>
{

}