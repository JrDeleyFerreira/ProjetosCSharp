﻿
using Abp.AutoMapper;
using GenAI.Domain.Entities;

namespace GenAI.Crosscutting.Entities.Dto.Users
{
    [AutoMapTo(typeof(User))]
    public class CreateUserDto
    {
        public string UserName { get; set; }
        public string Name { get; set; }
        public string EmailAddress { get; set; }
        public string Surname => Name.Split(' ')[Name.Split(' ').Length - 1];
        public string[] RoleNames { get; set; }
        public bool IsActive { get; set; }

        public void Normalize()
        {
            if (RoleNames == null)
            {
                RoleNames = new string[0];
            }
        }
    }
}


