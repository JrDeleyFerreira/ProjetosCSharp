﻿using System.ComponentModel.DataAnnotations;

namespace GenAI.Crosscutting.Entities.Dto.Users
{
    public class ChangeUserLanguageDto
    {
        [Required]
        public string LanguageName { get; set; }
    }
}

