﻿using Abp.Application.Services.Dto;
using Abp.AutoMapper;
using GenAI.Domain.Entities;

namespace GenAI.Crosscutting.Entities.Dto.Users
{
    
    public class UpdateUserStatusDto : EntityDto<long>
    {
        public bool IsActive { get; set; }
    }
}