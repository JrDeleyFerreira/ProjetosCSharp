﻿using GenAI.Crosscutting.Entities.Dto.Shared;

namespace GenAI.Crosscutting.Entities.Dto.Users;

public class FilterUserDto : FilterPagedDto
{
    public string Name { get; set; }
    public string UserName { get; set; }
    public string Email { get; set; }
}