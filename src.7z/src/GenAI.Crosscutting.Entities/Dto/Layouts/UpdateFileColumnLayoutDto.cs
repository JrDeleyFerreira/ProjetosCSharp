﻿using System;
using System.Collections.Generic;

namespace GenAI.Crosscutting.Entities.Dto.Layouts;

public sealed class UpdateFileColumnLayoutDto
{
    public Guid Id { get; set; }
    public string FileColumnName { get; set; }
    public int FileColumnPosition { get; set; }
    public bool IsActive { get; set; }
    public List<UpdateCorrespondingInformationDto>? UpdateCorrespondingInformation { get; set; }
}
