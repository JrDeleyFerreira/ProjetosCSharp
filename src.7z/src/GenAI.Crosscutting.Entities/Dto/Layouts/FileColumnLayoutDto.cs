﻿using Abp.Application.Services.Dto;
using Abp.AutoMapper;
using GenAI.Domain.Entities.Layouts;
using System;

namespace GenAI.Crosscutting.Entities.Dto.Layouts;

[AutoMapFrom(typeof(FileColumnLayout))]
public sealed class FileColumnLayoutDto : EntityDto<Guid>
{
    public string EntityDescription { get; set; }
    public string SystemDescription { get; set; } = string.Empty;
    public int ColumnKey { get; set; }
    public string ColumnName { get; set; }
    public string ColumnDescription { get; set; }
    public string FileColumnName { get; set; }
    public int FileColumnPosition { get; set; }
}
