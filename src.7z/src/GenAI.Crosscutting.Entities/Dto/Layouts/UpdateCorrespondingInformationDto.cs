﻿using System;

namespace GenAI.Crosscutting.Entities.Dto.Layouts;

public class UpdateCorrespondingInformationDto
{
    public Guid Id { get; set; }
    public string Description { get; set; }
    public bool IsActive { get; set; }
}
