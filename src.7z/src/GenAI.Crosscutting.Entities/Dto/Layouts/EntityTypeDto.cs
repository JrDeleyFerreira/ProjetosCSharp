﻿using Abp.Application.Services.Dto;
using Abp.AutoMapper;
using GenAI.Domain.Entities.Layouts;
using System;

namespace GenAI.Crosscutting.Entities.Dto.Layouts;

[AutoMapFrom(typeof(EntityType))]
public sealed class EntityTypeDto : EntityDto<Guid>
{
    public int Key { get; set; }
    public string Name { get; set; }
    public string Description { get; set; }
}
