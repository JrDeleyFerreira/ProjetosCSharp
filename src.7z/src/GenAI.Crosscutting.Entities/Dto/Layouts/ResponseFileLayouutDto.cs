﻿using System;

namespace GenAI.Crosscutting.Entities.Dto.Layouts;

public class ResponseFileLayouutDto
{
    public Guid Id { get; set; }
}
