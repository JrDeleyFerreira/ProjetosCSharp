﻿namespace GenAI.Application.Dto.Shared
{
    public class LanguageParameterDto
    {
        public string Language { get; set; }
    }
}


