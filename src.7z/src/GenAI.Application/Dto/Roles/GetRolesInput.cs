﻿namespace GenAI.Application.Dto.Roles
{
    public class GetRolesInput
    {
        public string Permission { get; set; }
    }
}


