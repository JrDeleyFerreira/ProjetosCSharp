﻿using Abp.Application.Services.Dto;

namespace GenAI.Application.Dto.Roles
{
    public class PagedRoleResultRequestDto : PagedResultRequestDto
    {
        public string Keyword { get; set; }
    }
}



