﻿using Abp.Application.Services.Dto;
using Abp.AutoMapper;
using GenAI.Domain.Entities;

namespace GenAI.Application.Dto.Sessions
{
    [AutoMapFrom(typeof(Tenant))]
    public class TenantLoginInfoDto : EntityDto
    {
        public string TenancyName { get; set; }

        public string Name { get; set; }
    }
}


