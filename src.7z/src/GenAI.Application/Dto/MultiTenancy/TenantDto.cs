﻿using Abp.Application.Services.Dto;
using Abp.AutoMapper;
using Abp.MultiTenancy;
using GenAI.Domain.Entities;
using System.ComponentModel.DataAnnotations;

namespace GenAI.Application.Dto.MultiTenancy
{
    [AutoMapFrom(typeof(Domain.Entities.Tenant))]
    public class TenantDto : EntityDto
    {
        [Required]
        [StringLength(AbpTenantBase.MaxTenancyNameLength)]
        [RegularExpression(AbpTenantBase.TenancyNameRegex)]
        public string TenancyName { get; set; }

        [Required]
        [StringLength(AbpTenantBase.MaxNameLength)]
        public string Name { get; set; }

        public bool IsActive { get; set; }
    }
}


