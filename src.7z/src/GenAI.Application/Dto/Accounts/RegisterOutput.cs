﻿namespace GenAI.Application.Dto.Accounts
{
    public class RegisterOutput
    {
        public bool CanLogin { get; set; }
    }
}


