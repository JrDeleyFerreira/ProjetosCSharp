﻿namespace GenAI.Application.Dto.Accounts
{
    public enum TenantAvailabilityState
    {
        Available = 1,
        InActive,
        NotFound
    }
}


