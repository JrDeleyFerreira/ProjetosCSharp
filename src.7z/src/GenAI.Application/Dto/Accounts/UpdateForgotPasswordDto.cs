﻿using System;
using System.ComponentModel.DataAnnotations;

namespace GenAI.Application.Dto.Accounts
{
    public class UpdateForgotPasswordDto
    {
        [Required]
        public Guid Token { get; set; }
        [Required]
        public string NewPassword { get; set; }
        [Required]
        public string ConfirmPassword { get; set; }
    }
}
