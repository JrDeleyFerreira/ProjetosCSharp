﻿using Abp.Authorization;
using GenAI.Core.Contracts.Services.Layouts;
using GenAI.Crosscutting.Entities.Dto.Layouts;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace GenAI.Application.Services.Layouts;

public class FileLayoutAppService : IFileLayoutAppService
{
	private readonly IFileColumnLayoutDomainService _fileColumnLayoutDomainService;
	private readonly IEntityTypeDomainService _entityTypeDomainService;

	public FileLayoutAppService(IFileColumnLayoutDomainService fileColumnLayoutDomainService, IEntityTypeDomainService entityTypeDomainService)
	{
		_fileColumnLayoutDomainService = fileColumnLayoutDomainService;
		_entityTypeDomainService = entityTypeDomainService;
	}

	[HttpGet]
	[AbpAuthorize()]
	public async Task<List<EntityTypeDto>> GetAllEntityLayoutsAsync() 
		=> await _entityTypeDomainService.GetAllEntityLayoutsAsync();

	[HttpGet]
	[AbpAuthorize()]
	public async Task<EntityTypeDto> GetEntityTypeById(Guid id) 
		=> await _entityTypeDomainService.GetEntityTypeById(id);

	[HttpGet]
	[AbpAuthorize()]
	public List<FileColumnLayoutDto> GetAllFileColumnLayoutsAsync() 
		=> _fileColumnLayoutDomainService.GetAllFileColumnLayoutsAsync();

	[HttpGet]
	[AbpAuthorize()]
	public FileColumnLayoutDto GetFileColumnLayoutByIdAsync(Guid id) 
		=> _fileColumnLayoutDomainService.GetFileColumnLayoutByIdAsync(id);

	[HttpGet]
	[AbpAuthorize()]
	public List<FileColumnLayoutDto> GetFileColumnLayoutsOfEntityAsync(Guid fileLayoutId) 
		=> _fileColumnLayoutDomainService.GetFileColumnLayoutsOfEntityAsync(fileLayoutId);

	[HttpDelete]
	[AbpAuthorize()]
	public async Task DeleteFileColumnLayoutAsync(Guid entityTypeId) 
		=> await _entityTypeDomainService.DeleteFileColumnLayoutAsync(entityTypeId);

	[HttpDelete]
	[AbpAuthorize()]
	public async Task DeleteCorrespondingInformationAsync(Guid correspondingInformationId)
		=> await _fileColumnLayoutDomainService.DeleteCorrespondingInformationAsync(correspondingInformationId);

	[HttpPut]
	[AbpAuthorize()]
	public async Task UpdateCorrespondingInformationAsync(UpdateCorrespondingInformationDto updateCorrespondingInformation) 
		=> await _fileColumnLayoutDomainService.UpdateCorrespondingInformationAsync(updateCorrespondingInformation);

	[HttpPut]
	[AbpAuthorize()]
	public async Task UpdateFileColumnLayoutAsync(UpdateFileColumnLayoutDto updateFileColumnLayout) 
		=> await _fileColumnLayoutDomainService.UpdateFileColumnLayoutAsync(updateFileColumnLayout);

	[HttpPut]
	[AbpAuthorize()]
	public async Task UpdateEntityTypeAsync(UpdateEntityTypeDto updateEntityType) 
		=> await _entityTypeDomainService.UpdateEntityTypeAsync(updateEntityType);
}
