﻿using Abp.Application.Services;
using GenAI.Crosscutting.Entities.Dto.Layouts;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace GenAI.Application.Services.Layouts;

public interface IFileLayoutAppService : IApplicationService
{
	Task<List<EntityTypeDto>> GetAllEntityLayoutsAsync();

	Task<EntityTypeDto> GetEntityTypeById(Guid id);

	List<FileColumnLayoutDto> GetAllFileColumnLayoutsAsync();

	List<FileColumnLayoutDto> GetFileColumnLayoutsOfEntityAsync(Guid fileLayoutId);

	FileColumnLayoutDto GetFileColumnLayoutByIdAsync(Guid id);

	Task DeleteCorrespondingInformationAsync(Guid correspondingInformationId);

	Task DeleteFileColumnLayoutAsync(Guid entityTypeId);

	Task UpdateCorrespondingInformationAsync(UpdateCorrespondingInformationDto updateCorrespondingInformation);

	Task UpdateFileColumnLayoutAsync(UpdateFileColumnLayoutDto updateFileColumnLayout);

	Task UpdateEntityTypeAsync(UpdateEntityTypeDto updateEntityType);
}
