﻿using GenAI.Core.Contracts.Services.Language;
using GenAI.Crosscutting.Entities.Dto.Language;
using System.Collections.Generic;

namespace GenAI.Application.Services.Languages
{
    public class ApplicationLanguageAppService : GenAIAppServiceBase, IApplicationLanguageAppService
    {
        private readonly IAppLanguageDomainService _ApplicationLanguageDomainService;

        public ApplicationLanguageAppService(IAppLanguageDomainService applicationLanguageDomainService)
        {
            _ApplicationLanguageDomainService = applicationLanguageDomainService;
        }

        public IEnumerable<AppLanguageDto> GetApplicationLanguages()
        {
            var appLanguages =  _ApplicationLanguageDomainService.GetApplicationLanguages();
            return ObjectMapper.Map<IEnumerable<AppLanguageDto>>(appLanguages);
        }
    }
}
