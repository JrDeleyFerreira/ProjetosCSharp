﻿using Abp.Localization;
using GenAI.Crosscutting.Entities.Dto.Language;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenAI.Application.Services.Languages
{
    public interface IApplicationLanguageAppService
    {
        IEnumerable<AppLanguageDto> GetApplicationLanguages();
    }
}
