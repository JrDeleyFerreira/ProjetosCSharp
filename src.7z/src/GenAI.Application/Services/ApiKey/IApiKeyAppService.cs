﻿using System;
using System.Threading.Tasks;
using Abp.Application.Services.Dto;
using GenAI.Application.Services.Shared;
using GenAI.Crosscutting.Entities.Dto.ApiKeys;

namespace GenAI.Application.Services.Indexes;

public interface IApiKeyAppService : IGenAIAppServiceBase<UserApiKeyDto, Guid>
{
    PagedResultDto<UserApiKeyDto> GetAllApiKeyPaged(FilterApiKeyDto filter);
    Task<bool> DeleteApiKeyAsync(Guid apiKeyId);
    Guid? GetApiKeyByUser(); 
}