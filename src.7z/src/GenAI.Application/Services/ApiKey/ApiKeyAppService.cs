﻿using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Abp.Application.Services.Dto;
using System;
using GenAI.Application.Services.Shared;
using Abp.Domain.Repositories;
using GenAI.Domain.Entities.ApiKey;
using GenAI.Core.Contracts.Services.ApiKey;
using GenAI.Crosscutting.Entities.Dto.ApiKeys;

namespace GenAI.Application.Services.Indexes;

//[AbpAuthorize(PermissionNames.Analysts)]
public class ApiKeyAppService : GenAIAppServiceBase<UserApiKey, Guid, UserApiKeyDto>, IApiKeyAppService
{
    private readonly IUserApiKeyDomainService _userApiKeyDomainService;

    public ApiKeyAppService(IRepository<UserApiKey, Guid> repository, IUserApiKeyDomainService userApiKeyDomainService) : base(repository, userApiKeyDomainService)
    {
        _userApiKeyDomainService = userApiKeyDomainService;
    }

    public PagedResultDto<UserApiKeyDto> GetAllApiKeyPaged(FilterApiKeyDto filter)
    {
        return _userApiKeyDomainService.GetAllApiKeyPaged(filter);
    }

    [HttpDelete]
    public async Task<bool> DeleteApiKeyAsync(Guid apiKeyId)
    {
        var isdeleted = await _userApiKeyDomainService.DeleteApiKeyAsync(apiKeyId);

        return isdeleted;
    }

    public Guid? GetApiKeyByUser()
    {
        var apikey = _userApiKeyDomainService.GetApiKeyByUser();
        return apikey;
    }
}