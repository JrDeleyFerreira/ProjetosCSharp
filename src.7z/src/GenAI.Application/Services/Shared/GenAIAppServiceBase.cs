﻿using Abp.Application.Services;
using Abp.Application.Services.Dto;
using Abp.Domain.Entities;
using Abp.Domain.Repositories;
using Abp.IdentityFramework;
using Abp.Runtime.Session;
using GenAI.Core.Contracts.Services.Shared;
using GenAI.Core.Impl.Services.MultiTenancy;
using GenAI.Core.Impl.Services.Users;
using GenAI.Crosscutting.Entities.Dto.Shared;
using GenAI.Crosscutting.Infra.Extensions.Abp;
using GenAI.Crosscutting.Infra.Settings;
using GenAI.Domain.Entities;
using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
namespace GenAI.Application.Services.Shared
{
    public abstract class GenAIAppServiceBase<TEntity, TEntityDto> :
        GenAIAppServiceBase<TEntity, int, TEntityDto>,
        IGenAIAppServiceBase<TEntityDto, int>
        where TEntity : class, IEntity<int>
        where TEntityDto : IEntityDto<int>
    {
        protected GenAIAppServiceBase(IRepository<TEntity, int> repository,
            IGenAIDomainServiceBase<TEntity, int, TEntityDto> domainService) : base(repository, domainService)
        {
        }
    }
    public abstract class GenAIAppServiceBase<TEntity, TPrimaryKey, TEntityDto> :
        GenAIAppServiceBase<TEntity, TPrimaryKey, TEntityDto, PagedAndSortedResultRequestDto>,
        IGenAIAppServiceBase<TEntityDto, TPrimaryKey, PagedAndSortedResultRequestDto>
        where TEntity : class, IEntity<TPrimaryKey>
        where TEntityDto : IEntityDto<TPrimaryKey>
    {
        protected GenAIAppServiceBase(IRepository<TEntity, TPrimaryKey> repository,
            IGenAIDomainServiceBase<TEntity, TPrimaryKey, TEntityDto> domainService) : base(repository, domainService)
        {
        }
    }
    public abstract class GenAIAppServiceBase<TEntity, TPrimaryKey, TEntityDto, TGetAllInput> :
        GenAIAppServiceBase<TEntity, TPrimaryKey, TEntityDto, TGetAllInput, TEntityDto>
        where TEntity : class, IEntity<TPrimaryKey>
        where TEntityDto : IEntityDto<TPrimaryKey>
        where TGetAllInput : IPagedAndSortedResultRequest
    {
        protected GenAIAppServiceBase(IRepository<TEntity, TPrimaryKey> repository,
            IGenAIDomainServiceBase<TEntity, TPrimaryKey, TEntityDto> domainService) : base(repository, domainService)
        {
        }
    }
    public abstract class GenAIAppServiceBase<TEntity, TPrimaryKey, TEntityDto, TGetAllInput, TCreateInput> :
        GenAIAppServiceBase<TEntity, TPrimaryKey, TEntityDto, TGetAllInput, TCreateInput, TEntityDto>
        where TEntity : class, IEntity<TPrimaryKey>
        where TEntityDto : IEntityDto<TPrimaryKey>
    {
        protected GenAIAppServiceBase(IRepository<TEntity, TPrimaryKey> repository,
            IGenAIDomainServiceBase<TEntity, TPrimaryKey, TEntityDto, TCreateInput> domainService) : base(repository, domainService)
        {
        }
    }
    public abstract class GenAIAppServiceBase<TEntity, TPrimaryKey, TEntityDto, TGetAllInput, TCreateInput, TUpdateInput> :
        GenAIAppServiceBase<TEntity, TPrimaryKey, TEntityDto, TGetAllInput, TCreateInput, TUpdateInput, EntityDto<TPrimaryKey>, EntityDto<TPrimaryKey>>
        where TEntity : class, IEntity<TPrimaryKey>
        where TEntityDto : IEntityDto<TPrimaryKey>
        where TUpdateInput : IEntityDto<TPrimaryKey>
    {
        protected GenAIAppServiceBase(IRepository<TEntity, TPrimaryKey> repository,
            IGenAIDomainServiceBase<TEntity, TPrimaryKey, TEntityDto, TCreateInput, TUpdateInput> domainService) : base(repository, domainService)
        {
        }
    }
    public abstract class GenAIAppServiceBase<TEntity, TPrimaryKey, TEntityDto, TGetAllInput, TCreateInput, TUpdateInput, TGetInput, TDeleteInput> :
    GenAIAppServiceBase<TEntity, TPrimaryKey, TEntityDto, TGetAllInput, TCreateInput, TUpdateInput, TGetInput, TDeleteInput, FilterPagedDto>
        where TEntity : class, IEntity<TPrimaryKey>
        where TEntityDto : IEntityDto<TPrimaryKey>
        where TUpdateInput : IEntityDto<TPrimaryKey>
        where TGetInput : IEntityDto<TPrimaryKey>
        where TDeleteInput : IEntityDto<TPrimaryKey>
    {
        protected GenAIAppServiceBase(IRepository<TEntity, TPrimaryKey> repository,
            IGenAIDomainServiceBase<TEntity, TPrimaryKey, TEntityDto, TCreateInput, TUpdateInput, FilterPagedDto> domainService) : base(repository, domainService)
        {

        }
    }
    public abstract class GenAIAppServiceBase<TEntity, TPrimaryKey, TEntityDto, TGetAllInput, TCreateInput, TUpdateInput, TGetInput, TDeleteInput, TFilterGetPagedInput> :
    GenAIAppServiceBase<TEntity, TPrimaryKey, TEntityDto, TGetAllInput, TCreateInput, TUpdateInput, TGetInput, TDeleteInput, TFilterGetPagedInput, EntityDto<TPrimaryKey>>
        where TEntity : class, IEntity<TPrimaryKey>
        where TEntityDto : IEntityDto<TPrimaryKey>
        where TUpdateInput : IEntityDto<TPrimaryKey>
        where TGetInput : IEntityDto<TPrimaryKey>
        where TDeleteInput : IEntityDto<TPrimaryKey>
        where TFilterGetPagedInput : FilterPagedDto
    {
        protected GenAIAppServiceBase(IRepository<TEntity, TPrimaryKey> repository,
            IGenAIDomainServiceBase<TEntity, TPrimaryKey, TEntityDto, TCreateInput, TUpdateInput, TFilterGetPagedInput> domainService) : base(repository, domainService)
        {

        }

    }
    public abstract class GenAIAppServiceBase<TEntity, TPrimaryKey, TEntityDto, TGetAllInput, TCreateInput, TUpdateInput, TGetInput, TDeleteInput, TFilterGetPagedInput, TListDto> :
        ApplicationService,
        IGenAIAppServiceBase<TEntityDto, TPrimaryKey, TGetAllInput, TCreateInput, TUpdateInput, TGetInput, TDeleteInput, TFilterGetPagedInput, TListDto>
        where TEntity : class, IEntity<TPrimaryKey>
        where TEntityDto : IEntityDto<TPrimaryKey>
        where TUpdateInput : IEntityDto<TPrimaryKey>
        where TGetInput : IEntityDto<TPrimaryKey>
        where TDeleteInput : IEntityDto<TPrimaryKey>
        where TFilterGetPagedInput : FilterPagedDto
        where TListDto : EntityDto<TPrimaryKey>, new()
    {
        protected Guid TenantId => AbpSession.GetTenant().HasValue ? AbpSession.GetTenant().Value : Guid.Empty;
        protected long UserId => AbpSession.GetUserId();

        public TenantManager TenantManager { get; set; }
        public UserManager UserManager { get; set; }
        protected readonly IGenAIDomainServiceBase<TEntity, TPrimaryKey, TEntityDto, TCreateInput, TUpdateInput, TFilterGetPagedInput, TListDto> DomainService;

        protected GenAIAppServiceBase(IRepository<TEntity, TPrimaryKey> repository,
            IGenAIDomainServiceBase<TEntity, TPrimaryKey, TEntityDto, TCreateInput, TUpdateInput, TFilterGetPagedInput, TListDto> domainService)
        {
            DomainService = domainService;
            LocalizationSourceName = GenAIConsts.LocalizationMessagesSourceName;
        }

        protected virtual Task<User> GetCurrentUserAsync()
        {
            var user = UserManager.FindByIdAsync(AbpSession.GetUserId().ToString());
            if (user == null)
            {
                throw new Exception(L("ThereIsNoCurrentUser"));
            }
            return user;
        }

        protected virtual Task<Tenant> GetCurrentTenantAsync()
        {
            return TenantManager.GetByIdAsync(AbpSession.GetTenantId());
        }

        protected virtual void CheckErrors(IdentityResult identityResult)
        {
            identityResult.CheckErrors(LocalizationManager);
        }

        public virtual async Task<IEnumerable<TEntityDto>> CreateInMassAsync(IEnumerable<TCreateInput> entitiesDto)
        {
            var entities = await DomainService.CreateInMassAsync(entitiesDto);
            var result = Map<IEnumerable<TEntityDto>>(entities);
            return result;
        }

        public virtual async Task<IEnumerable<TEntityDto>> UpdateInMassAsync(IEnumerable<TUpdateInput> entities)
        {
            IEnumerable<TEntity> e = Map<IEnumerable<TEntity>>(entities);
            e = await DomainService.UpdateAsync(e);
            var result = Map<IEnumerable<TEntityDto>>(e);
            return result;
        }

        public virtual async Task<IEnumerable<TEntityDto>> GetAllListAsync()
        {
            IEnumerable<TEntity> entities = await DomainService.GetAllAsync();
            var result = Map<IEnumerable<TEntityDto>>(entities);
            return result;
        }

        public virtual PagedResultDto<TEntityDto> GetAllPaged(TFilterGetPagedInput filter)
        {
            var paged = DomainService.GetAllPaged(filter);
            return paged;
        }
        public virtual TEntityDto GetSync(TPrimaryKey id)
        {
            var entity = DomainService.GetSync(id);
            return MapToEntityDto(entity);
        }

        protected virtual async Task<IEnumerable<TEntityDto>> GetAllListFromDataBaseAsync(Func<TEntity, object> sortingExpression, bool ascending = true)
        {
            var entities = await DomainService.GetAllAsync(sortingExpression);
            return Map<IEnumerable<TEntityDto>>(entities);
        }

        public virtual async Task DeletesAsync(List<TPrimaryKey> ids)
        {
            await DomainService.DeletesAsync(ids);
        }

        public virtual IEnumerable<TEntityDto> GetAllFilter(TFilterGetPagedInput filter)
        {
            IQueryable<TEntity> entities = DomainService.CreateQueryFilter(filter);
            IEnumerable<TEntityDto> entityDtos = Map<IEnumerable<TEntityDto>>(entities);
            return entityDtos;
        }
        public virtual IEnumerable<TListDto> GetFiltered(TFilterGetPagedInput filter)
        {
            IQueryable<TListDto> entities = DomainService.CreateFilter(filter);
            return entities.ToList();
        }

        public virtual PagedResultDto<TListDto> GetPaged(TFilterGetPagedInput filter)
        {
            PagedResultDto<TListDto> result = DomainService.GetPaged(filter);
            return result;
        }

        public virtual async Task<TEntityDto> CreateAsync(TCreateInput input)
        {
            TEntity entity = await DomainService.CreateAsync(input);
            return MapToEntityDto(entity);
        }

        public virtual async Task DeleteAsync(TDeleteInput input)
        {
            await DomainService.DeleteAsync(input.Id);
        }

        public virtual async Task<PagedResultDto<TEntityDto>> GetAllAsync(TGetAllInput input)
        {
            IEnumerable<TEntity> entities = await DomainService.GetAllAsync();
            IEnumerable<TEntityDto> entityDtos = Map<IEnumerable<TEntityDto>>(entities);
            return new PagedResultDto<TEntityDto> { Items = (IReadOnlyList<TEntityDto>)entityDtos, TotalCount = entityDtos.Count() };
        }

        public virtual async Task<TEntityDto> GetAsync(TGetInput input)
        {
            TEntity entity = await DomainService.GetAsync(input.Id);
            return MapToEntityDto(entity);
        }

        public virtual async Task<TEntityDto> UpdateAsync(TUpdateInput input)
        {
            TEntity entity = await DomainService.UpdateAsync(input);
            return MapToEntityDto(entity);
        }
        protected TDestination Map<TDestination>(object obj) where TDestination : class
        {
            return ObjectMapper.Map<TDestination>(obj);
        }
        protected virtual TEntityDto MapToEntityDto(TEntity entity)
        {
            return ObjectMapper.Map<TEntityDto>(entity);
        }
    }
}
