﻿using Abp.Application.Services;
using Abp.Application.Services.Dto;
using GenAI.Crosscutting.Entities.Dto.Shared;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace GenAI.Application.Services.Shared
{
    public interface IGenAIAppServiceBase<TEntityDto> :
        IGenAIAppServiceBase<TEntityDto, int>
        where TEntityDto : IEntityDto<int>
    {
    }
    public interface IGenAIAppServiceBase<TEntityDto, TPrimaryKey> :
        IGenAIAppServiceBase<TEntityDto, TPrimaryKey, PagedAndSortedResultRequestDto>
       where TEntityDto : IEntityDto<TPrimaryKey>
    {
    }
    public interface IGenAIAppServiceBase<TEntityDto, TPrimaryKey, in TGetAllInput> :
        IGenAIAppServiceBase<TEntityDto, TPrimaryKey, TGetAllInput, TEntityDto>
        where TEntityDto : IEntityDto<TPrimaryKey>
        where TGetAllInput : IPagedAndSortedResultRequest
    {
    }
    public interface IGenAIAppServiceBase<TEntityDto, TPrimaryKey, in TGetAllInput, in TCreateInput> :
        IGenAIAppServiceBase<TEntityDto, TPrimaryKey, TGetAllInput, TCreateInput, TCreateInput>
        where TEntityDto : IEntityDto<TPrimaryKey>
        where TCreateInput : IEntityDto<TPrimaryKey>
    {
    }
    public interface IGenAIAppServiceBase<TEntityDto, TPrimaryKey, in TGetAllInput, in TCreateInput, in TUpdateInput> :
       IGenAIAppServiceBase<TEntityDto, TPrimaryKey, TGetAllInput, TCreateInput, TUpdateInput, EntityDto<TPrimaryKey>, EntityDto<TPrimaryKey>>
       where TEntityDto : IEntityDto<TPrimaryKey>
       where TUpdateInput : IEntityDto<TPrimaryKey>
    {
    }
    public interface IGenAIAppServiceBase<TEntityDto, TPrimaryKey, in TGetAllInput, in TCreateInput, in TUpdateInput, in TGetInput, in TDeleteInput> :
        IGenAIAppServiceBase<TEntityDto, TPrimaryKey, TGetAllInput, TCreateInput, TUpdateInput, TGetInput, TDeleteInput, FilterPagedDto>
        where TEntityDto : IEntityDto<TPrimaryKey>
        where TUpdateInput : IEntityDto<TPrimaryKey>
        where TGetInput : IEntityDto<TPrimaryKey>
        where TDeleteInput : IEntityDto<TPrimaryKey>
    {
    }
    public interface IGenAIAppServiceBase<TEntityDto, TPrimaryKey, in TGetAllInput, in TCreateInput, in TUpdateInput, in TGetInput, in TDeleteInput, in TFilterGetPagedInput> :
        IGenAIAppServiceBase<TEntityDto, TPrimaryKey, TGetAllInput, TCreateInput, TUpdateInput, TGetInput, TDeleteInput, TFilterGetPagedInput, EntityDto<TPrimaryKey>>
        where TEntityDto : IEntityDto<TPrimaryKey>
        where TUpdateInput : IEntityDto<TPrimaryKey>
        where TGetInput : IEntityDto<TPrimaryKey>
        where TDeleteInput : IEntityDto<TPrimaryKey>
        where TFilterGetPagedInput : FilterPagedDto
    {
    }

    public interface IGenAIAppServiceBase<TEntityDto, TPrimaryKey, in TGetAllInput, in TCreateInput, in TUpdateInput, in TGetInput, in TDeleteInput, in TFilterGetPagedInput, TListDto> :
        IApplicationService
        where TEntityDto : IEntityDto<TPrimaryKey>
        where TUpdateInput : IEntityDto<TPrimaryKey>
        where TGetInput : IEntityDto<TPrimaryKey>
        where TDeleteInput : IEntityDto<TPrimaryKey>
        where TFilterGetPagedInput : FilterPagedDto
        where TListDto : EntityDto<TPrimaryKey>, new()
    {
        Task<TEntityDto> CreateAsync(TCreateInput entityDto);
        Task<IEnumerable<TEntityDto>> CreateInMassAsync(IEnumerable<TCreateInput> entitiesDto);
        Task<TEntityDto> UpdateAsync(TUpdateInput entityDto);
        Task<IEnumerable<TEntityDto>> UpdateInMassAsync(IEnumerable<TUpdateInput> entities);
        Task<IEnumerable<TEntityDto>> GetAllListAsync();
        PagedResultDto<TEntityDto> GetAllPaged(TFilterGetPagedInput filter);
        PagedResultDto<TListDto> GetPaged(TFilterGetPagedInput filter);
        IEnumerable<TEntityDto> GetAllFilter(TFilterGetPagedInput filter);
        IEnumerable<TListDto> GetFiltered(TFilterGetPagedInput filter);
        TEntityDto GetSync(TPrimaryKey id);
        Task DeletesAsync(List<TPrimaryKey> ids);
    }
}
