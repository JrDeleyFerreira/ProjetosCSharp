﻿using Abp.Application.Services;
using Abp.Application.Services.Dto;
using GenAI.Crosscutting.Entities.Dto.Collaborators;
using Microsoft.AspNetCore.Http;
using System;
using System.Threading.Tasks;

namespace GenAI.Application.Services.Collaborators;

public interface ICollaboratorAppService : IApplicationService
{
	Task<ResponseCollaboratorDto> CreateAsync(CreateCollaboratorDto collaborator);
	Task DeleteAsync(Guid id);
	Task<CollaboratorDto> GetByIdAsync(Guid id);
	Task UpdateAsync(UpdateCollaboratorDto collaborator);
	PagedResultDto<CollaboratorDto> GetAllPaged(FilterCollaboratorDto filter);
	Task ImportSpreadsheetAsync(IFormFile formImport);
}
