﻿using Abp.Application.Services.Dto;
using Abp.Authorization;
using GenAI.Core.Contracts.Services.Collaborators;
using GenAI.Crosscutting.Entities.Dto.Collaborators;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;

namespace GenAI.Application.Services.Collaborators;

public class CollaboratorAppService : GenAIAppServiceBase, ICollaboratorAppService
{
	private readonly ICollaboratorDomainService _collaboratorDomainService;

	public CollaboratorAppService(ICollaboratorDomainService collaboratorDomainService) => _collaboratorDomainService = collaboratorDomainService;

	[HttpPost]
	[AbpAuthorize()]
	public async Task<ResponseCollaboratorDto> CreateAsync(CreateCollaboratorDto collaborator)
	{
		var response = await _collaboratorDomainService.InsertAsync(collaborator);
		return response;
	}

	[HttpDelete]
	[AbpAuthorize()]
	public async Task DeleteAsync(Guid id) => 
		await _collaboratorDomainService.DeleteAsync(id);

	[HttpGet]
	[AbpAuthorize()]
	public PagedResultDto<CollaboratorDto> GetAllPaged(FilterCollaboratorDto filter) =>
		_collaboratorDomainService.GetAllPaged(filter);

	[HttpGet]
	[AbpAuthorize()]
	public async Task<CollaboratorDto> GetByIdAsync(Guid id) =>
		await _collaboratorDomainService.GetByIdAsync(id);

	[HttpPut]
	[AbpAuthorize()]
	public async Task UpdateAsync(UpdateCollaboratorDto collaborator) =>
		await _collaboratorDomainService.UpdateAsync(collaborator);

	[HttpPost]
	[AbpAuthorize()]
	public async Task ImportSpreadsheetAsync(IFormFile formImport) =>
		await _collaboratorDomainService.ImportSpreadsheetAsync(formImport);
}
