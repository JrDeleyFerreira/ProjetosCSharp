﻿using Abp.Authorization;
using Abp.Configuration;
using Abp.Runtime.Session;
using Abp.UI;
using Abp.Zero.Configuration;
using GenAI.Application.Dto.Accounts;
using GenAI.Core.Impl.Services.Authorization;
using GenAI.Core.Impl.Services.Users;
using GenAI.Crosscutting.Entities.Dto.Users;
using GenAI.Domain.Entities;
using GenAI.Domain.Entities.Tokens;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace GenAI.Application.Services.Accounts
{
    public class AccountAppService : GenAIAppServiceBase, IAccountAppService
    {
        // from: http://regexlib.com/REDetails.aspx?regexp_id=1923
        public const string PasswordRegex = "(?=^.{8,}$)(?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?!.*\\s)[0-9a-zA-Z!@#$%^&*()]*$";
        private readonly IAbpSession _AbpSession;
        private readonly UserManager _UserManager;
        private readonly LogInManager _LogInManager;
        private readonly IPasswordHasher<User> _PasswordHasher;

        private readonly UserRegistrationManager _UserRegistrationManager;

        public AccountAppService(
            UserRegistrationManager userRegistrationManager,
            IAbpSession abpSession,
            UserManager userManager,
            LogInManager logInManager,
            IPasswordHasher<User> passwordHasher)
        {
            _UserRegistrationManager = userRegistrationManager;
            _AbpSession = abpSession;
            _UserManager = userManager;
            _LogInManager = logInManager;
            _PasswordHasher = passwordHasher;
            LocalizationSourceName = "Messages";
        }

        public async Task<IsTenantAvailableOutput> IsTenantAvailable(IsTenantAvailableInput input)
        {
            Tenant tenant = await TenantManager.FindByTenancyNameAsync(input.TenancyName);
            if (tenant == null)
            {
                return new IsTenantAvailableOutput(TenantAvailabilityState.NotFound);
            }

            if (!tenant.IsActive)
            {
                return new IsTenantAvailableOutput(TenantAvailabilityState.InActive);
            }

            return new IsTenantAvailableOutput(TenantAvailabilityState.Available, tenant.Id);
        }

        public async Task<RegisterOutput> Register(RegisterInput input)
        {
            User user = await _UserRegistrationManager.RegisterAsync(
                input.Name,
                input.Surname,
                input.EmailAddress,
                input.UserName,
                input.Password,
                true // Assumed email address is always confirmed. Change this if you want to implement email confirmation.
            );

            bool isEmailConfirmationRequiredForLogin = await SettingManager.GetSettingValueAsync<bool>(AbpZeroSettingNames.UserManagement.IsEmailConfirmationRequiredForLogin);

            return new RegisterOutput
            {
                CanLogin = user.IsActive && (user.IsEmailConfirmed || !isEmailConfirmationRequiredForLogin)
            };
        }
        [AbpAuthorize(PermissionNames.Analysts)]
        [HttpPut]
        public async Task<bool> ChangePassword(ChangePasswordDto input)
        {
            if (_AbpSession.UserId == null)
            {
                throw new UserFriendlyException(L("PLEASE_LOGIN_BEFORE_CHANGE_PASS"));
            }
            long userId = _AbpSession.UserId.Value;
            User user = await _UserManager.GetUserByIdAsync(userId);
            var loginAsync = await _LogInManager.LoginAsync(user.UserName, input.CurrentPassword, shouldLockout: false);
            if (loginAsync.Result != AbpLoginResultType.Success)
            {
                throw new UserFriendlyException(L("EXISTING_PASSWORD_DID_NOT_MATCH"));
            }

            user.Password = _PasswordHasher.HashPassword(user, input.NewPassword);
            CurrentUnitOfWork.SaveChanges();
            return true;
        }
        [AbpAllowAnonymous]
        public async Task<UpdateForgotPasswordDto> UpdateForgotPassword(UpdateForgotPasswordDto updateForgotPasswordDto)
        {
            Token token = await _UserManager.GetToken(updateForgotPasswordDto.Token);
            if (token == null) throw new UserFriendlyException(L("INVALID_TOKEN"));
            User user = await _UserManager.GetUserByIdAsync(token.UserId);
            if (user == null) throw new UserFriendlyException(L("INVALID_USER"));

            var result = await _UserManager.ResetPasswordAsync(user, token.TokenId, updateForgotPasswordDto.NewPassword);

            if (!result.Succeeded) throw new UserFriendlyException(L("FAIL_UPDATE_PASSWORD"));
            return updateForgotPasswordDto;
        }
    }
}


