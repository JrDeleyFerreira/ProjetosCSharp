﻿using Abp.Application.Services;
using GenAI.Application.Dto.Accounts;
using GenAI.Crosscutting.Entities.Dto.Users;
using System.Threading.Tasks;

namespace GenAI.Application.Services.Accounts
{
    public interface IAccountAppService : IApplicationService
    {
        Task<IsTenantAvailableOutput> IsTenantAvailable(IsTenantAvailableInput input);

        Task<RegisterOutput> Register(RegisterInput input);
        Task<bool> ChangePassword(ChangePasswordDto input);
    }
}


