﻿using Abp.Application.Services;
using Abp.Application.Services.Dto;
using GenAI.Application.Dto.Roles;
using System.Threading.Tasks;

namespace GenAI.Application.Services.Roles
{
    public interface IRoleAppService : IAsyncCrudAppService<RoleDto, int, PagedRoleResultRequestDto, CreateRoleDto, RoleDto>
    {
        Task<ListResultDto<PermissionDto>> GetAllPermissions();

        Task<GetRoleForEditOutput> GetRoleForEdit(EntityDto input);

        Task<ListResultDto<RoleListDto>> GetRolesAsync(GetRolesInput input);
    }
}


