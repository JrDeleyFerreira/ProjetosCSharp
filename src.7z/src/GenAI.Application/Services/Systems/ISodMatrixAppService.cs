﻿using Abp.Application.Services;
using Abp.Application.Services.Dto;
using GenAI.Crosscutting.Entities.Dto.Systems;
using System.Threading.Tasks;
using System;

namespace GenAI.Application.Services.Systems
{
    public interface ISodMatrixAppService : IApplicationService
    {
        Task<SystemResponseDto> CreateAsync(CreateSodMatrixRequestDto sodMatrixDto);
        Task DeleteAsync(Guid id);
        PagedResultDto<SodMatrixDto> GetAllPaged(FilterSodMatrixDto filter);
        Task<SodMatrixDto> GetByIdAsync(Guid id);
        Task UpdateAsync(UpdateSodMatrixRequestDto sodMatrixDto);
    }
}
