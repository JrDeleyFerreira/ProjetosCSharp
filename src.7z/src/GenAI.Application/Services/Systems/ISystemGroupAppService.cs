﻿using Abp.Application.Services;
using Abp.Application.Services.Dto;
using GenAI.Crosscutting.Entities.Dto.Systems;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;

namespace GenAI.Application.Services.Systems
{
    public interface ISystemGroupAppService : IApplicationService
    {
        Task<SystemResponseDto> Create(CreateSystemGroupRequestDto systemDto);
        PagedResultDto<SystemGroupDto> GetAllPaged(FilterSystemGroupDto filter);
        Task DeleteAsync([FromQuery] Guid id);
        Task UpdateAsync(UpdateSystemGroupRequestDto systemDto);
        Task<SystemGroupDto> GetByIdAsync([FromQuery] Guid id);
    }
}
