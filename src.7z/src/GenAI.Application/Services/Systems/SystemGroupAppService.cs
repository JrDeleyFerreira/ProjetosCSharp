﻿using Abp.Application.Services.Dto;
using Abp.Authorization;
using GenAI.Core.Contracts.Services.Systems;
using GenAI.Core.Impl.Services.Systems;
using GenAI.Crosscutting.Entities.Dto.Systems;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;

namespace GenAI.Application.Services.Systems
{
    public class SystemGroupAppService : GenAIAppServiceBase, ISystemGroupAppService
    {
        private readonly ISystemGroupDomainService _systemGroupDomainService;

        public SystemGroupAppService(ISystemGroupDomainService systemGroupDomainService)
        {
            _systemGroupDomainService = systemGroupDomainService;
        }

        [HttpPost]
        [AbpAuthorize()]
        public async Task<SystemResponseDto> Create(CreateSystemGroupRequestDto systemDto)
        {
            var response = await _systemGroupDomainService.Create(systemDto);
            return response;
        }

        [HttpGet]
        [AbpAuthorize()]
        public PagedResultDto<SystemGroupDto> GetAllPaged(FilterSystemGroupDto filter)
        {
            var response = _systemGroupDomainService.GetAllPaged(filter);
            return response;
        }

        [HttpDelete]
        [AbpAuthorize()]
        public async Task DeleteAsync([FromQuery] Guid id)
        {
            await _systemGroupDomainService.DeleteAsync(id);
        }

        [HttpPut]
        [AbpAuthorize()]
        public async Task UpdateAsync(UpdateSystemGroupRequestDto systemDto)
        {
            await _systemGroupDomainService.UpdateAsync(systemDto);
        }

        [HttpGet]
        [AbpAuthorize()]
        public async Task<SystemGroupDto> GetByIdAsync([FromQuery] Guid id)
        {
            return await _systemGroupDomainService.GetByIdAsync(id);
        }
    }
}
