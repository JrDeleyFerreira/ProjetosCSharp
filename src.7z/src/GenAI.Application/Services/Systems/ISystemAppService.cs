﻿using Abp.Application.Services;
using Abp.Application.Services.Dto;
using GenAI.Crosscutting.Entities.Dto.Systems;
using System;
using System.Threading.Tasks;

namespace GenAI.Application.Services.Systems
{
    public interface ISystemAppService : IApplicationService
    {
        Task<SystemResponseDto> CreateAsync(CreateSystemRequestDto systemDto);
        Task DeleteAsync(Guid id);
        PagedResultDto<SystemDto> GetAllPaged(FilterSystemDto filter);
        Task<SystemDto> GetByIdAsync(Guid id);
        Task UpdateAsync(UpdateSystemRequestDto systemDto);
    }
}
