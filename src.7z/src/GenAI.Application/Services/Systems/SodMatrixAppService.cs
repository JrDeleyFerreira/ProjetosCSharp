﻿using Abp.Application.Services.Dto;
using Abp.Authorization;
using GenAI.Core.Contracts.Services.Systems;
using GenAI.Crosscutting.Entities.Dto.Systems;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using System;

namespace GenAI.Application.Services.Systems
{
    public class SodMatrixAppService : GenAIAppServiceBase, ISodMatrixAppService
    {
        private readonly ISodMatrixDomainService _sodMatrixDomainService;

        public SodMatrixAppService(ISodMatrixDomainService sodMatrixDomainService)
        {
            _sodMatrixDomainService = sodMatrixDomainService;
        }

        [HttpPost]
        [AbpAuthorize()]
        public async Task<SystemResponseDto> CreateAsync(CreateSodMatrixRequestDto sodMatrixDto)
        {
            var response = await _sodMatrixDomainService.Create(sodMatrixDto);
            return response;
        }

        [HttpGet]
        [AbpAuthorize()]
        public PagedResultDto<SodMatrixDto> GetAllPaged(FilterSodMatrixDto filter)
        {
            var response = _sodMatrixDomainService.GetAllPaged(filter);
            return response;
        }

        [HttpDelete]
        [AbpAuthorize()]
        public async Task DeleteAsync([FromQuery] Guid id)
        {
            await _sodMatrixDomainService.DeleteAsync(id);
        }

        [HttpPut]
        [AbpAuthorize()]
        public async Task UpdateAsync(UpdateSodMatrixRequestDto sodMatrixDto)
        {
            await _sodMatrixDomainService.UpdateAsync(sodMatrixDto);
        }

        [HttpGet]
        [AbpAuthorize()]
        public async Task<SodMatrixDto> GetByIdAsync([FromQuery] Guid id)
        {
            return await _sodMatrixDomainService.GetByIdAsync(id);
        }
    }
}
