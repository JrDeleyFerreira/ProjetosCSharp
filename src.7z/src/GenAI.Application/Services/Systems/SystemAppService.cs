﻿using Abp.Authorization;
using GenAI.Core.Contracts.Services.Systems;
using GenAI.Crosscutting.Entities.Dto.Systems;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using System;
using GenAI.Core.Impl.Services.Authorization;
using Abp.Application.Services.Dto;

namespace GenAI.Application.Services.Systems
{
    [AbpAuthorize(PermissionNames.Analysts)]
    public class SystemAppService : GenAIAppServiceBase, ISystemAppService
    {
        private readonly ISystemDomainService _systemDomainService;

        public SystemAppService(ISystemDomainService systemDomainService)
        {
            _systemDomainService = systemDomainService;
        }

        [HttpPost]
        [AbpAuthorize()]
        public async Task<SystemResponseDto> CreateAsync(CreateSystemRequestDto systemDto)
        {
            var response = await _systemDomainService.Create(systemDto);
            return response;
        }

        [HttpPut]
        [AbpAuthorize()]
        public async Task UpdateAsync(UpdateSystemRequestDto systemDto)
        {
            await _systemDomainService.UpdateAsync(systemDto);
        }

        [HttpGet]
        [AbpAuthorize()]
        public PagedResultDto<SystemDto> GetAllPaged(FilterSystemDto filter)
        {
            var response = _systemDomainService.GetAllPaged(filter);
            return response;
        }

        [HttpDelete]
        [AbpAuthorize()]
        public async Task DeleteAsync([FromQuery]Guid id)
        {
            await _systemDomainService.DeleteAsync(id);
        }

        [HttpGet]
        [AbpAuthorize()]
        public async Task<SystemDto> GetByIdAsync([FromQuery] Guid id)
        {
            return await _systemDomainService.GetByIdAsync(id);
        }
    }
}
