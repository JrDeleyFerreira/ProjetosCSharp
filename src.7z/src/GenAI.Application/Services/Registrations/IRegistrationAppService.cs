﻿using Abp.Application.Services;
using Abp.Application.Services.Dto;
using GenAI.Crosscutting.Entities.Dto.Registrations;
using System;
using System.Threading.Tasks;

namespace GenAI.Application.Services.Registrations;

public interface IRegistrationAppService : IApplicationService
{
	Task<RegistrationResponseDto> CreateAsync(CreateRegistrationDto registrationDto);
	Task DeleteAsync(Guid id);
	Task<RegistrationDto> GetByIdAsync(Guid id);
	Task UpdateAsync(UpdateRegistrationRequestDto registrationDto);
	PagedResultDto<RegistrationDto> GetAllPaged(FilterRegistrationDto filter);

}
