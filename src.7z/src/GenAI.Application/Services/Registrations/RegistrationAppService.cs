﻿using Abp.Application.Services.Dto;
using Abp.Authorization;
using GenAI.Core.Contracts.Services.Registrations;
using GenAI.Core.Impl.Services.Authorization;
using GenAI.Crosscutting.Entities.Dto.Registrations;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;

namespace GenAI.Application.Services.Registrations;

[AbpAuthorize(PermissionNames.Analysts)]
public class RegistrationAppService : GenAIAppServiceBase, IRegistrationAppService
{
	private readonly IRegistrationDomainService _registrationDomainService;

	public RegistrationAppService(IRegistrationDomainService registrationDomainService)
	{
		_registrationDomainService = registrationDomainService;
	}

	[HttpPost]
	[AbpAuthorize()]
	public async Task<RegistrationResponseDto> CreateAsync(CreateRegistrationDto registrationDto)
	{
		var response = await _registrationDomainService.Create(registrationDto);
		return response;
	}

	[HttpDelete]
	[AbpAuthorize()]
	public async Task DeleteAsync(Guid id) =>
		await _registrationDomainService.DeleteAsync(id);

	[HttpGet]
	[AbpAuthorize()]
	public PagedResultDto<RegistrationDto> GetAllPaged(FilterRegistrationDto filter) => 
		_registrationDomainService.GetAllPaged(filter);

	[HttpGet]
	[AbpAuthorize()]
	public async Task<RegistrationDto> GetByIdAsync(Guid id) => 
		await _registrationDomainService.GetByIdAsync(id);

	[HttpPut]
	[AbpAuthorize()]
	public async Task UpdateAsync(UpdateRegistrationRequestDto registrationDto) => 
		await _registrationDomainService.UpdateAsync(registrationDto);
}
