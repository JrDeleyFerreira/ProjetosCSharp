﻿using Abp.Application.Services.Dto;
using Abp.Authorization;
using GenAI.Core.Contracts.Services.Employees;
using GenAI.Crosscutting.Entities.Dto.Employees;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;

namespace GenAI.Application.Services.Employees;

public class EmployeeAppService : GenAIAppServiceBase, IEmployeeAppService
{
	private readonly IEmployeeDomainService _employeeDomainService;

	public EmployeeAppService(IEmployeeDomainService employeeDomainService) => _employeeDomainService = employeeDomainService;

	[HttpPost]
	[AbpAuthorize()]
	public async Task<ResponseEmployeeDto> CreateAsync(CreateEmployeeDto employee)
	{
		var response = await _employeeDomainService.InsertAsync(employee);
		return response;
	}

	[HttpDelete]
	[AbpAuthorize()]
	public async Task DeleteAsync(Guid id) 
		=> await _employeeDomainService.DeleteAsync(id);

	[HttpGet]
	[AbpAuthorize()]
	public PagedResultDto<EmployeeDto> GetAllPaged(FilterEmployeeDto filter) 
		=> _employeeDomainService.GetAllPaged(filter);

	[HttpGet]
	[AbpAuthorize()]
	public async Task<EmployeeDto> GetByIdAsync(Guid id) 
		=> await _employeeDomainService.GetByIdAsync(id);

	[HttpPut]
	[AbpAuthorize()]
	public async Task UpdateAsync(UpdateEmployeeDto updateEmployee) 
		=> await _employeeDomainService.UpdateAsync(updateEmployee);
}
