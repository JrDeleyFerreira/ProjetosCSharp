﻿using Abp.Application.Services;
using Abp.Application.Services.Dto;
using GenAI.Crosscutting.Entities.Dto.Employees;
using System;
using System.Threading.Tasks;

namespace GenAI.Application.Services.Employees;

public interface IEmployeeAppService : IApplicationService
{
	Task<ResponseEmployeeDto> CreateAsync(CreateEmployeeDto employee);
	Task DeleteAsync(Guid id);
	Task<EmployeeDto> GetByIdAsync(Guid id);
	Task UpdateAsync(UpdateEmployeeDto updateEmployee);
	PagedResultDto<EmployeeDto> GetAllPaged(FilterEmployeeDto filter);
}
