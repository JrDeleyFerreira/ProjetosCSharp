﻿using Abp.Application.Services.Dto;
using GenAI.Application.Dto.Roles;
using GenAI.Application.Services.Shared;
using GenAI.Crosscutting.Entities.Dto.Users;
using GenAI.Domain.Entities;
using System.Threading.Tasks;

namespace GenAI.Application.Services.Users
{
    public interface IUserAppService : IGenAIAppServiceBase<UserDto, long, PagedUserResultRequestDto, CreateUserDto, UpdateUserDto, GetUserDto, DeleteUserDto, FilterUserDto>
    {
        Task<ListResultDto<RoleDto>> GetRoles();

        Task ChangeLanguage(ChangeUserLanguageDto input);

        Task <UpdateUserStatusOutputDto> UpdateStatusAsync(UpdateUserStatusDto input);     
           
    }
}