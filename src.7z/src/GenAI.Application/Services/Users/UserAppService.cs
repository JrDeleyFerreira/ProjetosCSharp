﻿using Abp.Application.Services.Dto;
using Abp.Authorization;
using Abp.Domain.Repositories;
using Abp.Localization;
using Abp.Runtime.Session;
using GenAI.Application.Dto.Roles;
using GenAI.Application.Services.Shared;
using GenAI.Core.Contracts.Services.Users;
using GenAI.Core.Impl.Services.Authorization;
using GenAI.Core.Impl.Services.Roles;
using GenAI.Core.Impl.Services.Users;
using GenAI.Crosscutting.Entities.Dto.Users;
using GenAI.Domain.Entities;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GenAI.Application.Services.Users
{
    [AbpAuthorize(PermissionNames.Pages_Users)]
    public class UserAppService : GenAIAppServiceBase<User, long, UserDto, UserDto, CreateUserDto, UpdateUserDto, GetUserDto, DeleteUserDto, FilterUserDto>, IUserAppService
    {
        private readonly UserManager _UserManager;
        private readonly RoleManager _RoleManager;
        private readonly IRepository<Role> _RoleRepository;
        private readonly AbpUserClaimsPrincipalFactory<User, Role> _ClaimsPrincipalFactory;
        private readonly IUserDomainService _userDomainService;

        public UserAppService(
            IRepository<User, long> repository,
            UserManager userManager,
            IUserDomainService userDomainService,
            RoleManager roleManager,
            IRepository<Role> roleRepository,
            AbpUserClaimsPrincipalFactory<User, Role> claimsPrincipalFactory)
            : base(repository, userDomainService)
        {
            _UserManager = userManager;
            _RoleManager = roleManager;
            _RoleRepository = roleRepository;
            _ClaimsPrincipalFactory = claimsPrincipalFactory;
            _userDomainService = userDomainService;


        }
        [AbpAuthorize(PermissionNames.Pages_Users)]
        public override async Task<UserDto> CreateAsync(CreateUserDto input)
        {
            User user = await DomainService.CreateAsync(input);
            return MapUserEntityDto(user);
        }
        [AbpAuthorize(PermissionNames.Pages_Users)]
        public override async Task<UserDto> UpdateAsync(UpdateUserDto input)
        {
            User user = await DomainService.UpdateAsync(input);
            return MapUserEntityDto(user);
        }

        [AbpAuthorize(PermissionNames.Page_Admin)]
        [HttpPut]
        public async Task<UpdateUserStatusOutputDto> UpdateStatusAsync(UpdateUserStatusDto input)
        {
            return ObjectMapper.Map<UpdateUserStatusOutputDto>(await _userDomainService.UpdateStatusAsync(input));

        }
             

        [AbpAuthorize(PermissionNames.Pages_Users)]
        public override async Task<UserDto> GetAsync(GetUserDto input)
        {
            UserDto user = await _userDomainService.GetUserWithTenants(input.Id);
            return user;
        }

        [AbpAuthorize(PermissionNames.Pages_Users)]
        public async Task<ListResultDto<RoleDto>> GetRoles()
        {
            var roles = await _RoleRepository.GetAllListAsync();
            if (await _UserManager.IsAdmin(UserId) == false)
            {
                Role role = roles.FirstOrDefault(n => n.Name == "Admin");
                roles.Remove(role);
            }

            return new ListResultDto<RoleDto>(ObjectMapper.Map<List<RoleDto>>(roles));
        }
        [AbpAuthorize(PermissionNames.Analysts)]
        public async Task ChangeLanguage(ChangeUserLanguageDto input)
        {
            await SettingManager.ChangeSettingForUserAsync(
                AbpSession.ToUserIdentifier(),
                LocalizationSettingNames.DefaultLanguage,
                input.LanguageName
            );
        }

        protected UserDto MapUserEntityDto(User user)
        {
            var roles = _RoleManager.Roles.AsEnumerable().Where(r => user.Roles.Any(ur => ur.RoleId == r.Id)).Select(r => r.NormalizedName);
            UserDto userDto = base.MapToEntityDto(user);
            userDto.RoleNames = roles.ToArray();
            return userDto;
        }

    }
}



