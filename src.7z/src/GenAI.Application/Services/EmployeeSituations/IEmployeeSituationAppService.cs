﻿using Abp.Application.Services;
using Abp.Application.Services.Dto;
using GenAI.Crosscutting.Entities.Dto.EmployeeSituations;
using Microsoft.AspNetCore.Http;
using System;
using System.Threading.Tasks;

namespace GenAI.Application.Services.EmployeeSituations;

public interface IEmployeeSituationAppService : IApplicationService
{
    Task<ResponseEmployeeSituationDto> CreateAsync(CreateEmployeeSituationDto employee);
    Task DeleteAsync(Guid id);
    Task<EmployeeSituationDto> GetByIdAsync(Guid id);
    Task UpdateAsync(UpdateEmployeeSituationDto updateEmployee);
    PagedResultDto<EmployeeSituationDto> GetAllPaged(FilterEmployeeSituationDto filter);
    Task ImportSpreadsheetAsync(IFormFile formImport, string referenceTime);
}
