﻿using Abp.Application.Services.Dto;
using Abp.Authorization;
using GenAI.Core.Contracts.Services.EmployeeSituations;
using GenAI.Crosscutting.Entities.Dto.EmployeeSituations;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;

namespace GenAI.Application.Services.EmployeeSituations;

public class EmployeeSituationAppService : GenAIAppServiceBase, IEmployeeSituationAppService
{
    private readonly IEmployeeSituationDomainService _employeeDomainService;

    public EmployeeSituationAppService(IEmployeeSituationDomainService employeeDomainService) => _employeeDomainService = employeeDomainService;

    [HttpPost]
    [AbpAuthorize()]
    public async Task<ResponseEmployeeSituationDto> CreateAsync(CreateEmployeeSituationDto employee)
    {
        var response = await _employeeDomainService.InsertAsync(employee);
        return response;
    }

    [HttpDelete]
    [AbpAuthorize()]
    public async Task DeleteAsync(Guid id)
        => await _employeeDomainService.DeleteAsync(id);

    [HttpGet]
    [AbpAuthorize()]
    public PagedResultDto<EmployeeSituationDto> GetAllPaged(FilterEmployeeSituationDto filter)
        => _employeeDomainService.GetAllPaged(filter);

    [HttpGet]
    [AbpAuthorize()]
    public async Task<EmployeeSituationDto> GetByIdAsync(Guid id)
        => await _employeeDomainService.GetByIdAsync(id);

    [HttpPost]
    [AbpAuthorize()]
    public async Task ImportSpreadsheetAsync(IFormFile formImport, string referenceTime)
        => await _employeeDomainService.ImportSpreadsheetAsync(formImport, referenceTime);

    [HttpPut]
    [AbpAuthorize()]
    public async Task UpdateAsync(UpdateEmployeeSituationDto updateEmployee)
        => await _employeeDomainService.UpdateAsync(updateEmployee);
}
