﻿using Abp.Application.Services;
using GenAI.Application.Dto.Sessions;
using System.Threading.Tasks;

namespace GenAI.Application.Services.Sessions
{
    public interface ISessionAppService : IApplicationService
    {
        Task<GetCurrentLoginInformationsOutput> GetCurrentLoginInformations();
    }
}


