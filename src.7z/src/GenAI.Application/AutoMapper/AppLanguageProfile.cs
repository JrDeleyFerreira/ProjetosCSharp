﻿using AutoMapper;
using GenAI.Crosscutting.Entities.Dto.Language;
using GenAI.Domain.Entities.Langague;

namespace GenAI.Application.AutoMapper
{
    public class AppLanguageProfile : Profile
    {
        public AppLanguageProfile() 
        {
            CreateMap<AppLanguage, AppLanguageDto>();
            CreateMap<AppLanguageDto, AppLanguage>();
        }
    }
}
