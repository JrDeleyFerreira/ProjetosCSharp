﻿using Abp.AutoMapper;
using Abp.EntityFrameworkCore;
using Abp.FluentValidation;
using Abp.Modules;
using Abp.Reflection.Extensions;
using GenAI.Core;
using GenAI.Core.Impl.Services.Authorization;
using GenAI.Crosscutting.Entities;
using GenAI.Crosscutting.Infra;
using System.Reflection;

namespace GenAI.Application
{
    [DependsOn(
        typeof(GenAIDomainModule),
        typeof(GenAIDomainCosmosModule),
        typeof(AbpAutoMapperModule),
        typeof(AbpEntityFrameworkCoreModule),
        typeof(GenAICrosscuttingInfraModule),
        typeof(AbpFluentValidationModule),
        typeof(GenAICrossCuttingEntitiesModule),
        typeof(AzureTableStorageModule),
        typeof(DinkToPdfModule)
        )
        ]
    public class GenAIApplicationModule : AbpModule
    {

        public override void PreInitialize()
        {
            Configuration.Authorization.Providers.Add<GenAIAuthorizationProvider>();
        }

        public override void Initialize()
        {
            Assembly thisAssembly = typeof(GenAIApplicationModule).GetAssembly();

            IocManager.RegisterAssemblyByConvention(thisAssembly);

            Configuration.Modules.AbpAutoMapper().Configurators.Add(
                // Scan the assembly for classes which inherit from AutoMapper.Profile
                cfg => cfg.AddMaps(thisAssembly)
            );
        }

        public override void PostInitialize()
        {
        }
    }
}


