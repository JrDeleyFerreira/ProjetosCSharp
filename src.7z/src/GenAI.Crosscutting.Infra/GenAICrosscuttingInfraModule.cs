﻿using Abp.Dependency;
using Abp.FluentValidation;
using Abp.Modules;
using Abp.Reflection.Extensions;
using Castle.MicroKernel.Registration;
using GenAI.Crosscutting.Infra.Logs;
using GenAI.Crosscutting.Infra.Services;
using GenAI.Crosscutting.Infra.Settings;
using GenAI.Crosscutting.Infra.Util;

namespace GenAI.Crosscutting.Infra
{
    [DependsOn(typeof(AbpFluentValidationModule))]
    public class GenAICrosscuttingInfraModule : AbpModule
    {
        public override void PreInitialize()
        {
            Configuration.Settings.Providers.Add<GenAISettingProvider>();
        }

        public override void Initialize()
        {
            IocManager.RegisterAssemblyByConvention(typeof(GenAICrosscuttingInfraModule).GetAssembly());
            IocManager.Register<IServiceBusService, ServiceBusService>();
            IocManager.Register<IBlobService, BlobService>();
        }
    }
}


