﻿using System.Security.Cryptography;
using System.Xml.Linq;
using System;

namespace GenAI.Crosscutting.Infra.Extensions;

public static class RSAExtensions
{
    public static void FromXml(this RSA rsa, string xmlString)
    {
        RSAParameters parameters = new RSAParameters();

        XDocument xmlDoc = XDocument.Parse(xmlString);
        XElement root = xmlDoc.Element("RSAKeyValue");
        if (root == null) throw new ArgumentException("Invalid XML RSA key.");

        parameters.Modulus = Convert.FromBase64String(root.Element("Modulus")?.Value);
        parameters.Exponent = Convert.FromBase64String(root.Element("Exponent")?.Value);

        if (root.Element("P") != null)
        {
            parameters.P = Convert.FromBase64String(root.Element("P")?.Value);
            parameters.Q = Convert.FromBase64String(root.Element("Q")?.Value);
            parameters.DP = Convert.FromBase64String(root.Element("DP")?.Value);
            parameters.DQ = Convert.FromBase64String(root.Element("DQ")?.Value);
            parameters.InverseQ = Convert.FromBase64String(root.Element("InverseQ")?.Value);
            parameters.D = Convert.FromBase64String(root.Element("D")?.Value);
        }

        rsa.ImportParameters(parameters);
    }
}