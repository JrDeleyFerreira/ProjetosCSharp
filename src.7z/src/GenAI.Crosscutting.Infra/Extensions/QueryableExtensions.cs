﻿using System;
using System.Linq;
using System.Linq.Expressions;

namespace GenAI.Crosscutting.Infra.Extensions
{
    public static class QueryableExtensions
    {
        public static IQueryable<T> Between<T, TKey>(this IQueryable<T> query, Expression<Func<T, TKey>> keySelector, TKey from, TKey to)
            where TKey : IComparable<TKey>
        {
            var left = Expression.GreaterThanOrEqual(keySelector.Body, Expression.Constant(from));
            var right = Expression.LessThanOrEqual(keySelector.Body, Expression.Constant(to));
            var body = Expression.And(left, right);
            var predicate = Expression.Lambda<Func<T, bool>>(body, keySelector.Parameters);
            return query;
        }
    }
}