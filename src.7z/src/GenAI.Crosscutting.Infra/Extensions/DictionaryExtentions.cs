﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;

namespace GenAI.Crosscutting.Infra.Extensions
{
    public static class DictionaryExtentions
    {
        /// <summary>
        /// Método utilizado para converter um Dictionary para representação em formato texto.
        /// </summary>
        /// <typeparam name="TKey">Tipo das chaves do mapa.</typeparam>
        /// <typeparam name="TValue">Tipo dos valores do mapa.</typeparam>
        /// <param name="paramDictionary">Mapa de chave e valor.</param>
        /// <returns> Uma string no formato: [chave1=valor1, chave2=valor2]</returns>
        public static string ToPrettyString<TKey, TValue>(this IDictionary<TKey, TValue> paramDictionary)
        {
            return "[" + string.Join(",", paramDictionary.Select(x => x.Key + "=" + x.Value).ToArray()) + "]";
        }



        public static string ToQueryString<TKey, TValue>(this IEnumerable<KeyValuePair<TKey, TValue>> obj)
        {
            var sb = new StringBuilder();
            foreach (var kv in obj)
            {
                if (kv.Value == null)
                    continue;
                if (sb.Length > 0)
                    sb.Append('&');
                sb.Append(EncodeQueryParamValue(kv.Key, true));
                sb.Append('=');
                sb.Append(EncodeQueryParamValue(kv.Value, true));
            }

            return sb.ToString();
        }
        /// <summary>
		/// URL-encodes a query parameter value.
		/// </summary>
		/// <param name="value">The query parameter value to encode.</param>
		/// <param name="encodeSpaceAsPlus">If true, spaces will be encoded as + signs. Otherwise, they'll be encoded as %20.</param>
		/// <returns></returns>
		private static string EncodeQueryParamValue(object value, bool encodeSpaceAsPlus)
        {
            var culture = new CultureInfo(CultureInfo.CurrentCulture.Name)
            {
                NumberFormat = NumberFormatInfo.InvariantInfo
            };
            var result = Uri.EscapeDataString(Convert.ToString(value ?? "", culture));
            return encodeSpaceAsPlus ? result.Replace("%20", "+") : result;
        }
    }
}


