﻿using System.Collections.Generic;
using System.Reflection;

namespace GenAI.Crosscutting.Infra.Extensions
{
    public static class AssemblyExtensions
    {
        public static IEnumerable<Assembly> GetAllReferencedAssemblies(this Assembly asbly)
        {
            var list = new List<string>();
            var stack = new Stack<Assembly>();

            stack.Push(asbly);

            do
            {
                var asm = stack.Pop();

                yield return asm;

                foreach (var reference in asm.GetReferencedAssemblies())
                    if (!list.Contains(reference.FullName))
                    {
                        stack.Push(Assembly.Load(reference));
                        list.Add(reference.FullName);
                    }

            }
            while (stack.Count > 0);

        }
    }
}


