﻿using Abp.Logging;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Dynamic;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;

namespace GenAI.Crosscutting.Infra.Extensions
{
    public static class ObjectExtentions
    {

        public static dynamic Merge(this object item1, object item2)
        {
            if (item1 == null || item2 == null)
                return item1 ?? item2 ?? new ExpandoObject();

            dynamic expando = new ExpandoObject();
            var result = (IDictionary<string, object>)expando;
            foreach (PropertyInfo fi in item1.GetType().GetProperties().Where(p => p.CanRead))
            {
                result[fi.Name] = fi.GetValue(item1, null);
            }
            foreach (PropertyInfo fi in item2.GetType().GetProperties().Where(p => p.CanRead))
            {
                result[fi.Name] = fi.GetValue(item2, null);
            }
            return result;
        }

        /// <summary>
        /// This wrapper around Convert.ChangeType was done to handle nullable types.
        /// See original authors work here: http://aspalliance.com/852
        /// </summary>
        /// <param name="value">The value to convert.</param>
        /// <param name="conversionType">The type to convert to.</param>
        /// <returns></returns>
        public static object ChangeType(this object value, Type conversionType)
        {
            if (conversionType == null)
            {
                throw new ArgumentNullException(nameof(conversionType));
            }

            if (value?.GetType() == conversionType)
            {
                return value;
            }

            if (conversionType.IsEnum && value != null)
            {
                try
                {
                    return Enum.Parse(conversionType, value.ToString());
                }
                catch
                {
                    LogHelper.Logger.Warn($"Não foi possível transformar o valor {value} para enum {conversionType.Name}.");
                    throw;
                }
            }

            if (conversionType.IsGenericType && conversionType.GetGenericTypeDefinition() == typeof(Nullable<>))
            {
                if (value == null)
                {
                    return null;
                }

                NullableConverter nullableConverter = new NullableConverter(conversionType);
                conversionType = nullableConverter.UnderlyingType;
            }
            return Convert.ChangeType(value, conversionType);
        }

        public static bool CanChangeType(this object value, Type conversionType)
        {
            if (conversionType == null)
            {
                return false;
            }

            IConvertible convertible = value as IConvertible;

            if (convertible == null)
            {
                return false;
            }

            return true;
        }
        public static MethodInfo GetMethod<T>(Expression<Func<T>> expression)
        {
            return ((MethodCallExpression)expression.Body).Method;
        }

        public static bool IsFunc(this object obj)
        {
            if (obj == null)
            {
                return false;
            }

            var type = obj.GetType();
            if (!type.IsGenericType)
            {
                return false;
            }

            return type.GetGenericTypeDefinition() == typeof(Func<>);
        }

        public static bool IsFunc<TReturn>(this object obj)
        {
            return obj is Func<TReturn>;
        }


        public static string ToNullSafeString(this object value)
        {
            return value?.ToString() ?? string.Empty;
        }
    }
}



