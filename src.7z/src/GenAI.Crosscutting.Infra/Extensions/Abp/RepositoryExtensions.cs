﻿using Abp.Domain.Entities;
using Abp.Domain.Repositories;
using Abp.EntityFrameworkCore.Repositories;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace GenAI.Crosscutting.Infra.Extensions.Abp
{
    public static class RepositoryExtensions
    {
        public static void BulkUpdate<TEntity, TPrimaryKey>(this IRepository<TEntity, TPrimaryKey> repository, IList<TEntity> entities) where TEntity : class, IEntity<TPrimaryKey>
        {
            repository.GetDbContext().UpdateRange(entities);
        }
        public static void BulkInsert<TEntity, TPrimaryKey>(this IRepository<TEntity, TPrimaryKey> repository, IList<TEntity> entities) where TEntity : class, IEntity<TPrimaryKey>
        {
            repository.GetDbContext().AddRange(entities);
        }
        public static async Task BulkInsertAsync<TEntity, TPrimaryKey>(this IRepository<TEntity, TPrimaryKey> repository, IList<TEntity> entities) where TEntity : class, IEntity<TPrimaryKey>
        {
            await repository.GetDbContext().AddRangeAsync(entities);
        }
    }
}
