﻿using Abp.Dependency;
using Abp.Runtime.Session;
using Microsoft.AspNetCore.Http;
using System;
using System.Linq;

namespace GenAI.Crosscutting.Infra.Extensions.Abp
{
    public static class AbpSessionExtensions
    {
        public static string GetClaimValue(this IAbpSession session, string claimType)
        {
            IPrincipalAccessor principalAccessor = IocManager.Instance.Resolve<IPrincipalAccessor>();
            return principalAccessor.Principal?.Claims.FirstOrDefault(c => c.Type.EqualsIgnoreCase(claimType))?.Value;
        }
        public static Guid? GetTenant(this IAbpSession session)
        {

            IHttpContextAccessor httpContextAccessor = IocManager.Instance.Resolve<IHttpContextAccessor>();

            var tenantId = httpContextAccessor.HttpContext.Request.Headers["avanade-tenant-id"];

            if (!tenantId.Any()) return null;

            if (Guid.TryParse(tenantId.First(), out Guid idTenant))
            {
                return idTenant;
            }
            throw new ApplicationException("Invalid Tenant ID");
        }
    }
}


