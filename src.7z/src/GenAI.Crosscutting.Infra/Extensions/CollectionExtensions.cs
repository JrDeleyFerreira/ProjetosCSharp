﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace GenAI.Crosscutting.Infra.Extensions
{
    public static class CollectionExtensions
    {
        public static string JoinSperator<T>(this ICollection<T> source, string separator)
        {
            var array = source.ToArray();

            return string.Join(separator, array);
        }
        public static void Add<T>(this ICollection<T> source, ICollection<T> enumerable)
        {
            foreach (var item in enumerable)
            {
                source.Add(item);
            }
        }

        public static string[] ToLower(this string[] source)
        {
            if (source != null && source.Any())
            {
                return source.Select(item => item?.ToLower()).ToArray();
            }
            return source;
        }

        public static void Remove<T>(this ICollection<T> source, ICollection<T> enumerable)
        {
            foreach (var item in enumerable)
            {
                source.Remove(item);
            }
        }

        public static void Remove<T>(this ICollection<T> source, Func<T, bool> predicate)
        {
            for (int i = 0; i < source.Count; i++)
            {
                T entity = source.ElementAt(i);

                if (predicate(entity))
                {
                    source.Remove(entity);
                    i--;
                }
            }
        }

        public static bool Contains<T>(this ICollection<T> source, ICollection<T> enumerable)
        {
            bool result = false;

            foreach (var item in enumerable)
            {
                result = source.Contains(item);
                if (!result)
                {
                    break;
                }
            }

            return result;
        }
    }
}


