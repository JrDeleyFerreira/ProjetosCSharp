﻿using System;

namespace GenAI.Crosscutting.Infra.Extensions
{
    public static class NumberExtensions
    {
        public static int IntPart(this decimal number)
        {
            return Convert.ToInt32(Math.Floor(Convert.ToDouble(number)));
        }

        public static int IntPart(this decimal? number)
        {
            return number?.IntPart() ?? 0;
        }

        public static string IntPartAsText(this decimal number)
        {
            return number.IntPart().ToString();
        }

        public static string IntPartAsText(this decimal? number)
        {
            return number.IntPart().ToString();
        }

        public static decimal DecimalPart(this decimal number)
        {
            return number - Convert.ToDecimal(Math.Floor(Convert.ToDouble(number)));
        }

        public static decimal DecimalPart(this decimal? number)
        {
            return number?.DecimalPart() ?? 0;
        }

        public static string DecimalPartAsText(this decimal number)
        {
            return $"{number.DecimalPart():.00}".OnlyNumbers();
        }

        public static string DecimalPartAsText(this decimal? number)
        {
            return $"{number.DecimalPart():.00}".OnlyNumbers();
        }

        public static T ToEnum<T>(this int number) where T : struct
        {
            return (T)(object)number;
        }
    }
}


