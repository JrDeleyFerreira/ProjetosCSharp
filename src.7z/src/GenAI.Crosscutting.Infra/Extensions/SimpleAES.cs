﻿using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace GenAI.Crosscutting.Infra.Extensions
{
    internal class SimpleAES
    {
        private readonly byte[] key =
        {
            137, 3, 245, 141, 77, 183, 113, 62, 6, 131, 73, 185, 56, 19, 243, 222, 98, 194,
            49, 173, 69, 208, 122, 2, 147, 172, 234, 0, 32, 124, 54, 34
        };

        private readonly byte[] vector = { 7, 137, 238, 233, 144, 169, 91, 0, 47, 76, 212, 221, 179, 185, 165, 164 };

        private readonly ICryptoTransform encryptor;
        private readonly ICryptoTransform decryptor;
        private readonly UTF8Encoding encoder;

        public SimpleAES()
        {
            var rm = new RijndaelManaged();
            encryptor = rm.CreateEncryptor(key, vector);
            decryptor = rm.CreateDecryptor(key, vector);
            encoder = new UTF8Encoding();
        }

        public string Encrypt(string unencrypted)
        {
            return Convert.ToBase64String(Encrypt(encoder.GetBytes(unencrypted)));
        }

        public string Decrypt(string encrypted)
        {
            return encoder.GetString(Decrypt(Convert.FromBase64String(encrypted)));
        }

        public byte[] Encrypt(byte[] buffer)
        {
            return Transform(buffer, encryptor);
        }

        public byte[] Decrypt(byte[] buffer)
        {
            return Transform(buffer, decryptor);
        }

        protected byte[] Transform(byte[] buffer, ICryptoTransform transform)
        {

            using (var stream = new MemoryStream())
            {
                using (var cs = new CryptoStream(stream, transform, CryptoStreamMode.Write))
                {
                    cs.Write(buffer, 0, buffer.Length);
                }
                return stream.ToArray();
            }
        }

    }
}

