﻿using System.Linq;

namespace GenAI.Crosscutting.Infra.Extensions
{
    public static class ArrayExtensions
    {
        public static string JoinWithQuotationMarks(this object[] array, string separator)
        {
            return string.Join(separator, array.Select(item => $"'{item}'"));
        }

        public static string JoinWithQuotationMarks(this object[] array)
        {
            return JoinWithQuotationMarks(array, ",");
        }
    }
}


