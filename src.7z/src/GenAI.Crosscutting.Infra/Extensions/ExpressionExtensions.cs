﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;

namespace GenAI.Crosscutting.Infra.Extensions
{
    public static class ExpressionExtensions
    {
        public static bool EqualsPropertyBody<T>(this Expression<Func<T, object>> propertyExpression, Expression<Func<T, object>> propertyExpressionToCompare)
        {
            return propertyExpression.ToPropertyBodyString() == propertyExpressionToCompare.ToPropertyBodyString();
        }
        public static string ToPropertyBodyString<T>(this Expression<Func<T, object>> propertyExpression)
        {
            return string.Join(".", GetProperties(propertyExpression).Select(p => p.Name));
        }

        public static IEnumerable<PropertyInfo> GetProperties<T>(this Expression<Func<T, object>> propertyExpression)
        {
            return RecursiveGetProperties(propertyExpression.Body);
        }

        public static IEnumerable<PropertyInfo> RecursiveGetProperties(this Expression expression)
        {
            var memberExpression = expression as MemberExpression;

            if (memberExpression == null)
            {
                UnaryExpression unaryExpression = expression as UnaryExpression;
                if (unaryExpression != null)
                {
                    var op = unaryExpression.Operand;
                    memberExpression = (op as MemberExpression);
                }
            }


            if (memberExpression == null) yield break;

            var property = memberExpression.Member as PropertyInfo;
            if (property == null)
            {
                throw new ArgumentException("Expression is not a property accessor");
            }
            foreach (PropertyInfo propertyInfo in RecursiveGetProperties(memberExpression.Expression))
            {
                yield return propertyInfo;
            }
            yield return property;
        }
    }
}

