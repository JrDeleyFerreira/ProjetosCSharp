﻿using System;

namespace GenAI.Crosscutting.Infra.Extensions
{
    public static class DateTimeExtensions
    {
        public static int Idade(this DateTime dataNascimento)
        {
            int idade = DateTime.Now.Year - dataNascimento.Year;

            if (DateTime.Now.Month < dataNascimento.Month
                || (DateTime.Now.Month == dataNascimento.Month && DateTime.Now.Day < dataNascimento.Day))
            {
                idade--;
            }

            return idade;
        }

        public static double TotalHour(this DateTime dataHora)
        {
            return dataHora.Hour + dataHora.Minute / 60.0;
        }

        public static DateTime CheckWeekend(this DateTime date)
        {
            if (date.DayOfWeek == DayOfWeek.Sunday)
            {
                return date.AddDays(-2);
            }

            if (date.DayOfWeek == DayOfWeek.Saturday)
            {
                return date.AddDays(-1);
            }

            return date;
        }
    }
}


