﻿using Castle.MicroKernel.Registration;
using System;

namespace GenAI.Crosscutting.Infra.Extensions
{
    public static class WindsorExtensions
    {
        public static ComponentRegistration<T> OverrideExistingRegistration<T>(this ComponentRegistration<T> componentRegistration) where T : class
        {
            return componentRegistration
                                .Named(Guid.NewGuid().ToString())
                                .IsDefault();
        }
    }
}


