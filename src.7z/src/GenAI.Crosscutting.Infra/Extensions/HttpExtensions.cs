﻿using Abp;
using Abp.Authorization;
using Abp.Extensions;
using Abp.Threading;
using Abp.Web;
using Abp.Web.Models;
using GenAI.Crosscutting.Infra.Exceptions;
using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Net;
using System.Net.Http;

namespace GenAI.Crosscutting.Infra.Extensions
{
    public static class HttpExtensions
    {
        public static object ReadAsJsonObject(this HttpResponseMessage httpResponseMessage)
        {
            return httpResponseMessage.ReadAsJsonObject(null);
        }

        public static T ReadAsJsonObject<T>(this HttpResponseMessage httpResponseMessage) where T : class
        {
            return httpResponseMessage.ReadAsJsonObject(typeof(T)) as T;
        }

        public static object ReadAsJsonObject(this HttpResponseMessage httpResponseMessage, Type typeToDeserialize)
        {
            string resultContent = AsyncHelper.RunSync(() => httpResponseMessage.Content.ReadAsStringAsync());

            string mediaType = httpResponseMessage.Content?.Headers?.ContentType?.MediaType;
            if (mediaType != null && !mediaType.Contains("json"))
            {
                if (!httpResponseMessage.IsSuccessStatusCode)
                {
                    throw new AbpException(resultContent);
                }
                throw new AbpException($"A requisição espera um JSON como resultado mas outro formato foi retornado. {mediaType}.{Environment.NewLine}{resultContent}");
            }

            var response = JsonConvert.DeserializeObject(resultContent, typeToDeserialize, new JsonSerializerSettings { TypeNameHandling = TypeNameHandling.Auto });

            if (!httpResponseMessage.IsSuccessStatusCode)
            {
                AjaxResponseBase ajaxResponse = response as AjaxResponseBase;
                if (ajaxResponse != null)
                {
                    if (ajaxResponse.UnAuthorizedRequest || httpResponseMessage.StatusCode == HttpStatusCode.Forbidden || httpResponseMessage.StatusCode == HttpStatusCode.Unauthorized)
                    {
                        throw new AbpAuthorizationException(ajaxResponse.Error?.Message);
                    }

                    throw new GenAIValidationException(ajaxResponse.Error?.Message)
                    {
                        ValidationErrors =
                            ajaxResponse.Error?.ValidationErrors?.Select(
                                err => new ValidationResult(err.Message, err.Members)).ToList() ?? new List<ValidationResult>()
                    };
                }
                throw new HttpRequestException(resultContent);
            }

            return response;

        }

        public static HttpMethod ToHttpMethod(this HttpVerb httpVerb)
        {
            switch (httpVerb)
            {
                case HttpVerb.Get:
                    return HttpMethod.Get;
                case HttpVerb.Post:
                    return HttpMethod.Post;
                case HttpVerb.Put:
                    return HttpMethod.Put;
                case HttpVerb.Delete:
                    return HttpMethod.Delete;
                case HttpVerb.Options:
                    return HttpMethod.Options;
                case HttpVerb.Trace:
                    return HttpMethod.Trace;
                case HttpVerb.Head:
                    return HttpMethod.Head;
                default:
                    throw new ArgumentOutOfRangeException(nameof(httpVerb), httpVerb, null);
            }

        }

        public static List<KeyValuePair<string, object>> ToQueryStringNameValueList(this object obj, string prefix = "")
        {
            //TODO tbb 08/08/2016 Melhorar o tratamento para objetos com referencia ciclica, pode causar um stackoverflow. Como foi criado para transformar especialmente DTO, esse problema pode nunca ocorrer
            List<KeyValuePair<string, object>> propsDic = new List<KeyValuePair<string, object>>();

            if (obj != null)
            {
                var objType = obj.GetType();

                var isPrimitive = objType.IsPrimitiveExtendedIncludingNullable(includeEnums: true);
                if (isPrimitive)
                {
                    propsDic.Add(new KeyValuePair<string, object>(prefix, obj));
                }
                else if (objType != typeof(string) && objType.IsEnumerableType())
                {

                    foreach (var val in (IEnumerable)obj)
                    {
                        propsDic.AddRange(val.ToQueryStringNameValueList(prefix));
                        //propsDic.Add(new KeyValuePair<string, object>(prefix, val));
                    }
                }
                else
                {
                    foreach (var propertyInfo in objType.GetProperties())
                    {
                        if (propertyInfo.PropertyType != typeof(string) &&
                            propertyInfo.PropertyType.IsEnumerableType())
                        {
                            string propName = prefix.IsNullOrWhiteSpace()
                                ? propertyInfo.Name
                                : $"{prefix}.{propertyInfo.Name}";

                            foreach (var val in (IEnumerable)propertyInfo.GetValue(obj))
                            {
                                propsDic.Add(new KeyValuePair<string, object>(propName, val));
                            }
                        }
                        else
                        {
                            if (!propertyInfo.PropertyType.IsPrimitiveExtendedIncludingNullable())
                            {
                                var subObjVal = propertyInfo.GetValue(obj);
                                if (subObjVal != null)
                                {
                                    prefix = prefix.IsNullOrWhiteSpace()
                                        ? propertyInfo.Name
                                        : $"{prefix}.{propertyInfo.Name}";
                                    propsDic.Add(subObjVal.ToQueryStringNameValueList(prefix));
                                }
                            }
                            else
                            {
                                var propName = prefix.IsNullOrWhiteSpace()
                                    ? propertyInfo.Name
                                    : $"{prefix}.{propertyInfo.Name}";
                                propsDic.Add(new KeyValuePair<string, object>(propName, propertyInfo.GetValue(obj)));
                            }
                        }
                    }
                }
            }

            return propsDic;
        }
    }
}


