﻿
namespace GenAI.Crosscutting.Infra.Extensions
{
    public static class BoolExtensions
    {
        /// <summary>
        /// Converte uma variável do tipo bool? para string, considerando a regra:
        /// null -> null
        /// true -> "S"
        /// false -> "N"
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static string ConvertToString(this bool? value)
        {
            return value.HasValue ? ((bool)value).ConvertToString() : null;
        }

        /// <summary>
        /// Converte uma variável do tipo bool? para string, considerando a regra:
        /// null -> null
        /// true -> "S"
        /// false -> "N"
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static string ConvertToString(this bool value)
        {
            return value ? "S" : "N";
        }
    }
}


