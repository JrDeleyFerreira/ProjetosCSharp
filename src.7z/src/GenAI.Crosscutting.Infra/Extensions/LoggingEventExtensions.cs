﻿using log4net.Core;
using log4net.Layout;
using System.IO;
using System;

namespace GenAI.Crosscutting.Infra.Extensions;

public static class LoggingEventExtensions
{
    public static string GetFormattedString(this LoggingEvent loggingEvent, ILayout layout)
    {
        if (layout == null)
        {
            return $"{loggingEvent.RenderedMessage} {loggingEvent.GetExceptionString()}{Environment.NewLine}";
        }

        using StringWriter stringWriter = new();
        layout.Format(stringWriter, loggingEvent);
        string message = stringWriter.ToString();

        return message;
    }
}