﻿using GenAI.Crosscutting.Infra.Util;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;
using GenAI.Crosscutting.Infra.Settings;
using OfficeOpenXml.FormulaParsing.Excel.Functions.DateTime;
using System.Security.Cryptography.Xml;

namespace GenAI.Crosscutting.Infra.Extensions
{
    public static class StringExtentions
    {
        /// <summary>
        /// Regular expression, which is used to validate an E-Mail address.
        /// </summary>
        public const string MatchEmailPattern =
                  @"^(([\w-]+\.)+[\w-]+|([a-zA-Z]{1}|[\w-]{2,}))@"
           + @"((([0-1]?[0-9]{1,2}|25[0-5]|2[0-4][0-9])\.([0-1]?
				[0-9]{1,2}|25[0-5]|2[0-4][0-9])\."
           + @"([0-1]?[0-9]{1,2}|25[0-5]|2[0-4][0-9])\.([0-1]?
				[0-9]{1,2}|25[0-5]|2[0-4][0-9])){1}|"
           + @"([a-zA-Z]+[\w-]+\.)+[a-zA-Z]{2,4})$";

        /// <summary>
        /// Regular expression, which is used to validate an URL
        /// </summary>
        public const string MatchUrlPattern = @"^http(s)?:\/\/.+";

        /// <summary>
        /// Busca todos os index de "value" em uma string.
        /// </summary>
        public static IEnumerable<int> FindAll(this string str, string value)
        {
            var index = 0;

            while (true)
            {
                index = str.IndexOf(value, index + 1, StringComparison.Ordinal);

                if (index == -1)
                {
                    break;
                }

                yield return index;
            }
        }

        /// <summary>
        /// Verifica se uma URL informada é válida de acordo com expressão de validação.
        /// </summary>
        /// <param name="url">Url para validação.</param>
        /// <returns></returns>
        public static bool HasUrlFormat(this string url)
        {
            return Regex.IsMatch(url, MatchUrlPattern, RegexOptions.IgnoreCase);
        }

        public static string UrlEncode(this string text)
        {
            return HttpUtility.UrlEncode(text);
        }

        /// <summary>
        /// Verifica se um email informado é um endereço válido de acordo com expressão de validação.
        /// </summary>
        /// <param name="stringToTest">Parametro que contém o endereço de email para validação.</param>
        /// <returns>True, quando o parâmetro não está em branco e contém um endereço de E-mail válido;
        /// senão false.</returns>
        public static bool HasEmailFormat(this string stringToTest)
        {
            return !string.IsNullOrWhiteSpace(stringToTest) && Regex.IsMatch(stringToTest, MatchEmailPattern);
        }

        public static string ObfuscatedEmail(this string email)
        {
            if (!email.HasEmailFormat())
            {
                throw new ArgumentException("O valor não é um e-mail.", nameof(email));
            }

            string[] parts = email.Split('@');
            string firstPart = parts[0];
            string secondPart = parts[1];

            StringBuilder sb = new StringBuilder();
            ObfuscatedString(firstPart, sb);
            return sb.Append("@").Append(secondPart).ToString();
        }

        /// <summary>
        /// Exibe somente os ultimos 4 numeros do cartao de credito
        /// </summary>
        /// <param name="cardNumber"></param>
        /// <returns></returns>
        public static string ObfuscatedCreditCard(this string cardNumber)
        {
            if (cardNumber.Length > 4)
            {
                cardNumber = string.Concat("".PadLeft(cardNumber.Length - 4, '*'), cardNumber.Substring(cardNumber.Length - 4));
            }
            return cardNumber;
        }

        private static void ObfuscatedString(string part, StringBuilder result)
        {
            StringBuilder temp = new StringBuilder(part);

            if (temp.Length > 1)
            {
                int numberOfAsterisk = (int)Math.Ceiling(temp.Length / 3.0);

                temp.Remove(numberOfAsterisk, numberOfAsterisk)
                    .Insert(numberOfAsterisk, new string('*', numberOfAsterisk));
            }
            result.Append(temp);
        }

        public static string ToFormat(this string strToFormat, params object[] parameters)
        {
            return string.Format(strToFormat, parameters);
        }

        public static double ToDoubleAlowPoint(this string valor)
        {
            int index = valor.IndexOf('E');
            if (index > 0)
            {
                valor = valor.Substring(0, index);
            }
            return double.Parse(
                valor,
                NumberStyles.AllowDecimalPoint,
                NumberFormatInfo.InvariantInfo
            );
        }

        public static decimal ToDecimalAlowPoint(this string valor)
        {
            int index = valor.IndexOf('E');
            if (index > 0)
            {
                valor = valor.Substring(0, index);
            }
            return decimal.Parse(
                valor,
                NumberStyles.AllowDecimalPoint,
                NumberFormatInfo.InvariantInfo
            );
        }

        /// <summary>
        /// Compara duas strings ignorando o case sensitive e aplicando Trim().
        /// </summary>
        /// <param name="str">String a ser comparada</param>
        /// <param name="value">String a ser comparada</param>
        /// <returns></returns>
        public static bool EqualsIgnoreCase(this string str, string value)
        {
            bool result = false;

            if (str != null && value != null)
            {
                result = str.Trim().Equals(value.Trim(), StringComparison.InvariantCultureIgnoreCase);
            }
            else if (str == null && value == null)
            {
                result = true;
            }

            return result;
        }

        /// <summary>
        /// Remove os espaços em branco no começo e fim da string caso ela seja diferente de nula.
        /// </summary>
        /// <param name="value">Valor da string</param>
        /// <returns>Valor da string com espaços removidos</returns>
        public static string SafeTrim(this string value)
        {
            string result = value;

            if (value != null)
            {
                result = value.Trim();
            }

            return result;
        }


        /// <summary>
        /// Retorna a substring de uma string trazendo vazio caso ultrapasse o tamanho da string
        /// </summary>
        /// <param name="value">Valor onde será realizado o substring</param>
        /// <param name="startIndex">posição</param>
        /// <param name="length">tamanho</param>
        /// <returns>Retorna a substring da string</returns>
        public static string SafeSubstring(this string value, int startIndex, int length)
        {
            string result = string.Empty;

            if (value != null)
            {
                if (value.Length >= startIndex + length)
                {
                    result = value.Substring(startIndex, length);
                }
                else if (value.Length > startIndex)
                {
                    result = value.Substring(startIndex);
                }
            }

            return result;
        }

        /// <summary>
        /// Converte uma string para boleano, considerando o seguinte padrão: "S" = true, "N" = false
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static bool? ConvertToBool(this string value)
        {
            bool? retorno = null;

            if (!string.IsNullOrEmpty(value))
            {
                if (value.Trim() == "S")
                {
                    retorno = true;
                }
                else if (value.Trim() == "N")
                {
                    retorno = false;
                }
            }

            return retorno;
        }

        /// <summary>
        /// Converte uma string para inteiro (Int32)
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static int ToInt32(this string value)
        {
            return Convert.ToInt32(value);
        }


        /// <summary>
        /// Retorna somente os números de uma string.
        /// </summary>
        /// <param name="value">Valor da string</param>
        /// <returns>Valor da string só com números</returns>
        public static string OnlyNumbers(this string value)
        {
            string result = value;

            if (value != null)
                result = Regex.Replace(result, @"\D", "");

            return result;
        }

        /// <summary>
        /// Retorna somente letras e espaços em branco de uma string.
        /// </summary>
        /// <param name="text"></param>
        /// <returns></returns>
        public static string OnlyLetters(this string text)
        {
            return new string(text.Where(c => char.IsLetter(c) || char.IsWhiteSpace(c)).ToArray());
        }

        /// <summary>
        /// Remove acentos de uma string.
        /// </summary>
        /// <param name="text"></param>
        /// <returns>string sem acentos</returns>
        public static string RemoveAccents(this string text)
        {
            StringBuilder sbReturn = new StringBuilder();
            var arrayText = text.Normalize(NormalizationForm.FormD).ToCharArray();
            foreach (char letter in arrayText)
            {
                if (CharUnicodeInfo.GetUnicodeCategory(letter) != UnicodeCategory.NonSpacingMark)
                    sbReturn.Append(letter);
            }
            return sbReturn.ToString();
        }

        /// <summary>
        /// Remove caracteres especiais inclusive letras com acentos.
        /// </summary>
        /// <param name="text"></param>
        /// <returns>string sem caracteres especiais</returns>
        public static string RemoveSpecialCharacter(this string text)
        {
            return Regex.Replace(text, "[^0-9a-zA-Z ]+", "");
        }

        /// <summary>
        /// Remove acentos e caracteres especiais.
        /// </summary>
        /// <param name="text"></param>
        /// <returns>string sem caracteres especiais</returns>
        public static string RemoveAccentsAndSpecialCharacter(this string text)
        {
            if (string.IsNullOrWhiteSpace(text))
            {
                return text;
            }
            return text.RemoveAccents().RemoveSpecialCharacter();
        }

        public static string CamelCased(this string pascalCased)
        {
            if (string.IsNullOrWhiteSpace(pascalCased))
            {
                return pascalCased;
            }
            return pascalCased[0].ToString().ToLowerInvariant() + pascalCased.Substring(1);
        }
        public static string PascalCased(this string camelCased)
        {
            if (string.IsNullOrWhiteSpace(camelCased))
            {
                return camelCased;
            }
            return camelCased[0].ToString().ToUpperInvariant() + camelCased.Substring(1);
        }

        public static string Encrypted(this string unencrypted)
        {
            RSA rsa = RSA.Create(2048);
            rsa.FromXmlString(GenAISettings.CriptoPublicKey);
            byte[] dataToEncrypt = Encoding.UTF8.GetBytes(unencrypted);
            byte[] encryptedData = rsa.Encrypt(dataToEncrypt, RSAEncryptionPadding.OaepSHA256);
            rsa.Dispose();
            return Convert.ToBase64String(encryptedData);
        }

        public static string EncryptedFromLargeString(this string unencrypted)
        {
            // Generate a new AES key
            using (Aes aes = Aes.Create())
            {
                aes.KeySize = 256;
                aes.GenerateKey();
                aes.GenerateIV();

                // Encrypt the data with AES
                byte[] dataToEncrypt = Encoding.UTF8.GetBytes(unencrypted);
                byte[] encryptedData;
                using (ICryptoTransform encryptor = aes.CreateEncryptor(aes.Key, aes.IV))
                {
                    encryptedData = encryptor.TransformFinalBlock(dataToEncrypt, 0, dataToEncrypt.Length);
                }

                // Encrypt the AES key with RSA
                using (RSA rsa = RSA.Create())
                {
                    rsa.FromXmlString(GenAISettings.CriptoPublicKey);
                    byte[] encryptedAesKey = rsa.Encrypt(aes.Key, RSAEncryptionPadding.OaepSHA256);

                    // Combine the encrypted AES key, IV, and encrypted data
                    byte[] combinedData = new byte[encryptedAesKey.Length + aes.IV.Length + encryptedData.Length];
                    Buffer.BlockCopy(encryptedAesKey, 0, combinedData, 0, encryptedAesKey.Length);
                    Buffer.BlockCopy(aes.IV, 0, combinedData, encryptedAesKey.Length, aes.IV.Length);
                    Buffer.BlockCopy(encryptedData, 0, combinedData, encryptedAesKey.Length + aes.IV.Length, encryptedData.Length);

                    // Return the combined data as a base64 string
                    return Convert.ToBase64String(combinedData);
                }
            }
        }

        public static string Decrypted(this string encrypted)
        {
            RSA rsa = RSA.Create();
            rsa.FromXml(GenAISettings.CriptoPrivateKey);

            byte[] dataToDecrypt = Convert.FromBase64String(encrypted);
            byte[] decryptedData = rsa.Decrypt(dataToDecrypt, RSAEncryptionPadding.OaepSHA256);
            rsa.Dispose();
            return Encoding.UTF8.GetString(decryptedData);
        }

        public static string DecryptedFromLargeString(string encrypted)
        {
            byte[] combinedData = Convert.FromBase64String(encrypted);

            using (RSA rsa = RSA.Create())
            {
                rsa.FromXmlString(GenAISettings.CriptoPrivateKey);

                // Extract the encrypted AES key length
                int keySize = rsa.KeySize / 8;
                byte[] encryptedAesKey = new byte[keySize];
                Buffer.BlockCopy(combinedData, 0, encryptedAesKey, 0, keySize);

                // Decrypt the AES key
                byte[] aesKey = rsa.Decrypt(encryptedAesKey, RSAEncryptionPadding.OaepSHA256);

                // Extract the IV
                byte[] iv = new byte[16];
                Buffer.BlockCopy(combinedData, keySize, iv, 0, iv.Length);

                // Extract the encrypted data
                int encryptedDataLength = combinedData.Length - keySize - iv.Length;
                byte[] encryptedData = new byte[encryptedDataLength];
                Buffer.BlockCopy(combinedData, keySize + iv.Length, encryptedData, 0, encryptedDataLength);

                // Decrypt the data with AES
                using (Aes aes = Aes.Create())
                {
                    aes.Key = aesKey;
                    aes.IV = iv;
                    using (ICryptoTransform decryptor = aes.CreateDecryptor(aes.Key, aes.IV))
                    {
                        byte[] decryptedData = decryptor.TransformFinalBlock(encryptedData, 0, encryptedData.Length);
                        return Encoding.UTF8.GetString(decryptedData);
                    }
                }
            }
        }

        public static T FromJson<T>(this string jsonString,
            JsonSerializerSettings serializerSettings = null)
        {
            return JsonConvert.DeserializeObject<T>(jsonString, serializerSettings);
        }

        public static bool IsBase64(this string s)
        {
            if (string.IsNullOrWhiteSpace(s))
            {
                return false;
            }

            s = s.Trim();
            return (s.Length % 4 == 0) && Regex.IsMatch(s, @"^[a-zA-Z0-9\+/]*={0,3}$", RegexOptions.None);

        }

        public static string HashSha256(this string message, string key)
        {
            Encoding encoding = Encoding.UTF8;
            var keyByte = encoding.GetBytes(key);
            using (var hmacsha256 = new HMACSHA256(keyByte))
            {
                hmacsha256.ComputeHash(encoding.GetBytes(message));

                return ByteToString(hmacsha256.Hash).ToLower();
            }
        }

        static string ByteToString(byte[] buff)
        {
            StringBuilder sbinary = new StringBuilder();
            foreach (byte t in buff)
            {
                sbinary.Append(t.ToString("X2"));
            }
            return sbinary.ToString();
        }

        public static string FirstName(this string name)
        {
            string result = name.SafeTrim();

            if (!string.IsNullOrEmpty(result))
            {
                var nomes = result.Split(' ');
                result = nomes.FirstOrDefault();
            }

            return result;
        }

        public static DateTime? ConvertToDateOrNull(this string toConvert, string dateFormat)
        {
            DateTime dataConvertida;
            if (DateTime.TryParseExact(toConvert, dateFormat, CultureInfo.InvariantCulture, DateTimeStyles.None, out dataConvertida))
            {
                return dataConvertida;
            }

            return null;
        }

        public static string RemoveQueryStringByKey(this string url, string key)
        {
            return Regex.Replace(url, $@"(&{key}=[^&\s]+|{key}=[^&\s]+&?)", "", RegexOptions.IgnoreCase);
        }

        public static string TruncateWordsWithPostfix(this string input, int length, string postFix = null)
        {
            if (input == null || input.Length < length)
                return input;
            int iNextSpace = input.LastIndexOf(" ", length, StringComparison.Ordinal);

            string text = input.Substring(0, (iNextSpace > 0) ? iNextSpace : length).Trim();

            if (string.IsNullOrWhiteSpace(postFix))
            {
                if (text.EndsWith("."))
                {
                    return text + "..";
                }
                return text + "...";
            }
            return text + postFix;
        }

        public static string ToCurrence(decimal? strValue)
        {
            if (strValue.HasValue)
                return strValue.Value.ToString("0.00;(0.00)");
            else
                return strValue.Value.ToString("0.00");
        }

        public static string FormatCNPJ(string CNPJ)
        {
            return Convert.ToUInt64(CNPJ).ToString(@"00\.000\.000\/0000\-00");
        }

        public static string FormatCPF(string CPF)
        {
            return Convert.ToUInt64(CPF).ToString(@"000\.000\.000\-00");
        }

        public static string InsertFormatCPForCNPJ(string Number)
        {
            if (ValidacaoUtil.IsCnpjValido(Number))
                return Convert.ToUInt64(Number).ToString(@"00\.000\.000\/0000\-00");
            else if (ValidacaoUtil.IsCpfValido(Number))
                return Convert.ToUInt64(Number).ToString(@"000\.000\.000\-00");
            else
                return Number;
        }

        public static string ConvertDateFormat(string format, string date)
        {
            int Year = Convert.ToInt32(date.Split('/')[2]);
            int Month = Convert.ToInt32(date.Split('/')[1]);
            int Day = Convert.ToInt32(date.Split('/')[0]);
            DateTime dt = new DateTime(Year, Month, Day);

            return dt.ToString("MM-dd-yyyy");
        }
    }
}


