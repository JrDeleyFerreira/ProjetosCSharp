﻿using Abp.Web;
using GenAI.Crosscutting.Infra.Extensions;
using Microsoft.AspNetCore.Mvc;
using System.Net.Http;
using System.Reflection;
using System.Text.RegularExpressions;

namespace GenAI.Crosscutting.Infra.WebApi
{
    public static class WebApiHttpVerbResolver
    {
        private static readonly Regex GetRegex = new Regex("^Consultar.*|^Obter.*|^Exist.*|^Buscar.*|^Verificar.*|^Is.*|^Find.*|^Get.*", RegexOptions.IgnoreCase | RegexOptions.Compiled | RegexOptions.CultureInvariant);
        private static readonly Regex PostRegex = new Regex("^Criar.*|^Salvar.*|^Enviar.*|^Valida.*|^Send.*|^Create.*|^Save.*", RegexOptions.IgnoreCase | RegexOptions.Compiled | RegexOptions.CultureInvariant);
        private static readonly Regex PutRegex = new Regex("^Atualizar.*|^Alterar.*|^Update.*", RegexOptions.IgnoreCase | RegexOptions.Compiled | RegexOptions.CultureInvariant);
        private static readonly Regex DeleteRegex = new Regex("^Exclu(ir|de).*|^Remover?.*|^Delet(e|ar).*", RegexOptions.IgnoreCase | RegexOptions.Compiled | RegexOptions.CultureInvariant);

        public static HttpMethod GetHttpMethodWithClinAppsConventions(MethodInfo method)
        {
            return GetHttpVerbWithClinAppsConventions(method).ToHttpMethod();
        }

        public static HttpVerb GetHttpVerbWithClinAppsConventions(MethodInfo method)
        {
            HttpVerb? definedVerb = GetNormalizedVerbOrDefault(method);

            if (definedVerb.HasValue)
            {
                return definedVerb.Value;
            }

            string methodName = method.Name;
            if (GetRegex.IsMatch(methodName))
            {
                return HttpVerb.Get;
            }

            if (PostRegex.IsMatch(methodName))
            {
                return HttpVerb.Post;
            }

            if (PutRegex.IsMatch(methodName))
            {
                return HttpVerb.Put;
            }

            if (DeleteRegex.IsMatch(methodName))
            {
                return HttpVerb.Delete;
            }
            return GetDefaultHttpVerb();
        }

        private static HttpVerb? GetNormalizedVerbOrDefault(MethodInfo method)
        {
            if (method.IsDefined(typeof(HttpGetAttribute)))
            {
                return HttpVerb.Get;
            }

            if (method.IsDefined(typeof(HttpPostAttribute)))
            {
                return HttpVerb.Post;
            }

            if (method.IsDefined(typeof(HttpPutAttribute)))
            {
                return HttpVerb.Put;
            }

            if (method.IsDefined(typeof(HttpDeleteAttribute)))
            {
                return HttpVerb.Delete;
            }

            if (method.IsDefined(typeof(HttpOptionsAttribute)))
            {
                return HttpVerb.Options;
            }

            if (method.IsDefined(typeof(HttpHeadAttribute)))
            {
                return HttpVerb.Head;
            }

            return null;
        }

        public static HttpVerb GetDefaultHttpVerb()
        {
            return HttpVerb.Post;
        }
    }


}

