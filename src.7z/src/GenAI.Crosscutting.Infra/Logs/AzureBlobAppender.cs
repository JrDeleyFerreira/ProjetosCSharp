﻿using log4net.Appender;
using log4net.Core;
using Microsoft.WindowsAzure.Storage.Blob;
using Microsoft.WindowsAzure.Storage.RetryPolicies;
using Microsoft.WindowsAzure.Storage;
using System.IO;
using System.Net;
using System.Text;
using System;
using System.Threading.Tasks;
using GenAI.Crosscutting.Infra.Extensions;
using GenAI.Crosscutting.Infra.Settings;
using Azure.Storage.Blobs.Specialized;
using SendGrid.Helpers.Mail;
using System.Linq;

namespace GenAI.Crosscutting.Infra.Logs;

public class AzureBlobAppender : BufferingAppenderSkeleton
{
    private CloudStorageAccount account;
    private CloudBlobClient client;
    private CloudBlobContainer container;

    public string ContainerName { get; set; }
    public string DirectoryName { get; set; }
    public string FileName { get; set; }

    public override void ActivateOptions()
    {
        base.ActivateOptions();

        string connectionString = GenAISettings.StorageAccountConnectionString;
        FileName = $"log_{DateTime.Now:yyyyMMdd}.log";

        if (!CloudStorageAccount.TryParse(connectionString, out account))
        {
            throw new ArgumentException("Missing or malformed connection string.", nameof(connectionString));
        }

        client = account.CreateCloudBlobClient();
        container = client.GetContainerReference(ContainerName.ToLower());
        container.CreateIfNotExistsAsync().GetAwaiter();
    }

    protected override void SendBuffer(LoggingEvent[] events)
    {
        SendBufferAsync(events).GetAwaiter().GetResult();
    }
    private async Task SendBufferAsync(LoggingEvent[] events)
    {
        await Task.WhenAll(events.Select(ProcessEventAsync));
    }
    private async Task ProcessEventAsync(LoggingEvent loggingEvent)
    {
        try
        {
            CloudAppendBlob blob = container.GetAppendBlobReference(Path.Combine(DirectoryName, FileName));
            try
            {
                await blob.CreateOrReplaceAsync(
                    AccessCondition.GenerateIfNotExistsCondition(),
                    new BlobRequestOptions() { RetryPolicy = new LinearRetry(TimeSpan.FromSeconds(1), 10) },
                    null);
            }
            catch (StorageException ex) when (ex.RequestInformation?.HttpStatusCode == (int)HttpStatusCode.Conflict)
            { }

            string message = loggingEvent.GetFormattedString(Layout);
            using MemoryStream ms = new(Encoding.UTF8.GetBytes(message));
            await blob.AppendBlockAsync(ms);
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex);
            throw;
        }
    }
}