﻿using System;
using System.Threading;
using System.Threading.Tasks;
using Abp.Dependency;
using GenAI.Crosscutting.Infra.Integrations;

namespace GenAI.Crosscutting.Infra.Services;

public interface IKafkaProducerService : ISingletonDependency
{
    Task PublishMessageAsync(string message, string topic);
    Task ConsumerMessageAsync<T>(string topic, Func<T, Task> onMessage, CancellationToken cancelationToken) where T : IntegrationEvent;
}
