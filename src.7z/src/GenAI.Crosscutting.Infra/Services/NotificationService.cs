﻿using GenAI.Crosscutting.Infra.Hubs;
using Microsoft.AspNetCore.SignalR;
using System.Threading.Tasks;

namespace GenAI.Crosscutting.Infra.Services;

public class NotificationService : INotificationService
{
    private IHubContext<GenAIHub> _HubContext;

    public NotificationService(IHubContext<GenAIHub> hubContext)
    {
        _HubContext = hubContext;
    }
    public async Task Notify(string method, string message, string connectionId)
    {
        await _HubContext.Clients.Client(connectionId).SendAsync(method, message);
    }
}