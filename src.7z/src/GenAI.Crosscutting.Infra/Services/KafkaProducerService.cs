﻿using Abp.Dependency;
using Confluent.Kafka;
using GenAI.Crosscutting.Infra.Settings;
using System;
using System.Threading;
using System.Threading.Tasks;
using GenAI.Crosscutting.Infra.Integrations;
using GenAI.Crosscutting.Infra.Logs;

namespace GenAI.Crosscutting.Infra.Services;

public class KafkaProducerService : IKafkaProducerService
{
    public KafkaProducerService()
    {
    }

    public async Task PublishMessageAsync(string message, string topic)
    {
        var kafkaprotocol = GenAISettings.KafkaSaslProtocol;

        ProducerConfig config = new()
        {
            BootstrapServers = GenAISettings.KafkaBoostrapServers,
            SaslUsername = GenAISettings.KafkaSaslUsername,
            SaslPassword = GenAISettings.KafkaSaslPassword,
            SecurityProtocol = kafkaprotocol == "SASLPLAINTEXT" ? SecurityProtocol.SaslPlaintext : SecurityProtocol.SaslSsl,
            SaslMechanism = SaslMechanism.Plain,
            ClientId = GenAISettings.KafkaProducerGroupId
        };

        using IProducer<string, string> producer = new ProducerBuilder<string, string>(config).Build();
        try
        {
            DeliveryResult<string, string> messageResult = await producer.ProduceAsync(topic, new Message<string, string>
            {
                Value = message,
                Key = Guid.NewGuid().ToString()
            });

            //await _log.LogDebugAsync($"Mensagem publicada no tópico: {messageResult.Topic}, Partição: {messageResult.Partition}, Offset: {messageResult.Offset}");
        }
        catch (ProduceException<Null, string> e)
        {
            //await _log.LogErrorAsync($"Erro ao publicar a mensagem: {e.Error.Reason}");
        }
    }

    public async Task ConsumerMessageAsync<T>(string topic, Func<T, Task> onMessage, CancellationToken cancelationToken) where T : IntegrationEvent
    {
        _ = Task.Factory.StartNew(async () =>
        {
            try
            {
                var kafkaprotocol = GenAISettings.KafkaSaslProtocol;

                ConsumerConfig config = new()
                {
                    BootstrapServers = GenAISettings.KafkaBoostrapServers,
                    SaslUsername = GenAISettings.KafkaSaslUsername,
                    SaslPassword = GenAISettings.KafkaSaslPassword,
                    SecurityProtocol = kafkaprotocol == "SASLPLAINTEXT" ? SecurityProtocol.SaslPlaintext : SecurityProtocol.SaslSsl,
                    SaslMechanism = SaslMechanism.Plain,
                    GroupId = GenAISettings.KafkaConsumerGroupId,
                    EnableAutoCommit = false
                };

                using IConsumer<string, string> consumer = new ConsumerBuilder<string, string>(config).Build();
                consumer.Subscribe(topic);
                DateTime startTime = DateTime.Now;
                while (DateTime.Now < startTime.AddMinutes(1) || !cancelationToken.IsCancellationRequested)
                {
                    ConsumeResult<string, string> result = consumer.Consume(1000);

                    if (result == null) continue;

                    string resultReplace = result.Message.Value.Replace("'", "\"");
                    //await _log.LogDebugAsync($"Mensagem Recebida: {resultReplace}");
                    T message = System.Text.Json.JsonSerializer.Deserialize<T>(resultReplace);

                    await onMessage(message);

                    consumer.Commit();
                    //await _log.LogDebugAsync($"Mensagem Commitada");
                }
            }
            catch (Exception e)
            {
                throw;
            }

        }, cancelationToken, TaskCreationOptions.LongRunning, TaskScheduler.Default);

        await Task.CompletedTask;
    }
}
