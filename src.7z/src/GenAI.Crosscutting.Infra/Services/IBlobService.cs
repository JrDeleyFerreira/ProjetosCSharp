﻿using Microsoft.AspNetCore.Http;
using System;
using System.Threading.Tasks;

namespace GenAI.Crosscutting.Infra.Services
{
    public interface IBlobService
    {
        Task UploadFileToBlobAsync(IFormFile file, string filePath);
        Task UploadFileToBlobAsync(IFormFile file, string filePath, string containerName);
        Task DeleteFileBlobAsync(string filePath);
        string GetUriSas(string filePath);
        Task<Tuple<string,string>> GetFileBase64(string fileUri);
        Task CreateContainerIfNotExistsAsync(string containerName);
	}
}