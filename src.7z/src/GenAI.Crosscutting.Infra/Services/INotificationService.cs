﻿using System.Threading.Tasks;
using Abp.Dependency;

namespace GenAI.Crosscutting.Infra.Services;

public interface INotificationService : ISingletonDependency
{
    Task Notify(string method, string message, string connectionId);
}