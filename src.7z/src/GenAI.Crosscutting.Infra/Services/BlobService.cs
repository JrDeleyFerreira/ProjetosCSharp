﻿using System.IO;
using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using GenAI.Crosscutting.Infra.Settings;
using Microsoft.AspNetCore.Http;
using System.Threading.Tasks;
using System;
using Azure.Storage.Sas;
using Azure.Storage.Blobs.Specialized;
using System.Linq;
using System.Text;

namespace GenAI.Crosscutting.Infra.Services;

public class BlobService : IBlobService
{
    private readonly BlobServiceClient _BlobServiceClient;

    public BlobService()
    {
        _BlobServiceClient = new BlobServiceClient(GenAISettings.StorageAccountConnectionString);
    }

    public async Task UploadFileToBlobAsync(IFormFile file, string filePath)
    {
        BlobContainerClient containerClient = _BlobServiceClient.GetBlobContainerClient(GenAISettings.ContainerNameStorage);
        await UploadFile(file, filePath, containerClient);
    }

    public async Task UploadFileToBlobAsync(IFormFile file, string filePath, string containerName)
    {
        BlobContainerClient containerClient = _BlobServiceClient.GetBlobContainerClient(containerName);
        await UploadFile(file, filePath, containerClient);
    }

    public async Task DeleteFileBlobAsync(string filePath)
    {
        BlobContainerClient containerClient = _BlobServiceClient.GetBlobContainerClient(GenAISettings.ContainerNameStorage);
        BlobClient blobClient = containerClient.GetBlobClient(filePath);
        if (await blobClient.ExistsAsync())
            await blobClient.DeleteAsync();
    }

    public string GetUriSas(string filePath)
    {
        BlobContainerClient containerClient = _BlobServiceClient.GetBlobContainerClient(GenAISettings.ContainerNameStorage);
        BlobClient blobClient = containerClient.GetBlobClient(filePath);

        BlobSasBuilder sasBuilder = new()
        {
            BlobContainerName = blobClient.GetParentBlobContainerClient().Name,
            BlobName = blobClient.Name,
            Resource = "b",
            StartsOn = DateTimeOffset.UtcNow,
            ExpiresOn = DateTimeOffset.UtcNow.AddHours(1),
            Protocol = SasProtocol.Https
        };

        sasBuilder.SetPermissions(BlobSasPermissions.Read);

        Uri sasURI = blobClient.GenerateSasUri(sasBuilder);
        return sasURI.ToString();
    }

    private static async Task UploadFile(IFormFile file, string filePath, BlobContainerClient containerClient)
    {
        await containerClient.CreateIfNotExistsAsync();

        BlobClient blobClient = containerClient.GetBlobClient(filePath);
        Stream uploadFileStream = file.OpenReadStream();
        BlobHttpHeaders blobHttpHeader = new() { ContentType = file.ContentType };

        await blobClient.UploadAsync(uploadFileStream, new BlobUploadOptions { HttpHeaders = blobHttpHeader });
    }

    public async Task<Tuple<string, string>> GetFileBase64(string fileUri)
    {
        var blobUri = new Uri(fileUri);
        string blobContainerName = blobUri.Segments[1]; // Assume-se que o nome do container está no segundo segmento do URI
        StringBuilder blobName = new();
        foreach (var item in blobUri.Segments.Skip(2))
        {
            blobName.Append(item);
        }

        // Obter referência ao container e blob
        var blobContainerClient = _BlobServiceClient.GetBlobContainerClient(blobContainerName);
        var blobClient = blobContainerClient.GetBlobClient(blobName.ToString());

        // Baixar o conteúdo do blob como um fluxo de bytes
        using MemoryStream memoryStream = new();
        await blobClient.DownloadToAsync(memoryStream);

        // Converter o fluxo de bytes para uma string Base64
        byte[] byteArray = memoryStream.ToArray();
        // Obter o formato do arquivo
        string fileFormat = Path.GetExtension(blobName.ToString()).TrimStart('.'); // Remove o ponto do início da extensão

        return new Tuple<string, string>(fileFormat, Convert.ToBase64String(byteArray));
    }

	public async Task CreateContainerIfNotExistsAsync(string containerName)
    {
        var blobServiceClient = _BlobServiceClient.GetBlobContainerClient(containerName);
        await blobServiceClient.CreateIfNotExistsAsync();
	}

}