﻿using System.Threading.Tasks;

namespace GenAI.Crosscutting.Infra.Services
{
    public interface IServiceBusService
    {
        Task<bool> SendMessage<T>(string queueName, T obj) where T : class;
    }
}
