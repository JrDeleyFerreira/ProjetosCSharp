﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Globalization;

namespace GenAI.Crosscutting.Infra.Validators
{
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field | AttributeTargets.Parameter)]
    public class DateTimeAttribute : RangeAttribute
    {
        //https://msdn.microsoft.com/en-us/library/ms187819.aspx
        private static readonly DateTime MinValidDate = new DateTime(1753, 1, 1);

        private static readonly DateTime MaxValidDate = new DateTime(9999, 12, 1, 23, 59, 59);

        public DateTimeAttribute() : base(typeof(DateTime),
            MinValidDate.ToString(CultureInfo.InvariantCulture),
            MaxValidDate.ToString(CultureInfo.InvariantCulture))
        {
        }

    }
}


