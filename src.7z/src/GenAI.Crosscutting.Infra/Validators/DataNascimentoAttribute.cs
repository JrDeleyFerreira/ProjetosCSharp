﻿using System;
using System.ComponentModel.DataAnnotations;

namespace GenAI.Crosscutting.Infra.Validators
{
    [AttributeUsage(AttributeTargets.Property)]
    public class DataNascimentoAttribute : ValidationAttribute
    {
        public override bool IsValid(object value)
        {
            if (value == null)
            {
                return true;
            }

            DateTime? dateTime = value as DateTime?;

            return dateTime.HasValue && dateTime.Value.Date <= DateTime.Now.Date;
        }
    }
}


