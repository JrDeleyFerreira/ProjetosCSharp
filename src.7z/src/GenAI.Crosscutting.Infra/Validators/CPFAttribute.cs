﻿using GenAI.Crosscutting.Infra.Util;
using System;
using System.ComponentModel.DataAnnotations;

namespace GenAI.Crosscutting.Infra.Validators
{
    [AttributeUsage(AttributeTargets.Property)]
    public class CPFAttribute : ValidationAttribute
    {
        public override bool IsValid(object value)
        {
            string cpf = value as string;

            if (string.IsNullOrEmpty(cpf))
            {
                return true;
            }

            return ValidacaoUtil.IsCpfValido(cpf);
        }
    }
}


