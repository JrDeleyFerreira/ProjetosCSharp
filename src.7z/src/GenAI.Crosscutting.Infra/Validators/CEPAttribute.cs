﻿using GenAI.Crosscutting.Infra.Util;
using System;
using System.ComponentModel.DataAnnotations;

namespace GenAI.Crosscutting.Infra.Validators
{
    [AttributeUsage(AttributeTargets.Property)]
    public class CEPAttribute : ValidationAttribute
    {
        public override bool IsValid(object value)
        {
            string cep = value as string;

            if (string.IsNullOrEmpty(cep))
            {
                return true;
            }

            return ValidacaoUtil.IsCepValido(cep);
        }
    }
}


