﻿using GenAI.Crosscutting.Infra.Util;
using System;

namespace GenAI.Crosscutting.Infra.Validators
{
    [AttributeUsage(AttributeTargets.Property)]
    public class MaiorIdadeAttribute : DataNascimentoAttribute
    {
        public override bool IsValid(object value)
        {
            if (value == null)
            {
                return true;
            }

            bool isValid = base.IsValid(value);

            if (isValid)
            {
                DateTime? dateTime = value as DateTime?;

                return dateTime.HasValue && ValidacaoUtil.IsMaiorIdade(dateTime.Value);
            }

            return false;
        }
    }
}


