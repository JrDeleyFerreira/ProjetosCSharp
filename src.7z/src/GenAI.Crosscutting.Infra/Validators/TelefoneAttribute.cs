﻿using GenAI.Crosscutting.Infra.Util;
using System;
using System.ComponentModel.DataAnnotations;

namespace GenAI.Crosscutting.Infra.Validators
{
    [AttributeUsage(AttributeTargets.Property)]
    public class TelefoneAttribute : ValidationAttribute
    {
        public override bool IsValid(object value)
        {
            string telefone = value as string;

            if (string.IsNullOrEmpty(telefone))
            {
                return true;
            }

            return ValidacaoUtil.IsTelefoneValido(telefone);
        }
    }
}


