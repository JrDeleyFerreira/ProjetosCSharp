﻿using GenAI.Crosscutting.Infra.Util;
using System;
using System.ComponentModel.DataAnnotations;

namespace GenAI.Crosscutting.Infra.Validators
{
    [AttributeUsage(AttributeTargets.Property)]
    public class HoraAttribute : ValidationAttribute
    {
        public override bool IsValid(object value)
        {
            string hora = value as string;

            return ValidacaoUtil.IsHoraValida(hora);
        }
    }
}


