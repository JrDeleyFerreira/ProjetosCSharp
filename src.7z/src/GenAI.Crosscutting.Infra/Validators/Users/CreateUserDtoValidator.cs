﻿using FluentValidation;
using GenAI.Crosscutting.Entities.Dto.Users;
using GenAI.Crosscutting.Infra.Resources;

namespace GenAI.Crosscutting.Infra.Validators.Users
{
    public class CreateUserDtoValidator : AbstractValidator<CreateUserDto>
    {
        public CreateUserDtoValidator()
        {
            RuleFor(x => x.Name).NotEmpty().WithMessage(l => Messages.USER_NAME_REQUIRED);
            RuleFor(x => x.EmailAddress).NotEmpty().WithMessage(l => Messages.USER_EMAIL_REQUIRED);
            RuleFor(x => x.EmailAddress).EmailAddress().WithMessage(l => Messages.INVALID_EMAIL);
            RuleFor(x => x.RoleNames).Must(n => n.Length > 0).WithMessage(l => Messages.USER_ROLE_REQUIRED);
        }
    }
}
