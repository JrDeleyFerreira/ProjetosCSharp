﻿using FluentValidation;
using GenAI.Crosscutting.Entities.Dto.Users;
using GenAI.Crosscutting.Infra.Resources;

namespace GenAI.Crosscutting.Infra.Validators.Users
{
    public class ChangePasswordDtoValidator : AbstractValidator<ChangePasswordDto>
    {
        public ChangePasswordDtoValidator()
        {
            const string passwordRegex = "(?=^.{8,}$)(?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?!.*\\s)[0-9a-zA-Z!@#$%^&*()]*$";

            RuleFor(x => x.CurrentPassword).NotEmpty().WithMessage(l => Messages.CURRENT_PASSWORD_REQUIRED);
            RuleFor(x => x.NewPassword).NotEmpty().WithMessage(l => Messages.NEW_PASSWORD_REQUIRED);
            RuleFor(x => x.ConfimPassword).NotEmpty().WithMessage(l => Messages.CONFIRM_PASSWORD_REQUIRED);
            RuleFor(x => x.NewPassword).Matches(passwordRegex).WithMessage(l => Messages.PASSWORD_REGEX);
            RuleFor(x => x.NewPassword).Equal(x => x.ConfimPassword).When(x => !string.IsNullOrEmpty(x.NewPassword)).WithMessage(l => Messages.NEW_PASS_DOES_NOT_MATCH_CONFIRM);
        }
    }
}
