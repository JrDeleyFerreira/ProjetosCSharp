﻿using GenAI.Crosscutting.Infra.Util;
using System;
using System.ComponentModel.DataAnnotations;

namespace GenAI.Crosscutting.Infra.Validators
{
    [AttributeUsage(AttributeTargets.Property)]
    public class CPFCNPJAttribute : ValidationAttribute
    {
        public override bool IsValid(object value)
        {
            string cpfCnpj = value as string;

            if (string.IsNullOrEmpty(cpfCnpj))
            {
                return true;
            }

            return ValidacaoUtil.IsCpfValido(cpfCnpj) || ValidacaoUtil.IsCnpjValido(cpfCnpj);
        }
    }
}


