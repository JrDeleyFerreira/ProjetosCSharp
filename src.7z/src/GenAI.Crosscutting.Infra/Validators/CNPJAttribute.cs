﻿using GenAI.Crosscutting.Infra.Util;
using System;
using System.ComponentModel.DataAnnotations;

namespace GenAI.Crosscutting.Infra.Validators
{
    [AttributeUsage(AttributeTargets.Property)]
    public class CNPJAttribute : ValidationAttribute
    {
        public override bool IsValid(object value)
        {
            string cnpj = value as string;

            if (string.IsNullOrEmpty(cnpj))
            {
                return true;
            }

            return ValidacaoUtil.IsCnpjValido(cnpj);
        }
    }
}


