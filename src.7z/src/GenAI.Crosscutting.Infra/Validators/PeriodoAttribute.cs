﻿using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace GenAI.Crosscutting.Infra.Validators
{
    [AttributeUsage(AttributeTargets.Property)]
    public class PeriodoAttribute : ValidationAttribute
    {
        public string NomePropriedadeFim { get; set; }

        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            PropertyDescriptor propriedadeFim =
                TypeDescriptor.GetProperties(validationContext.ObjectType).Find(this.NomePropriedadeFim, false);

            if (propriedadeFim == null)
            {
                throw new ArgumentNullException($" A propriedade '{this.NomePropriedadeFim}' não existe no objeto validado.");
            }

            DateTime? dataFim = propriedadeFim.GetValue(validationContext.ObjectInstance) as DateTime?;

            DateTime? dataInicio = value as DateTime?;

            ValidationResult result = ValidationResult.Success;

            bool periodoPreenchido = dataInicio.HasValue && dataFim.HasValue;

            if (periodoPreenchido && dataFim < dataInicio)
            {
                string[] memberNames = validationContext.MemberName != null ? new string[] { validationContext.MemberName, NomePropriedadeFim } : null;

                result = new ValidationResult(string.Format(this.ErrorMessageString, validationContext.DisplayName, propriedadeFim.DisplayName, dataInicio, dataFim), memberNames);
            }

            return result;
        }
    }
}


