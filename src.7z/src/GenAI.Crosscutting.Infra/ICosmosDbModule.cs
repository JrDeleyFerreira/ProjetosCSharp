﻿using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace GenAI.Crosscutting.Infra;

public interface ICosmosDbModule<T>
{
    Task<T> Get(string itemId);
    Task<T> UpsertItem(T item, string partitionKeyValue);
    Task<List<T>> GetAll();
    Task<List<T>> GetAllByQuery(string query, IList<Dictionary<string, object>> parameters = null);
    Task<T> GetSingleByQuery(string query, IList<Dictionary<string, object>> parameters = null);
    Task<List<T>> GetAllByQuery(Expression<Func<T, bool>> predicate);
}
