﻿using Abp.BackgroundJobs;

namespace GenAI.Crosscutting.Infra.Jobs
{
    public abstract class StartupBackgroundJob : BackgroundJob<int>, IStartupBackgroundJob
    {
        public abstract void Execute();

        public override void Execute(int args)
        {
            this.Execute();
        }
    }
}


