﻿namespace GenAI.Crosscutting.Infra.Jobs
{
    public interface IBackgroundJob
    {
        void Execute();
    }
}

