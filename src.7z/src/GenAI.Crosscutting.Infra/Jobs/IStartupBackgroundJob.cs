﻿namespace GenAI.Crosscutting.Infra.Jobs
{
    public interface IStartupBackgroundJob : IBackgroundJob
    {

    }
}


