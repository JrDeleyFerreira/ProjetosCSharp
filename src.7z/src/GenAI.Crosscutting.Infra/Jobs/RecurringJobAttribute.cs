﻿using System;

namespace GenAI.Crosscutting.Infra.Jobs
{
    [AttributeUsage(AttributeTargets.Class)]
    public class RecurringJobAttribute : Attribute
    {
        public string CronExpression { get; set; }
        public string KeySettings { get; set; }
        public string JobId { get; set; }
    }
}


