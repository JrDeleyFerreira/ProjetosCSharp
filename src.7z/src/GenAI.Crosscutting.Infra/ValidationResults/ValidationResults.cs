﻿using GenAI.Crosscutting.Infra.Exceptions;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;

namespace GenAI.Crosscutting.Infra.ValidationResults
{
    public class ValidationResults
    {
        #region Construtor e parâmetros

        private readonly List<ValidationResult> validationsResult;

        public ValidationResults()
        {
            validationsResult = new List<ValidationResult>();
        }

        #endregion

        #region Métodos de adição

        public void Add(string message)
        {
            if (string.IsNullOrWhiteSpace(message))
            {
                throw new ArgumentNullException(nameof(message));
            }

            validationsResult.Add(new ValidationResult(message));
        }

        public void Add(string message, params object[] parameters)
        {
            Add(string.Format(message, parameters));
        }

        public void Add(string code, string message)
        {
            if (string.IsNullOrWhiteSpace(code))
            {
                throw new ArgumentNullException(nameof(code));
            }

            if (string.IsNullOrWhiteSpace(message))
            {
                throw new ArgumentNullException(nameof(message));
            }

            Add($"[{code}] {message}");
        }

        public void Add(ValidationResult validation)
        {
            if (validation == null)
            {
                throw new ArgumentNullException(nameof(validation));
            }

            Add(validation.ErrorMessage);
        }

        public void Add(IEnumerable<ValidationResult> validations)
        {
            foreach (ValidationResult validation in validations)
            {
                Add(validation);
            }
        }

        #endregion

        #region Validações e checagens

        public bool IsValid()
        {
            return !validationsResult.Any();
        }

        public void Validate()
        {
            if (!IsValid())
            {
                throw new GenAIValidationException(validationsResult);
            }
        }

        public IList<string> Messages
        {
            get
            {
                return validationsResult.Select(v => v.ErrorMessage).ToList().AsReadOnly();
            }
        }

        #endregion
    }
}


