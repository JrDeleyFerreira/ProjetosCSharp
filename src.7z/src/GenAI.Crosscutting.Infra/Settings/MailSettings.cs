﻿using System.Collections.Generic;

namespace GenAI.Crosscutting.Infra.Settings
{
    public class MailSettings
    {
        public ICollection<ProtocolEntrySettings> Smtp { get; set; }

        public ICollection<ProtocolEntrySettings> Pop3 { get; set; }

        public ICollection<ProtocolEntrySettings> Imap { get; set; }

        public MailSettings()
        {
            Smtp = new List<ProtocolEntrySettings>();
            Pop3 = new List<ProtocolEntrySettings>();
            Imap = new List<ProtocolEntrySettings>();
        }
    }
}
