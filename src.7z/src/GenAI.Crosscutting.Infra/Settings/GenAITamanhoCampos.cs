﻿namespace GenAI.Crosscutting.Infra.Settings
{
    public static class GenAITamanhoCampos
    {
        public const int Cpf = 11;

        public const int Cnpj = 14;

        public const int Telefone = 10;

        public const int Celular = 11;

        public const int Email = 254;

        public const int Cep = 8;

        public const int Sexo = 1;

        public const int Nome60 = 60;

        public const int Nome80 = 80;

        public const int CartaoCreditoNumero = 19;

        public const int CartaoCreditoCodigoSeguranca = 3;

        public const int LogradouroMaxLegth = 100;

        public const int ComplementoMaxLegth = 100;

        public const int Hora = 5;
    }
}


