﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenAI.Crosscutting.Infra.Settings
{
    public class ProtocolEntrySettings
    {
        public string Key { get; set; }

        public ProtocolSettings Settings { get; set; }
    }
}
