﻿namespace GenAI.Crosscutting.Infra.Settings
{
    public static class GenAIRoles
    {
        public const string Admin = nameof(Admin);
    }
}

