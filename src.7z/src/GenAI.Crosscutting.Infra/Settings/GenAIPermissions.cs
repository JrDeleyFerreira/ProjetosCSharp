﻿using System.Diagnostics.CodeAnalysis;

namespace GenAI.Crosscutting.Infra.Settings
{
    [SuppressMessage("ReSharper", "InconsistentNaming")]
    public static class GenAIPermissions
    {
        public const string PageUser = "Pages.Users";
        public const string PageRoles = "Pages.Roles";
        public const string PageTenants = "Pages.Tenants";
        public const string Analysts = "Analysts";
        public const string PageForecast = "Page.Forecast";
        public const string PageAdmin = "Page.Admin";
    }
}

