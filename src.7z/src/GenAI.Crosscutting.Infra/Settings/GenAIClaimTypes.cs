﻿namespace GenAI.Crosscutting.Infra.Settings
{
    public static class GenAIClaimTypes
    {
        public const string SampleClaimType = "https://www.avanade.com/identity/claims/sample";

    }
}


