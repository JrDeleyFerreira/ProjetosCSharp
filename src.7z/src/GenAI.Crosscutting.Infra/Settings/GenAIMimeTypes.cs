﻿namespace GenAI.Crosscutting.Infra.Settings
{
    public static class GenAIMimeTypes
    {
        public const string Pdf = "application/pdf";
        public const string Csv = "text/csv";
    }
}


