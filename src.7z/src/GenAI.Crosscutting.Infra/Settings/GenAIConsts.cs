﻿namespace GenAI.Crosscutting.Infra.Settings
{
    public static class GenAIConsts
    {
        public const string LocalizationLabelsSourceName = "Labels";
        public const string LocalizationMessagesSourceName = "Messages";
        public const string LocalizationTextsSourceName = "Texts";

        public const string ConnectionStringName = "Default";

        public const bool MultiTenancyEnabled = true;

        public const string NamespaceBaseName = "GenAI";

        public const string Mme = "Forecast:Mme";

        public const string ClientCache = nameof(ClientCache);
        public const string AllocationTypeCache = nameof(AllocationTypeCache);
        public const string ChargeTypeCache = nameof(ChargeTypeCache);
        public const string OgCache = nameof(OgCache);
        public const string CompanyCache = nameof(CompanyCache);
        public const string GainTypeCache = nameof(GainTypeCache);

        public const string StatusCache = nameof(StatusCache);
        public const string TenantCache = nameof(TenantCache);
        public const string TowerCache = nameof(TowerCache);

        public const string ChatDatabaseName = "GenAICrossDBDev";
        public const string WorkflowDatabaseName = "GenAICrossDB";

        public const string ChatContainerName = "Chats";
        public const string WorkflowTriggerContainerName = "WorkflowTrigger";
        public const string WorkflowExecutionContainerName = "WorkflowExecution";
        public const string WorkflowStepExecutionContainerName = "WorkflowStepExecution";
    }
}

