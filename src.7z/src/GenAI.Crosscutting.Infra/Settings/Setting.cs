﻿using Microsoft.Extensions.Configuration;

namespace GenAI.Crosscutting.Infra.Settings
{
    public class Setting<T>
    {
        private IConfiguration _Configurations;
        public Setting()
        {
        }
        public Setting(string configKey)
        {
            ConfigKey = configKey;
        }
        public Setting(string configKey, IConfiguration configurations)
        {
            ConfigKey = configKey;
            _Configurations = configurations;
        }

        public Setting(string configKey, bool required, IConfiguration configurations)
        {
            ConfigKey = configKey;
            Required = required;
            _Configurations = configurations;
        }

        public string ConfigKey { get; set; }

        public bool Required { get; }


        public static implicit operator string(Setting<T> d)
        {
            return d.ConfigKey;
        }

        public static implicit operator Setting<T>(string d)
        {
            return new Setting<T> { ConfigKey = d };
        }

        public T Get()
        {
            return Get(this.Required);
        }

        public T Get(bool required)
        {
            SettingsReader.Configurations = _Configurations;
            return SettingsReader.Get<T>(this.ConfigKey, required);
        }

        public T Get(T defaultValue)
        {
            SettingsReader.Configurations = _Configurations;
            return SettingsReader.Get<T>(this.ConfigKey, defaultValue);
        }
    }

}