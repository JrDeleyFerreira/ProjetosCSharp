﻿using Microsoft.Extensions.Configuration;
using System;

namespace GenAI.Crosscutting.Infra.Settings
{
    public class GenAISettings
    {
        public static IConfiguration Configurations { get; set; }

        private static T GetValueAppSetting<T>(string path)
        {
            return new Setting<T>(path, true, Configurations).Get();
        }
        private static string GetValueEnvironmentVariable(string environmentName)
        {
            return Environment.GetEnvironmentVariable(environmentName);
        }
        private static bool IsDevelopment()
        {
            string environmentName = GetValueEnvironmentVariable("ASPNETCORE_ENVIRONMENT");
            return environmentName == "Local";
        }

        public static string ConnectionStringsJobs => IsDevelopment() 
            ? GetValueAppSetting<string>("ConnectionStrings:Jobs") 
            : GetValueEnvironmentVariable("CONNECTION_STRING_JOBS");

        public static string ConnectionStringsDefault => IsDevelopment() 
            ? GetValueAppSetting<string>("ConnectionStrings:Default") 
            : GetValueEnvironmentVariable("CONNECTION_STRING_DEFAULT");
        
        //Azure AI

        public static string KeyAzureAI => IsDevelopment()
            ? GetValueAppSetting<string>("AzureAI:Key")
            : GetValueEnvironmentVariable("OPENAI_API_KEY");

        public static string CompletionsAzureAI => IsDevelopment()
            ? GetValueAppSetting<string>("AzureAI:Completions")
            : GetValueEnvironmentVariable("OPENAI_COMPLETIONS");

        public static string EndpointAzureAI => IsDevelopment()
            ? GetValueAppSetting<string>("AzureAI:Endpoint")
            : GetValueEnvironmentVariable("OPENAI_END_POINT");

        public static string ApiVersionAzureAI => IsDevelopment()
            ? GetValueAppSetting<string>("AzureAI:ApiVersion")
            : GetValueEnvironmentVariable("OPENAI_API_VERSION");

        //Resources codes for func calling

        public static string PromptWelcomeFuncResourceCode => GetValueAppSetting<string>("ResourceCodesFuncCalling:PromptWelcomeFunc");
        public static string PromptFindWorkflowsFuncResourceCode => GetValueAppSetting<string>("ResourceCodesFuncCalling:PromptFindWorkflowsFunc");
        public static string PromptBaseFuncResourceCode => GetValueAppSetting<string>("ResourceCodesFuncCalling:PromptBaseFunc");
        public static string OpenAiFuncResourceCode => GetValueAppSetting<string>("ResourceCodesFuncCalling:OpenAiFunc");

        // Exceptions
        public static bool SendAllExceptionsToClient => GetValueAppSetting<bool>("Exceptions:SendAllDetailsToClient");

        //App
        public static string AppClientRootAddress => IsDevelopment()
            ? GetValueAppSetting<string>("AzureAI:ClientRootAddress")
            : GetValueEnvironmentVariable("URL_PORTAL");

        public static string ServerRootAddress => IsDevelopment()
            ? GetValueAppSetting<string>("AzureAI:ServerRootAddress")
            : GetValueEnvironmentVariable("URL_API");

        //JWT
        public static string JwtBearerSecurityKey => IsDevelopment() 
            ? GetValueAppSetting<string>("Authentication:JwtBearer:SecurityKey") 
            : GetValueEnvironmentVariable("JWT_SECURITY_KEY");

        //AzureAd
        public static string AzureAdTenantId => IsDevelopment()
            ?  GetValueAppSetting<string>("AzureAd:TenantId")
            : GetValueEnvironmentVariable("TENANT_ID");

        public static string AzureAdClientId => IsDevelopment()
           ? GetValueAppSetting<string>("AzureAd:ClientId")
           : GetValueEnvironmentVariable("SSO_SP_APP_ID");

        public static string AzureAdGroupId => IsDevelopment()
           ? GetValueAppSetting<string>("AzureAd:GroupId")
           : GetValueEnvironmentVariable("AZURE_AD_GROUP");

        public static string AzureAdClientSecret => IsDevelopment() 
            ? GetValueAppSetting<string>("AzureAd:ClientSecret") 
            : GetValueEnvironmentVariable("SSO_SP_APP_SECRET");

        public static string DiscoveryEndpoint => IsDevelopment()
            ? GetValueAppSetting<string>("AzureAd:DiscoveryEndpoint")
            : GetValueEnvironmentVariable("AZURE_AD_DISCOVERY_END_POINT");

        public static string ClaimType => IsDevelopment()
            ? GetValueAppSetting<string>("AzureAd:ClaimType")
            : GetValueEnvironmentVariable("AZURE_AD_CLAIM");

        public static string Domain => IsDevelopment()
            ? GetValueAppSetting<string>("AzureAd:Domain")
            : GetValueEnvironmentVariable("AZURE_AD_DOMAIN");

        public static string Issuer => IsDevelopment()
            ? GetValueAppSetting<string>("AzureAd:Issuer")
            : GetValueEnvironmentVariable("AZURE_AD_ISSUER");

        //BlobStorage
        public static string AccountNameStorage => IsDevelopment() 
            ? GetValueAppSetting<string>("AzureStorageConfig:AccountName") 
            : GetValueEnvironmentVariable("BLOB_ACCOUNT_NAME");

        public static string AccountKeyStorage => IsDevelopment()
            ? GetValueAppSetting<string>("AzureStorageConfig:AccountKey")
            : GetValueEnvironmentVariable("BLOB_ACCOUNT_KEY");

        public static string StorageAccountConnectionString =>
            $"DefaultEndpointsProtocol=https;AccountName={AccountNameStorage};AccountKey={AccountKeyStorage};EndpointSuffix=core.windows.net";

        public static string TableStorageLog => IsDevelopment()
            ? GetValueAppSetting<string>("AzureStorageConfig:TableAzure")
            : GetValueEnvironmentVariable("BLOB_TABLE_LOG");

        public static string ContainerLogApi => IsDevelopment()
            ? GetValueAppSetting<string>("AzureStorageConfig:ContainerLogApi")
            : GetValueEnvironmentVariable("BLOB_CONTAINER_LOG");

        public static string ContainerNameStorage => IsDevelopment()
            ? GetValueAppSetting<string>("AzureStorageConfig:ContainerName")
            : GetValueEnvironmentVariable("BLOB_CONTAINER_NAME");

        //CosmosDB
        public static string CosmosDbUri => IsDevelopment() 
            ? GetValueAppSetting<string>("ConnectionStrings:CosmosDbUrl") 
            : GetValueEnvironmentVariable("COSMOS_DB_URL");

        public static string CosmosDbKey => IsDevelopment() 
            ? GetValueAppSetting<string>("ConnectionStrings:CosmosDbKey") 
            : GetValueEnvironmentVariable("COSMOS_DB_KEY");

        //Kafka
        public static string ChatTopicCallback => IsDevelopment()
            ? GetValueAppSetting<string>("Topics:Chat")
            : GetValueEnvironmentVariable("KAFKA_TOPICS_CHAT");

        public static string KafkaBoostrapServers => IsDevelopment() 
            ? GetValueAppSetting<string>("KafkaSettings:BootstrapServers") 
            : GetValueEnvironmentVariable("BROKER_LIST");

        public static string KafkaConsumerGroupId => IsDevelopment()
            ? GetValueAppSetting<string>("KafkaSettings:KafkaConsumerGroupId")
            : GetValueEnvironmentVariable("KAFKA_CONSUMER_GROUP");

        public static string KafkaProducerGroupId => IsDevelopment()
            ? GetValueAppSetting<string>("KafkaSettings:KafkaProducerGroupId")
            : GetValueEnvironmentVariable("KAFKA_PRODUCER_GROUP");

        public static string KafkaSaslUsername => IsDevelopment() 
            ? GetValueAppSetting<string>("KafkaSettings:SaslUsername") 
            : GetValueEnvironmentVariable("KAFKA_USERNAME");

        public static string KafkaSaslPassword => IsDevelopment() 
            ? GetValueAppSetting<string>("KafkaSettings:SaslPassword") 
            : GetValueEnvironmentVariable("KAFKA_PASSWORD");
        public static string KafkaSaslProtocol => IsDevelopment()
            ? GetValueAppSetting<string>("KafkaSettings:SaslProtocol")
            : GetValueEnvironmentVariable("KAFKA_PROTOCOL");

        public static string SignalRConnectionString => IsDevelopment()
            ? GetValueAppSetting<string>("SignalR:ConnectionString")
            : GetValueEnvironmentVariable("SIGNALR_CONNECTION_STRING");

        //Copilot
        public static bool SendKafka => GetValueAppSetting<bool>("Copilot:SendKafka");

        //Url Tokenized
        public static string UrlTokenizedSecret => IsDevelopment() 
            ? GetValueAppSetting<string>("UrlTokenized:Secret") 
            : GetValueEnvironmentVariable("URL_TOKENIZED_SECRET");

        //CorsOrigins
        public static string CorsOrigins => IsDevelopment()
            ? GetValueAppSetting<string>("App:CorsOrigins")
            : GetValueEnvironmentVariable("APP_CORS_ORIGINS");


        //Chaves de criptografia
        public static string CriptoPublicKey => IsDevelopment()
            ? GetValueAppSetting<string>("Encryption:CriptoPublicKey")
            : GetValueEnvironmentVariable("CRIPTO_PUBLIC_KEY");

        public static string CriptoPrivateKey => IsDevelopment() 
            ? GetValueAppSetting<string>("Encryption:CriptoPrivateKey") 
            : GetValueEnvironmentVariable("CRIPTO_PRIVATE_KEY");

        //Affinity Compass TenantId
        public static string AffinityCompassTenantId => IsDevelopment() 
            ? GetValueAppSetting<string>("AffinityCompass:TenantId") 
            : GetValueEnvironmentVariable("AFFINITY_COMPASS_TENANT_ID");

        public static string HostMail => IsDevelopment() 
            ?  GetValueAppSetting<string>("EmailConfiguration:Host") 
            : GetValueEnvironmentVariable("SMTP_HOST_MAIL");

        public static string PortMail => IsDevelopment()
            ? GetValueAppSetting<string>("EmailConfiguration:Port")
            : GetValueEnvironmentVariable("SMTP_PORT_MAIL");

        public static string UserEmail => IsDevelopment() 
            ? GetValueAppSetting<string>("EmailConfiguration:UserName") 
            : GetValueEnvironmentVariable("SMTP_USER_MAIL");

        public static string UserEmailPassword => IsDevelopment() 
            ? GetValueAppSetting<string>("EmailConfiguration:Password") 
            : GetValueEnvironmentVariable("SMTP_PASSWORD_MAIL");

        public static string EndpointConvertMarkdown => IsDevelopment()
          ? GetValueAppSetting<string>("ENDPOINT_CONVERT_MARKDOWN")
          : GetValueEnvironmentVariable("ENDPOINT_CONVERT_MARKDOWN");

        //Flag is Production
        public static string IsProductionEnvironment => IsDevelopment()
           ? GetValueAppSetting<string>("Environment:Environment_IsProduction")
           : GetValueEnvironmentVariable("ENVIRONMENT_ISPRODUCTION");      

    }
}