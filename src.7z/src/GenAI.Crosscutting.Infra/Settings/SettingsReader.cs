﻿using Abp.Dependency;
using GenAI.Crosscutting.Infra.Extensions;
using Microsoft.Extensions.Configuration;
using System;
using System.Configuration;

namespace GenAI.Crosscutting.Infra.Settings
{
    public class SettingsReader
    {
        public static IConfiguration Configurations { get; set; }
        public static T Get<T>(string key)
        {
            return Get<T>(key, false);
        }

        public static T Get<T>(string key, bool required)
        {
            TryGet(key, out T confVal, required);
            return confVal;
        }

        public static T Get<T>(string key, T defaultValue)
        {

            return TryGet(key, out T confVal) ? confVal : defaultValue;
        }


        private static bool TryGet<T>(string key, out T confVal, bool required = false)
        {
            IConfiguration configurations = Configurations ?? IocManager.Instance.Resolve<IConfiguration>();

            confVal = default(T);


            bool isPrimitive = typeof(T).IsPrimitiveExtendedIncludingNullable(true);


            bool hasVal = ((isPrimitive && configurations[key] != null) || (!isPrimitive && configurations.GetSection(key) != null));


            if (required && !hasVal)
            {
                throw new ConfigurationErrorsException($"Configuração '{key}' não foi encontrada.");
            }

            if (!required && !hasVal)
            {

                return false;
            }

            if (!isPrimitive)
            {
                confVal = Activator.CreateInstance<T>();
                configurations.Bind(key, confVal);

                return true;
            }


            try
            {
                confVal = configurations.GetValue<T>(key);
            }
            catch
            {
                throw new FormatException($"Não é possivel converter o valor da configuração {key}=\"{configurations[key]}\" para o tipo '{typeof(T).Name}'.");
            }
            return true;
        }


    }
}

