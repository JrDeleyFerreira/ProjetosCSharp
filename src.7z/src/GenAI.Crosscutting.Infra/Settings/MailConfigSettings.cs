﻿using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using SendGrid.Helpers.Mail;
using System;
using System.Collections.Generic;
using System.IO;
using System.Xml;
using System.Linq;

namespace GenAI.Crosscutting.Infra.Settings
{
    public sealed class MailConfigSettings
    {
        internal static MailSettings MailSettings { get; private set; }
        public MailConfigSettings() 
        {
            
        }

        private static void LoadSettings()
        {
            MailSettings = new MailSettings();
            string[] array = new string[3]
            {
                "appsettings.json",
                "web.config",
                GetAppName() + ".config"
            };
            foreach (string path in array)
            {
                string path2 = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, path);
                if (!File.Exists(path2))
                {
                    continue;
                }

                string text = File.ReadAllText(path2);
                if (Path.GetExtension(path2) == ".json")
                {
                    JObject jObject = (JObject)JsonConvert.DeserializeObject(text);
                    if (jObject.ContainsKey("mailSettings"))
                    {
                        ((List<ProtocolEntrySettings>)MailSettings.Smtp).AddRange(LoadProtocolEntriesSettingsFromJsonArray((JArray)jObject["mailSettings"]!["smtp"]));
                        ((List<ProtocolEntrySettings>)MailSettings.Pop3).AddRange(LoadProtocolEntriesSettingsFromJsonArray((JArray)jObject["mailSettings"]!["pop3"]));
                        ((List<ProtocolEntrySettings>)MailSettings.Imap).AddRange(LoadProtocolEntriesSettingsFromJsonArray((JArray)jObject["mailSettings"]!["imap"]));
                    }
                    else if (jObject.ContainsKey("system.net"))
                    {
                        ((List<ProtocolEntrySettings>)MailSettings.Smtp).AddRange(LoadOldSmtpSettingsFromJsonArray((JArray)jObject["system.net"]!["mailSettings"]));
                    }
                }
                else
                {
                    XmlDocument xmlDocument = new XmlDocument();
                    xmlDocument.LoadXml(text);
                    ((List<ProtocolEntrySettings>)MailSettings.Smtp).AddRange(LoadOldSmtpSettingsFromXmlNodeList(xmlDocument.GetElementsByTagName("smtp")));
                }
            }
        }

        private static ProtocolEntrySettings[] LoadProtocolEntriesSettingsFromJsonArray(JArray rawProtocolEntries)
        {
            List<ProtocolEntrySettings> list = new List<ProtocolEntrySettings>();
            if (rawProtocolEntries != null)
            {
                list.AddRange(JsonConvert.DeserializeObject<ProtocolEntrySettings[]>(rawProtocolEntries.ToString()));
            }

            return list.ToArray();
        }

        private static ProtocolEntrySettings[] LoadOldSmtpSettingsFromJsonArray(JArray mailSettingsArray)
        {
            List<ProtocolEntrySettings> list = new List<ProtocolEntrySettings>();
            foreach (JToken item2 in mailSettingsArray ?? JArray.Parse("[]"))
            {
                ProtocolEntrySettings item = new ProtocolEntrySettings
                {
                    Key = item2["from"]!.ToString(),
                    Settings = new ProtocolSettings
                    {
                        Host = item2["network"]!["host"]!.ToString(),
                        Port = Convert.ToInt32(item2["network"]!["port"]),
                        Username = (item2["network"]!["userName"]?.ToString() ?? ""),
                        Password = (item2["network"]!["password"]?.ToString() ?? "")
                    }
                };
                list.Add(item);
            }

            return list.ToArray();
        }
        private static ProtocolEntrySettings[] LoadOldSmtpSettingsFromXmlNodeList(XmlNodeList smtpNodeList)
        {
            List<ProtocolEntrySettings> list = new List<ProtocolEntrySettings>();
            if (smtpNodeList != null)
            {
                foreach (XmlNode smtpNode in smtpNodeList)
                {
                    XmlNode xmlNode2 = smtpNode.SelectSingleNode("network");
                    ProtocolEntrySettings item = new ProtocolEntrySettings
                    {
                        Key = smtpNode.Attributes!["from"]!.Value,
                        Settings = new ProtocolSettings
                        {
                            Host = xmlNode2.Attributes!["host"]!.Value,
                            Port = Convert.ToInt32(xmlNode2.Attributes!["port"]!.Value),
                            Username = (xmlNode2.Attributes!["userName"]?.Value ?? ""),
                            Password = (xmlNode2.Attributes!["password"]?.Value ?? "")
                        }
                    };
                    list.Add(item);
                }
            }

            return list.ToArray();
        }

        private static string GetAppName()
        {
            string text = AppDomain.CurrentDomain.FriendlyName;
            if (text == "testhost")
            {
                text = Path.GetFileNameWithoutExtension(Directory.GetFiles(AppDomain.CurrentDomain.BaseDirectory, "*.config").First());
            }

            return text;
        }

        public static (string protocol, ProtocolSettings settings) GetSendProtocolSettings(string key)
        {
            if (MailSettings == null)
            {
                LoadSettings();
            }

            ProtocolEntrySettings protocolEntrySettings = MailSettings.Smtp.FirstOrDefault((ProtocolEntrySettings x) => x.Key.Equals(key));
            if (protocolEntrySettings == null)
            {
                throw new Exception("Não foi possível localizar a configuração de envio de e-mail para " + key + ".");
            }

            return ("Smtp", protocolEntrySettings.Settings);
        }
    }
}
