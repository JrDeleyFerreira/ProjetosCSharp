﻿
namespace GenAI.Crosscutting.Infra.Settings
{
    public class ServiceBusConfig
    {
        public string ConnectionString { get; set; }
        public string NewUserQueue { get; set; }
    }
}
