﻿using Abp.Configuration;
using System.Collections.Generic;

namespace GenAI.Crosscutting.Infra.Settings
{
    public class GenAISettingProvider : SettingProvider
    {
        public override IEnumerable<SettingDefinition> GetSettingDefinitions(SettingDefinitionProviderContext context)
        {
            return new[]
            {
                new SettingDefinition(
                    "SampleSetting",
                    "false",
                    scopes: SettingScopes.User
                )
            };
        }
    }
}

