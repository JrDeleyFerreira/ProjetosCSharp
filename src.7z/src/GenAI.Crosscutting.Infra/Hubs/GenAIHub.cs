﻿using System.Threading.Tasks;
using Microsoft.AspNetCore.SignalR;

namespace GenAI.Crosscutting.Infra.Hubs;

public class GenAIHub : Hub
{
    public string GetConnectionId() => Context.ConnectionId;
    public async Task SendMessageAsync(string method, string message, string connectionId)
    {
        await Clients.Client(connectionId).SendAsync(method, message);
    }
}