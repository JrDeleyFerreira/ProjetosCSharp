﻿namespace GenAI.Crosscutting.Infra.Integrations;

public abstract class IntegrationEvent : Event
{
    
}