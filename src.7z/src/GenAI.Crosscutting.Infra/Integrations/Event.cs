﻿using System;

namespace GenAI.Crosscutting.Infra.Integrations
{
    public class Event
    {
        public DateTime TimeStamp { get; set; }

        public Event()
        {
            TimeStamp = DateTime.Now;
        }
    }
}
