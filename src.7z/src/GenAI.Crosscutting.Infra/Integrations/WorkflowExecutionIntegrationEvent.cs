﻿using System.Text.Json.Serialization;

namespace GenAI.Crosscutting.Infra.Integrations;

public class WorkflowExecutionIntegrationEvent : IntegrationEvent
{
    public WorkflowExecutionIntegrationEvent()
    {
        
    }
    [JsonPropertyName("workflow_execution_id")]
    public string WorkflowExecutionId { get; set; }

    [JsonPropertyName("tenant_id")]
    public string TenantId { get; set; }
}