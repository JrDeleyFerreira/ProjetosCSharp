﻿using Newtonsoft.Json.Serialization;

namespace GenAI.Crosscutting.Infra.Util
{
    public class CustomJsonWriter : NamingStrategy 
    {
        protected override string ResolvePropertyName(string name)
        {
            string nameCahnged = name.ToLower();
            return nameCahnged;
        }
    }
}
