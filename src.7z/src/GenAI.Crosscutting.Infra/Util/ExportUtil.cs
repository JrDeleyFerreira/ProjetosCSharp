﻿using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GenAI.Crosscutting.Infra.Util
{
    public static class ExportUtil
    {

        public static byte[] ExportExcel(List<string> columnLines, string[] columnHeaders, string fileName, string format, List<int> columnAmounts)
        {
            using (var package = new ExcelPackage())
            {
                var worksheet = package.Workbook.Worksheets.Add(fileName);
                using (var cells = worksheet.Cells[1, 1, 1, columnHeaders.Count()])
                {
                    cells.Style.Font.Bold = true;
                }

                for (var i = 0; i < columnHeaders.Count(); i++)
                {
                    worksheet.Cells[1, i + 1].Value = columnHeaders[i];
                }

                var lineCount = 2;
                var columnCount = 1;
                for (var i = 0; i < columnLines.Count(); i++)
                {
                    if (columnAmounts.Contains(columnCount))
                        worksheet.Cells[lineCount, columnCount].Value = Convert.ToDecimal(columnLines[i]);
                    else
                        worksheet.Cells[lineCount, columnCount].Value = columnLines[i];

                    columnCount++;

                    if (columnHeaders.Count() < columnCount)
                    {
                        lineCount++;
                        columnCount = 1;
                    }
                }

                worksheet.Cells.Style.Numberformat.Format = format;
                worksheet.Cells.AutoFitColumns();

                return package.GetAsByteArray();
            }
        }

        public static byte[] ExportCSV(List<object[]> columnLines, string[] columnHeaders, string delimiter)
        {
            var billingcsv = new StringBuilder();

            columnLines.ForEach(line =>
            {
                billingcsv.AppendLine(string.Join(delimiter, line));
            });

            return Encoding.GetEncoding("ISO-8859-6")
                .GetBytes($"{string.Join(";", columnHeaders)}\r\n{billingcsv.ToString()}");
        }
    }
}


