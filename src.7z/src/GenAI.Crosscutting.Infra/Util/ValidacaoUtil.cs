﻿using GenAI.Crosscutting.Infra.Extensions;
using GenAI.Crosscutting.Infra.Settings;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace GenAI.Crosscutting.Infra.Util
{
    public static class ValidacaoUtil
    {
        #region CPF

        /// <summary>
        /// Verifica se um cpf é válido.
        /// </summary>
        /// <param name="cpf">CPF</param>
        /// <returns>true se o CPF for válido.</returns>
        public static bool IsCpfValido(string cpf)
        {
            if (string.IsNullOrEmpty(cpf)
                || cpf.Length != GenAITamanhoCampos.Cpf
                || cpf != cpf.OnlyNumbers()
                || cpf.Distinct().Count() == 1)
            {
                return false;
            }

            StringBuilder digito = new StringBuilder();
            int k, j;

            for (k = 0; k < 2; k++)
            {
                var soma = 0;

                for (j = 0; j < 9 + k; j++)
                {
                    soma += int.Parse(cpf[j].ToString()) * (10 + k - j);
                }

                if (soma % 11 == 0 || soma % 11 == 1)
                {
                    digito.Append(0);
                }
                else
                {
                    digito.Append(11 - (soma % 11));
                }
            }

            return (digito[0] == cpf[9] & digito[1] == cpf[10]);
        }

        #endregion

        #region CNPJ

        public static bool IsCnpjValido(string cnpj)
        {
            if (string.IsNullOrEmpty(cnpj)
                || cnpj.Length != GenAITamanhoCampos.Cnpj
                || cnpj != cnpj.OnlyNumbers()
                || cnpj.Distinct().Count() == 1)
            {
                return false;
            }

            IList<int[]> mutiplicadores = new List<int[]>
            {
                new int[12] {5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2},
                new int[13] {6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2}
            };

            string digito = string.Empty;
            string cnpjAuxiliar = cnpj.Substring(0, 12);

            foreach (int[] mutiplicador in mutiplicadores)
            {
                int soma = 0;

                for (int i = 0; i < cnpjAuxiliar.Length; i++)
                {
                    soma += int.Parse(cnpjAuxiliar[i].ToString()) * mutiplicador[i];
                }

                int resto = soma % 11;
                resto = resto < 2 ? 0 : 11 - resto;

                digito = $"{digito}{resto}";
                cnpjAuxiliar = $"{cnpjAuxiliar}{digito}";
            }

            return cnpj.EndsWith(digito);
        }

        #endregion

        #region Email

        /// <summary>
        /// Verifica se um endereço de email é válido.
        /// </summary>
        /// <param name="email">email</param>
        /// <returns>true se o email for válido.</returns>
        public static bool IsEmailValido(string email)
        {
            if (string.IsNullOrEmpty(email))
            {
                return true;
            }

            if (email.Length > GenAITamanhoCampos.Email)
            {
                return false;
            }

            return Regex.IsMatch(email, GenAIRegexPatterns.Email, RegexOptions.IgnoreCase);
        }

        #endregion

        #region CEP

        /// <summary>
        /// Verifica se o CEP preenchido contém 8 caracteres
        /// </summary>
        /// <param name="cep">Valor do CEP a ser validado</param>
        /// <returns>Verdadeiro se o CEP está no formato válido</returns>
        public static bool IsCepValido(string cep)
        {
            if (string.IsNullOrEmpty(cep))
            {
                return true;
            }

            return cep.Length == GenAITamanhoCampos.Cep;
        }

        #endregion

        #region Telefone

        /// <summary>
        /// Verifica se o telefone preenchido contém de 10 ou 11 caracteres
        /// </summary>
        /// <param name="telefone">Valor do telefone a ser validado</param>
        /// <returns>Verdadeiro se o telefone está com tamanho válido</returns>
        public static bool IsTelefoneValido(string telefone)
        {
            if (string.IsNullOrEmpty(telefone))
            {
                return true;
            }

            return telefone.All(char.IsNumber)
                && (telefone.Length == GenAITamanhoCampos.Telefone
                    || telefone.Length == GenAITamanhoCampos.Celular);
        }


        public static bool IsCelular(string telefone)
        {
            if (string.IsNullOrWhiteSpace(telefone) || telefone.Length < 10 || !telefone.All(char.IsNumber))
            {
                return false;
            }

            int digitoInicial = Convert.ToInt32(Convert.ToString(telefone[2]));
            return digitoInicial >= 6 && digitoInicial <= 9;
        }

        public static bool IsTelefoneOuCelularValido(string contato)
        {
            return IsTelefoneValido(contato) || IsCelular(contato);
        }

        #endregion

        #region Data e Hora

        /// <summary>
        /// Verifica se a idade é maior ou igual a 18
        /// </summary>
        /// <param name="dataNascimento">Data de nascimento</param>
        /// <returns>Verdadeiro se é maior de idade</returns>
        public static bool IsMaiorIdade(DateTime dataNascimento)
        {
            return dataNascimento.AddYears(18) <= DateTime.Now;
        }

        /// <summary>
        /// Verificar se a data e hora inicial é menor ou igual a data e hora final
        /// </summary>
        /// <param name="dataHoraInicial">Data e hora inicial</param>
        /// <param name="dataHoraFinal">Data e hora final</param>
        /// <returns></returns>
        public static bool IsPeriodoValido(DateTime dataHoraInicial, DateTime dataHoraFinal)
        {
            return dataHoraInicial <= dataHoraFinal;
        }

        /// <summary>
        /// Verificar se a hora está válida
        /// </summary>
        /// <param name="hora">Hora</param>
        /// <returns>Verdadeiro se a hora estiver preenchida e válida</returns>
        public static bool IsHoraValida(string hora)
        {
            if (string.IsNullOrEmpty(hora))
            {
                return true;
            }

            if (hora.Length != GenAITamanhoCampos.Hora)
            {
                return false;
            }

            return Regex.IsMatch(hora, GenAIRegexPatterns.Hora, RegexOptions.IgnoreCase);
        }

        #endregion

        #region Base64

        public static bool IsBase64(string base64Input)
        {
            Span<byte> buffer = new Span<byte>(new byte[base64Input.Length]);
            return Convert.TryFromBase64String(base64Input, buffer, out int bytesParsed);
        }

        #endregion
    }
}


