﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Security.Cryptography;
using System.Text;

namespace GenAI.Crosscutting.Infra.Util
{
    public static class Util
    {
        /// <summary>
		/// URL-encodes a query parameter value.
		/// </summary>
		/// <param name="value">The query parameter value to encode.</param>
		/// <param name="encodeSpaceAsPlus">If true, spaces will be encoded as + signs. Otherwise, they'll be encoded as %20.</param>
		/// <returns></returns>
		public static string EncodeQueryParamValue(object value, bool encodeSpaceAsPlus)
        {
            var culture = new CultureInfo(CultureInfo.CurrentCulture.Name)
            {
                NumberFormat = NumberFormatInfo.InvariantInfo
            };
            var result = Uri.EscapeDataString(Convert.ToString(value ?? "", culture));
            return encodeSpaceAsPlus ? result.Replace("%20", "+") : result;
        }
        public static List<DateTime> ListDaysInterval(DateTime initDate, DateTime endDate)
        {
            List<DateTime> dates = new List<DateTime>();
            dates.Add(initDate);

            if (initDate == endDate) return dates;

            while (initDate < endDate)
            {
                initDate = initDate.AddDays(1);
                dates.Add(initDate);
            }
            return dates;
        }
        public static int MonthDifference(DateTime lValue, DateTime rValue)
        {
            return Math.Abs((lValue.Month - rValue.Month) + 12 * (lValue.Year - rValue.Year)) + 1;
        }
        public static string GetFY(DateTime date)
        {
            if (date.Month > 1 && date.Month <= 8) return $"FY{GetDigitYear(date.Year)}";
            return $"FY{GetDigitYear(date.Year + 1)}";
        }

        private static string GetDigitYear(int year)
        {
            return year.ToString().Substring(2, 2);
        }
        public static DateTime GetDateMonthYear(int month, int year, bool lastDay = false)
        {
            return lastDay == true ? new DateTime(year, month, DateTime.DaysInMonth(year, month)) : new DateTime(year, month, 1);
        }
        public static DateTime GetDateNowTimeZoneId(string destinationTimeZoneId)
        {
            return TimeZoneInfo.ConvertTimeBySystemTimeZoneId(DateTime.UtcNow, destinationTimeZoneId);
        }
        public static int GetFYPeriod(DateTime date)
        {
            Dictionary<string, int> pairs = new();
            DateTime initFY;
            DateTime endFY;
            if (date.Month > 9 && date.Month <= 12)
            {
                initFY = new DateTime(date.Year, 9, 1);
                endFY = new DateTime(date.Year + 1, 8, 31);
            }
            else
            {
                initFY = new DateTime(date.Year - 1, 9, 1);
                endFY = new DateTime(date.Year, 8, 31);
            }
            int i = 1;
            while (initFY < endFY)
            {
                pairs.Add($"{initFY.Month}/{initFY.Year}", i);
                initFY = initFY.AddMonths(1);
                i++;
            }
            return pairs.FirstOrDefault(n => n.Key == $"{date.Month}/{date.Year}").Value;
        }
        public static string GenerateApiKey(Guid guid, DateTime dateTime, long userId)
        {
            // Concatenar os inputs em uma string
            string input = $"{guid}{dateTime:yyyyMMddHHmmss}{userId}";

            // Utilizar SHA256 para gerar o hash
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] hashBytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(input));

                // Converter o hash em uma string hexadecimal
                StringBuilder builder = new StringBuilder();
                foreach (byte b in hashBytes)
                {
                    builder.Append(b.ToString("x2"));
                }

                return builder.ToString();
            }
        }
    }
}
