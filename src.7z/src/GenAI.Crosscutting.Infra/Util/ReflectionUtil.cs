﻿using GenAI.Crosscutting.Infra.Settings;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

namespace GenAI.Crosscutting.Infra.Util
{
    public static class ReflectionUtil
    {
        public static IEnumerable<Type> GetTypesImplement<TType>()
        {
            return GetTypesImplement<TType>(GenAIConsts.NamespaceBaseName);
        }

        public static IEnumerable<Type> GetTypesImplement<TType>(string namespaceSolution)
        {
            return AppDomain.CurrentDomain.GetAssemblies()
                .Where(a => a.FullName.StartsWith(namespaceSolution))
                .SelectMany(a => a.GetTypes()
                    .Where(t => typeof(TType).IsAssignableFrom(t) && t.IsClass && !t.IsAbstract));
        }

        public static IEnumerable<TType> GetInstanceImplement<TType>()
        {
            var classTypes = GetTypesImplement<TType>();

            foreach (Type classType in classTypes)
            {
                ConstructorInfo ci = classType.GetConstructor(Type.EmptyTypes);
                if (ci != null)
                {
                    yield return (TType)ci.Invoke(null);
                }
            }
        }

        public static IEnumerable<Type> GetTypesOrInterfacesImplements<TType>()
        {
            return AppDomain.CurrentDomain.GetAssemblies()
                .SelectMany(a => a.GetTypes().Where(t => typeof(TType).IsAssignableFrom(t)));
        }
    }
}


