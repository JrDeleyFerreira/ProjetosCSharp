﻿using Abp.Runtime.Validation;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;

namespace GenAI.Crosscutting.Infra.Exceptions
{
    public class GenAIValidationException : AbpValidationException
    {
        public GenAIValidationException()
        {

        }

        public GenAIValidationException(SerializationInfo serializationInfo, StreamingContext context) : base(serializationInfo, context)
        {
        }

        public GenAIValidationException(string message) : base(message, new List<ValidationResult> { new ValidationResult(message) })
        {
        }

        public GenAIValidationException(string message, List<ValidationResult> validationErrors) : base(message, new List<ValidationResult>(validationErrors) { new ValidationResult(message) })
        {
        }

        public GenAIValidationException(string message, Exception innerException) : base(message, innerException)
        {
            this.ValidationErrors.Add(new ValidationResult(message));
        }

        public GenAIValidationException(List<ValidationResult> validationErrors) : base(string.Empty, new List<ValidationResult>(validationErrors))
        {
        }
    }
}


