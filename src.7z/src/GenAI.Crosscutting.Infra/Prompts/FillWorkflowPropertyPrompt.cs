﻿using Confluent.Kafka;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenAI.Crosscutting.Infra.Prompts
{
    public class FillWorkflowPropertyPrompt
    {
        public string GetFillWorkflowPropertyPrompt()
        {
            string prompt = $"Você é uma IA que ajuda a determinar a melhor propriedade para ser preenchida com base em um texto fornecido e no nome das propriedades. Aqui está como você deve proceder:" +
                            $"" +
                            $"1. Analise os nomes e hints das propriedades fornecidas." +
                            $"2. Leia o texto fornecido." +
                            $"3. Com base no contexto dos nomes das propriedades, hints e o conteúdo do texto, escolha a propriedade que parece ser a melhor para ser preenchida." +
                            $"" +
                            $"Exemplo:" +
                            $"" +
                            $"Propriedades:" +
                            $"- Descrição do Produto" +
                            $"- Feedback do Cliente" +
                            $"- Resumo do Artigo" +
                            $"" +
                            $"Texto: Este produto é excelente, funcionou perfeitamente e superou minhas expectativas." +
                            $"Hints: [\r\n  {{\r\n    \"language\": \"en\",\r\n    \"value\": \"Enter the type document(pdf or docx)\"\r\n  }},\r\n  {{\r\n    \"language\": \"pt-BR\",\r\n    \"value\": \"Insira o tipo do documento(pdf ou docx)\"\r\n  }}\r\n]" +
                            $"" +
                            $"Escolha: Feedback do Cliente" +
                            $"" +
                            $"Observe as Hints de cada propriedade para ter uma análise melhor de escolha" +
                            $"Agora é a sua vez. Escolha a propriedade mais adequada com base no texto fornecido." +
                            $"";

            return prompt;
        }

        public string GetFillWorkflowPropertyTextPrompt(string properties, string text)
        {
            string prompt =
                            $"Propriedades E Hints:" +
                            $"- {properties}" +
                            $"" +
                            $"Texto: {text}" +
                            $"" +
                            $"" +
                            $"Escolha: (Retorne apenas o nome da propriedade sem comentários adicionais)";

            return prompt;
        }
    }
}
