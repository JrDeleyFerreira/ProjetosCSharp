﻿using Microsoft.Azure.Cosmos.Core.Collections;
using OfficeOpenXml.FormulaParsing.Excel.Functions.Information;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Intrinsics.X86;
using System.Text;
using System.Threading.Tasks;

namespace GenAI.Crosscutting.Infra.Prompts
{
    public class FinalDescriptionPrompt
    {
        public string GetFinalDescriptionPrompt(string level)
        {
            string prompt = $"Você é um assistente de IA que auxilia a criar um texto de acordo com níveis de utilização de IA." +
                             $"Os Níveis existentes são: Neutro, Exploração, Experimentação, Especialização e Transformação." +
                             $"Leve em consideração que para ter o resultado desse level, uma pessoa respondeu um questionário que contém 3 dominíos que se chamam Estratégico, Tecnológico e Experiência," +
                             $"Cada pergunta respondida sobre como você a IA dentro da empresa gera um score para cada domínio e no final é feito uma soma dos scores dos domínios gerando o Nível dele." +
                             $"Tendo em vista as informações acima, crie um texto de 2 parágrafos de acordo com o nível {level}, o primeiro parágrafo deve criar um texto sobre o própio nível dado e o segundo parágrafo deve dar sugestões de como melhorar essa integração de IA dentro da empresa." +
                             $"Não sugestione treinamento de funcionários, estamos tratando de soluções." +
                             $"A empresa que esta realizando o questionário é uma provedora de soluções que pode suprir as necessidades de IA que o usuario precisa." +
                             $"Após a primera explicação colocar um <br> entre a quebra de linha, não deve ser colocado no final e sim no meio." +
                             $"";

            return prompt;
        }

        public string GetFinalDescriptionLanguagePrompt(string text, string language)
        {
            string prompt = $"Traduza esse texto abaixo para a lingua '{language}', leve em consderação que o nome da lingua esta abreviado." +
                            $"   " +
                            $"{text}";

            return prompt;
        }

        public string CreateAssistantAndGetFinalDescriptionPrompt(string level, string language)
        {
            return $@"
                    {GetFinalDescriptionPrompt(level)}.
                    O texto deve estar na lingua '{language}', leve em consideração que o nome da lingua está abreviado.
                ";
        }
    }
   
}
