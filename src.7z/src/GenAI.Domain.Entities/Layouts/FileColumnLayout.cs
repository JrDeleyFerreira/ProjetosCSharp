﻿using System;

namespace GenAI.Domain.Entities.Layouts;

public class FileColumnLayout : BaseEntity
{
    public FileLayout FileLayout { get; set; }
    public Guid FileLayoutId{ get; set; }
    public string Name { get; set; }
    public int Position { get; set; }
    public CorrespondingInformation CorrespondingInformation { get; set; }
    public Guid CorrespondingInformationId { get; set; }
}
