﻿using Abp.Domain.Entities;
using System;

namespace GenAI.Domain.Entities.Layouts;

public class EntityTypeCorrespondingInformation : Entity<Guid>
{
    public EntityType EntityType { get; set; }
    public Guid EntityTypeId { get; set; }
    public CorrespondingInformation CorrespondingInformation { get; set; }
    public Guid CorrespondingInformationId { get; set; }
}
