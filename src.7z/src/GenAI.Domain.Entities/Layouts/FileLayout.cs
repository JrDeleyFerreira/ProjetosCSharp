﻿using GenAI.Domain.Entities.Systems;
using System;
using System.Collections.Generic;

namespace GenAI.Domain.Entities.Layouts;

public class FileLayout : BaseEntity
{
    public EntityType EntityType { get; set; }
    public Guid EntityTypeId { get; set; }
    public ICollection<FileColumnLayout> FileColumns{ get; set; }
	public Guid? SystemId { get; set; }
	public BusinessSystem? System { get; set; }
}
