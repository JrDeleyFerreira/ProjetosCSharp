﻿using GenAI.Domain.Entities.Enums;

namespace GenAI.Domain.Entities.Layouts;

public class CorrespondingInformation : BaseEntity
{
    public CorrespondingInformationProperties EntityProperties { get; set; }
    public string Description { get; set; }
}
