﻿using GenAI.Domain.Entities.Enums;

namespace GenAI.Domain.Entities.Layouts;

public class EntityType : BaseEntity
{
    public EntityTypes Type { get; set; }
    public string Description { get; set; }
}
