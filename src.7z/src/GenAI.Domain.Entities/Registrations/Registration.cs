﻿namespace GenAI.Domain.Entities.Registrations;

public class Registration : BaseEntity
{
    public string ValiaRegistration { get; set; }
    public string OfficialRegistration { get; set; }
}
