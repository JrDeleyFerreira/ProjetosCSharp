﻿using System;

namespace GenAI.Domain.Entities.Collaborators;

public class Collaborator : BaseEntity
{
    public string Key { get; set; }
    public string Name { get; set; }
    public string Supplier { get; set; }
    public string Responsible { get; set; }
    public DateTime? ContractExpirationDate { get; set; }
    public string Email { get; set; }
}
