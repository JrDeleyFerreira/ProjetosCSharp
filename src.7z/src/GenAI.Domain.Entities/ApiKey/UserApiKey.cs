﻿using System;
using Abp.Domain.Entities;

namespace GenAI.Domain.Entities.ApiKey;

public class UserApiKey : Entity<Guid>
{
    public string Name { get; set; }
    public string Key { get; set; }
    public long UserId { get; set; }
    public DateTime Expiration { get; set; }

    public virtual User User { get; set; }
}