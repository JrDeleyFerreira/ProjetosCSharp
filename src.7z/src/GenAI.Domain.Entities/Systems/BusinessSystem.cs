﻿using System.Collections.Generic;

namespace GenAI.Domain.Entities.Systems;

public class BusinessSystem : BaseEntity
{
    public string Description { get; set; }
    public ICollection<SystemGroup> Groups { get; set; }
}
