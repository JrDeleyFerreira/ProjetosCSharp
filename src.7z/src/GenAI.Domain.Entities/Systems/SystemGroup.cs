﻿using System;

namespace GenAI.Domain.Entities.Systems
{
	public class SystemGroup : BaseEntity
    {
        public string Description { get; set; }
        public Guid SystemId { get; set; }
        public BusinessSystem System { get; set; }
    }
}
