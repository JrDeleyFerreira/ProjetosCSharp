﻿using System;

namespace GenAI.Domain.Entities.Systems
{
	public class SodMatrix : BaseEntity
    {
        public Guid FirstGroupId { get; set; }
        public Guid SecondGroupId { get; set; }
        public string Comment { get; set; }
        public SystemGroup FirstGroup { get; set; }
        public SystemGroup SecondGroup { get; set; }
    }
}
