﻿using Abp.Domain.Entities;
using System;

namespace GenAI.Domain.Entities;

public class BaseEntity : Entity<Guid>
{
    public bool IsActive { get; set; }
    public DateTime CreationTime { get; set; }
	public long CreatorUserId { get; set; }
	public DateTime? DeletionTime { get; set; }
	public long? DeletionUserId { get; set; }
	public DateTime? LastModificationTime { get; set; }
	public long? LastModifierUserId { get; set; }
}
