﻿using Abp.Authorization.Users;
using Abp.Extensions;
using GenAI.Domain.Entities.ApiKey;
using GenAI.Domain.Entities.Tenants;
using GenAI.Domain.Entities.Tokens;
using System;
using System.Collections.Generic;

namespace GenAI.Domain.Entities
{
    public class User : AbpUser<User>
    {

        public const string DefaultPassword = "123qwe";
        public virtual ICollection<Token> Tokens { get; set; }
        public virtual ICollection<TenantUser> TenantUseres { get; set; }
        public virtual ICollection<UserApiKey> UserApiKeys { get; set; }        
        public static string CreateRandomPassword()
        {
            return Guid.NewGuid().ToString("N").Truncate(16);
        }

        public static User CreateTenantAdminUser(int tenantId, string emailAddress)
        {
            User user = new()
            {
                TenantId = tenantId,
                UserName = AdminUserName,
                Name = AdminUserName,
                Surname = AdminUserName,
                EmailAddress = emailAddress,
                Roles = new List<UserRole>()
            };

            user.SetNormalizedNames();

            return user;
        }
    }
}


