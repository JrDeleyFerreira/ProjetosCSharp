﻿using Abp.Domain.Entities;
using System;

namespace GenAI.Domain.Entities.Tokens
{
    public class Token : Entity<Guid>
    {
        public string TokenId { get; set; }
        public long UserId { get; set; }
        public DateTime Created { get; set; }
        public virtual User User { get; set; }
    }
}
