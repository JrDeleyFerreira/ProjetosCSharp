﻿using Abp.Domain.Entities;
using System;

namespace GenAI.Domain.Entities.ImportedDocuments;

public class ImportedDocument : Entity<Guid>
{
    public string EntityType { get; set; }
    public string FileName { get; set; }
    public string FileExtension { get; set; }
    public DateTime CreationTime { get; set; }
	public long CreatorUserId { get; set; }
}
