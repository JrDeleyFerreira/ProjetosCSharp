﻿using System;

namespace GenAI.Domain.Entities.EmployeeSituations;

public class EmployeeSituation : BaseEntity
{
    public long EmployeeCode { get; set; }
    public string Name { get; set; }
    public string RhStatus { get; set; }
    public string PayrollStatus { get; set; }
    public DateTime AdmissionDate { get; set; }
    public string EmploymentContract { get; set; }
    public string PositionCode { get; set; }
    public string PositionDescription { get; set; }
    public string DepartmentCode { get; set; }
    public string DepartmentDescription { get; set; }
    public string CostCenter { get; set; }
    public string Manager { get; set; }
    public string EstablishmentCode { get; set; }
    public string EstablishmentCnpj { get; set; }
    public string WorkplaceCode { get; set; }
    public string WorkplaceDescription { get; set; }
    public string WorkplaceState { get; set; }
    public string WorkplaceCity { get; set; }
    public string Email { get; set; }
    public DateTime ReferenceTime { get; set; }
}
