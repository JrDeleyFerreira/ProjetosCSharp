﻿using Abp.Domain.Entities;
using System;

namespace GenAI.Domain.Entities.Tenants
{
    public class TenantUser : Entity
    {
        public TenantUser()
        {

        }
        public Guid TenantId { get; set; }
        public long UserId { get; set; }

        public virtual Tenant Tenant { get; set; }
        public virtual User User { get; set; }
    }
}
