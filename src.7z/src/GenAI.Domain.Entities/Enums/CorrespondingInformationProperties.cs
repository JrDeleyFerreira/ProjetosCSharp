﻿namespace GenAI.Domain.Entities.Enums;

public enum CorrespondingInformationProperties
{
	Key = 1,
	Name = 2,
	Supplier = 3,
	Responsible = 4,
	ContractExpirationDate = 5,
	Email = 6,
	EmployeeCode = 7,
	RhStatus = 8,
	PayrollStatus = 9,
	AdmissionDate = 10,
	EmploymentContract = 11,
	PositionCode = 12,
	PositionDescription = 13,
	DepartmentCode = 14,
	DepartmentDescription = 15,
	CostCenter = 16,
	Manager = 17,
	EstablishmentCode = 18,
	EstablishmentCnpj = 19,
	WorkplaceCode = 20,
	WorkplaceDescription = 21,
	WorkplaceState = 22,
	WorkplaceCity = 23,
	ReferenceTime = 24,
}
