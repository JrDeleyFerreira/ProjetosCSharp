﻿
namespace GenAI.Domain.Entities.Enums
{
    public enum GenderEnum
    {
        Male = 1,
        Female = 2
    }
}
