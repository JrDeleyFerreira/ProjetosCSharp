﻿namespace GenAI.Domain.Entities.Enums
{
    public enum EntityModelStatusEnum
    {
        ACTIVE,
        INACTIVE,
        DELETE
    }
}
