﻿using System.ComponentModel;

namespace GenAI.Domain.Entities.Enums;

public enum EntityTypes
{
	System = 1,

	Collaborator = 2,

	Employee = 3,
}
