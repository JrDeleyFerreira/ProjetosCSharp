﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace GenAI.Repositories.Migrations
{
    public partial class ModifiedConflictNameToSodMatrix : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Conflicts",
                schema: "dbo");

            migrationBuilder.CreateTable(
                name: "SodMatrices",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    FirstGroupId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    SecondGroupId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Comment = table.Column<string>(type: "nvarchar(250)", nullable: false),
                    IsActive = table.Column<bool>(type: "bit", nullable: false),
                    CreationTime = table.Column<DateTime>(type: "datetime", nullable: false),
                    CreatorUserId = table.Column<long>(type: "bigint", nullable: false),
                    DeletionTime = table.Column<DateTime>(type: "datetime", nullable: true),
                    DeletionUserId = table.Column<long>(type: "bigint", nullable: true),
                    LastModificationTime = table.Column<DateTime>(type: "datetime", nullable: true),
                    LastModifierUserId = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SodMatrices", x => x.Id);
                    table.ForeignKey(
                        name: "FK_SodMatrices_Groups_FirstGroupId",
                        column: x => x.FirstGroupId,
                        principalSchema: "dbo",
                        principalTable: "Groups",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_SodMatrices_Groups_SecondGroupId",
                        column: x => x.SecondGroupId,
                        principalSchema: "dbo",
                        principalTable: "Groups",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateIndex(
                name: "IX_SodMatrices_FirstGroupId",
                schema: "dbo",
                table: "SodMatrices",
                column: "FirstGroupId");

            migrationBuilder.CreateIndex(
                name: "IX_SodMatrices_SecondGroupId",
                schema: "dbo",
                table: "SodMatrices",
                column: "SecondGroupId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "SodMatrices",
                schema: "dbo");

            migrationBuilder.CreateTable(
                name: "Conflicts",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    FirstGroupId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    SecondGroupId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Comment = table.Column<string>(type: "nvarchar(250)", nullable: false),
                    CreationTime = table.Column<DateTime>(type: "datetime", nullable: false),
                    CreatorUserId = table.Column<long>(type: "bigint", nullable: false),
                    DeletionTime = table.Column<DateTime>(type: "datetime", nullable: true),
                    DeletionUserId = table.Column<long>(type: "bigint", nullable: true),
                    IsActive = table.Column<bool>(type: "bit", nullable: false),
                    LastModificationTime = table.Column<DateTime>(type: "datetime", nullable: true),
                    LastModifierUserId = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Conflicts", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Conflicts_Groups_FirstGroupId",
                        column: x => x.FirstGroupId,
                        principalSchema: "dbo",
                        principalTable: "Groups",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_Conflicts_Groups_SecondGroupId",
                        column: x => x.SecondGroupId,
                        principalSchema: "dbo",
                        principalTable: "Groups",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateIndex(
                name: "IX_Conflicts_FirstGroupId",
                schema: "dbo",
                table: "Conflicts",
                column: "FirstGroupId");

            migrationBuilder.CreateIndex(
                name: "IX_Conflicts_SecondGroupId",
                schema: "dbo",
                table: "Conflicts",
                column: "SecondGroupId");
        }
    }
}
