﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace GenAI.Repositories.Migrations
{
    public partial class AddRelationBetweenConflictAndGroup : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateIndex(
                name: "IX_Conflicts_FirstGroupId",
                schema: "dbo",
                table: "Conflicts",
                column: "FirstGroupId");

            migrationBuilder.CreateIndex(
                name: "IX_Conflicts_SecondGroupId",
                schema: "dbo",
                table: "Conflicts",
                column: "SecondGroupId");

            migrationBuilder.AddForeignKey(
                name: "FK_Conflicts_Groups_FirstGroupId",
                schema: "dbo",
                table: "Conflicts",
                column: "FirstGroupId",
                principalSchema: "dbo",
                principalTable: "Groups",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Conflicts_Groups_SecondGroupId",
                schema: "dbo",
                table: "Conflicts",
                column: "SecondGroupId",
                principalSchema: "dbo",
                principalTable: "Groups",
                principalColumn: "Id");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Conflicts_Groups_FirstGroupId",
                schema: "dbo",
                table: "Conflicts");

            migrationBuilder.DropForeignKey(
                name: "FK_Conflicts_Groups_SecondGroupId",
                schema: "dbo",
                table: "Conflicts");

            migrationBuilder.DropIndex(
                name: "IX_Conflicts_FirstGroupId",
                schema: "dbo",
                table: "Conflicts");

            migrationBuilder.DropIndex(
                name: "IX_Conflicts_SecondGroupId",
                schema: "dbo",
                table: "Conflicts");
        }
    }
}
