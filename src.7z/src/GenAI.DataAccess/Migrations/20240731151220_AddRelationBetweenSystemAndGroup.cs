﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace GenAI.Repositories.Migrations
{
    public partial class AddRelationBetweenSystemAndGroup : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateIndex(
                name: "IX_Groups_SystemId",
                schema: "dbo",
                table: "Groups",
                column: "SystemId");

            migrationBuilder.AddForeignKey(
                name: "FK_Groups_Systems_SystemId",
                schema: "dbo",
                table: "Groups",
                column: "SystemId",
                principalSchema: "dbo",
                principalTable: "Systems",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Groups_Systems_SystemId",
                schema: "dbo",
                table: "Groups");

            migrationBuilder.DropIndex(
                name: "IX_Groups_SystemId",
                schema: "dbo",
                table: "Groups");
        }
    }
}
