﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace GenAI.Repositories.Migrations
{
    public partial class ModifiedPositionTypeInEmployeeSituation : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "PositionType",
                schema: "dbo",
                table: "EmployeeSituations",
                newName: "EmploymentContract");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "EmploymentContract",
                schema: "dbo",
                table: "EmployeeSituations",
                newName: "PositionType");
        }
    }
}
