﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace GenAI.Repositories.Migrations
{
    public partial class Add_Employee_and_changes : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<DateTime>(
                name: "CreationTime",
                schema: "dbo",
                table: "Collaborators",
                type: "datetime",
                nullable: false,
                oldClrType: typeof(DateTime),
                oldType: "date");

            migrationBuilder.CreateTable(
                name: "Employees",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Code = table.Column<long>(type: "bigint", nullable: false),
                    Name = table.Column<string>(type: "nvarchar(255)", nullable: false),
                    RhStatus = table.Column<string>(type: "nvarchar(100)", nullable: false),
                    PayrollStatus = table.Column<string>(type: "nvarchar(100)", nullable: false),
                    ReferenceTime = table.Column<DateTime>(type: "datetime", nullable: false),
                    PositionType = table.Column<string>(type: "nvarchar(100)", nullable: false),
                    PositionCode = table.Column<string>(type: "nvarchar(100)", nullable: false),
                    PositionDescription = table.Column<string>(type: "nvarchar(255)", nullable: false),
                    DepartmentCode = table.Column<string>(type: "nvarchar(100)", nullable: false),
                    DepartmentDescription = table.Column<string>(type: "nvarchar(200)", nullable: false),
                    CostCenter = table.Column<string>(type: "nvarchar(100)", nullable: false),
                    Manager = table.Column<string>(type: "nvarchar(100)", nullable: false),
                    EstablishmentCode = table.Column<string>(type: "nvarchar(100)", nullable: false),
                    EstablishmentCnpj = table.Column<string>(type: "nvarchar(100)", nullable: false),
                    WorkplaceCode = table.Column<string>(type: "nvarchar(100)", nullable: false),
                    WorkplaceDescription = table.Column<string>(type: "nvarchar(255)", nullable: false),
                    WorkplaceState = table.Column<string>(type: "nvarchar(2)", nullable: false),
                    WorkplaceCity = table.Column<string>(type: "nvarchar(100)", nullable: false),
                    Email = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    IsActive = table.Column<bool>(type: "bit", nullable: false),
                    CreationTime = table.Column<DateTime>(type: "datetime", nullable: false),
                    CreatorUserId = table.Column<long>(type: "bigint", nullable: false),
                    DeletionTime = table.Column<DateTime>(type: "datetime", nullable: true),
                    DeletionUserId = table.Column<long>(type: "bigint", nullable: true),
                    LastModificationTime = table.Column<DateTime>(type: "datetime", nullable: true),
                    LastModifierUserId = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Employees", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "ImportedDocuments",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    EntityType = table.Column<string>(type: "nvarchar(50)", nullable: false),
                    FileName = table.Column<string>(type: "nvarchar(255)", nullable: false),
                    FileExtension = table.Column<string>(type: "nvarchar(10)", nullable: false),
                    CreationTime = table.Column<DateTime>(type: "datetime", nullable: false),
                    CreatorUserId = table.Column<long>(type: "bigint", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ImportedDocuments", x => x.Id);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Employees",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "ImportedDocuments",
                schema: "dbo");

            migrationBuilder.AlterColumn<DateTime>(
                name: "CreationTime",
                schema: "dbo",
                table: "Collaborators",
                type: "date",
                nullable: false,
                oldClrType: typeof(DateTime),
                oldType: "datetime");
        }
    }
}
