﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace GenAI.Repositories.Migrations
{
    public partial class Criacao_Layouts : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<Guid>(
                name: "FileLayoutId",
                schema: "dbo",
                table: "Systems",
                type: "uniqueidentifier",
                nullable: true);

            migrationBuilder.CreateTable(
                name: "CorrespondingInformations",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    EntityProperties = table.Column<byte>(type: "tinyint", nullable: false),
                    Description = table.Column<string>(type: "nvarchar(100)", nullable: false),
                    IsActive = table.Column<bool>(type: "bit", nullable: false),
                    CreationTime = table.Column<DateTime>(type: "datetime", nullable: false),
                    CreatorUserId = table.Column<long>(type: "bigint", nullable: false),
                    DeletionTime = table.Column<DateTime>(type: "datetime", nullable: true),
                    DeletionUserId = table.Column<long>(type: "bigint", nullable: true),
                    LastModificationTime = table.Column<DateTime>(type: "datetime", nullable: true),
                    LastModifierUserId = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CorrespondingInformations", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "EntityTypes",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Type = table.Column<byte>(type: "tinyint", nullable: false),
                    Description = table.Column<string>(type: "nvarchar(100)", nullable: false),
                    IsActive = table.Column<bool>(type: "bit", nullable: false),
                    CreationTime = table.Column<DateTime>(type: "datetime", nullable: false),
                    CreatorUserId = table.Column<long>(type: "bigint", nullable: false),
                    DeletionTime = table.Column<DateTime>(type: "datetime", nullable: true),
                    DeletionUserId = table.Column<long>(type: "bigint", nullable: true),
                    LastModificationTime = table.Column<DateTime>(type: "datetime", nullable: true),
                    LastModifierUserId = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_EntityTypes", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "EntityTypeCorrespondingInformations",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    EntityTypeId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    CorrespondingInformationId = table.Column<Guid>(type: "uniqueidentifier", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_EntityTypeCorrespondingInformations", x => x.Id);
                    table.ForeignKey(
                        name: "FK_EntityTypeCorrespondingInformations_CorrespondingInformations_CorrespondingInformationId",
                        column: x => x.CorrespondingInformationId,
                        principalSchema: "dbo",
                        principalTable: "CorrespondingInformations",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_EntityTypeCorrespondingInformations_EntityTypes_EntityTypeId",
                        column: x => x.EntityTypeId,
                        principalSchema: "dbo",
                        principalTable: "EntityTypes",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "FileLayouts",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    EntityTypeId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    SystemId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    IsActive = table.Column<bool>(type: "bit", nullable: false),
                    CreationTime = table.Column<DateTime>(type: "datetime", nullable: false),
                    CreatorUserId = table.Column<long>(type: "bigint", nullable: false),
                    DeletionTime = table.Column<DateTime>(type: "datetime", nullable: true),
                    DeletionUserId = table.Column<long>(type: "bigint", nullable: true),
                    LastModificationTime = table.Column<DateTime>(type: "datetime", nullable: true),
                    LastModifierUserId = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_FileLayouts", x => x.Id);
                    table.ForeignKey(
                        name: "FK_FileLayouts_EntityTypes_EntityTypeId",
                        column: x => x.EntityTypeId,
                        principalSchema: "dbo",
                        principalTable: "EntityTypes",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_FileLayouts_Systems_SystemId",
                        column: x => x.SystemId,
                        principalSchema: "dbo",
                        principalTable: "Systems",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "FileColumnLayouts",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    FileLayoutId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    Name = table.Column<string>(type: "nvarchar(255)", nullable: false),
                    Position = table.Column<int>(type: "int", nullable: false),
                    CorrespondingInformationId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    IsActive = table.Column<bool>(type: "bit", nullable: false),
                    CreationTime = table.Column<DateTime>(type: "datetime", nullable: false),
                    CreatorUserId = table.Column<long>(type: "bigint", nullable: false),
                    DeletionTime = table.Column<DateTime>(type: "datetime", nullable: true),
                    DeletionUserId = table.Column<long>(type: "bigint", nullable: true),
                    LastModificationTime = table.Column<DateTime>(type: "datetime", nullable: true),
                    LastModifierUserId = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_FileColumnLayouts", x => x.Id);
                    table.ForeignKey(
                        name: "FK_FileColumnLayouts_CorrespondingInformations_CorrespondingInformationId",
                        column: x => x.CorrespondingInformationId,
                        principalSchema: "dbo",
                        principalTable: "CorrespondingInformations",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_FileColumnLayouts_FileLayouts_FileLayoutId",
                        column: x => x.FileLayoutId,
                        principalSchema: "dbo",
                        principalTable: "FileLayouts",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateIndex(
                name: "IX_Systems_FileLayoutId",
                schema: "dbo",
                table: "Systems",
                column: "FileLayoutId");

            migrationBuilder.CreateIndex(
                name: "IX_EntityTypeCorrespondingInformations_CorrespondingInformationId",
                schema: "dbo",
                table: "EntityTypeCorrespondingInformations",
                column: "CorrespondingInformationId");

            migrationBuilder.CreateIndex(
                name: "IX_EntityTypeCorrespondingInformations_EntityTypeId",
                schema: "dbo",
                table: "EntityTypeCorrespondingInformations",
                column: "EntityTypeId");

            migrationBuilder.CreateIndex(
                name: "IX_FileColumnLayouts_CorrespondingInformationId",
                schema: "dbo",
                table: "FileColumnLayouts",
                column: "CorrespondingInformationId");

            migrationBuilder.CreateIndex(
                name: "IX_FileColumnLayouts_FileLayoutId",
                schema: "dbo",
                table: "FileColumnLayouts",
                column: "FileLayoutId");

            migrationBuilder.CreateIndex(
                name: "IX_FileLayouts_EntityTypeId",
                schema: "dbo",
                table: "FileLayouts",
                column: "EntityTypeId");

            migrationBuilder.CreateIndex(
                name: "IX_FileLayouts_SystemId",
                schema: "dbo",
                table: "FileLayouts",
                column: "SystemId");

            migrationBuilder.AddForeignKey(
                name: "FK_Systems_FileLayouts_FileLayoutId",
                schema: "dbo",
                table: "Systems",
                column: "FileLayoutId",
                principalSchema: "dbo",
                principalTable: "FileLayouts",
                principalColumn: "Id");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Systems_FileLayouts_FileLayoutId",
                schema: "dbo",
                table: "Systems");

            migrationBuilder.DropTable(
                name: "EntityTypeCorrespondingInformations",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "FileColumnLayouts",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "CorrespondingInformations",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "FileLayouts",
                schema: "dbo");

            migrationBuilder.DropTable(
                name: "EntityTypes",
                schema: "dbo");

            migrationBuilder.DropIndex(
                name: "IX_Systems_FileLayoutId",
                schema: "dbo",
                table: "Systems");

            migrationBuilder.DropColumn(
                name: "FileLayoutId",
                schema: "dbo",
                table: "Systems");
        }
    }
}
