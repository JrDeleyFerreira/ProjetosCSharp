﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace GenAI.Repositories.Migrations
{
    public partial class EmployeeSituations_and_adjustments : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "CostCenter",
                schema: "dbo",
                table: "Employees");

            migrationBuilder.DropColumn(
                name: "DepartmentCode",
                schema: "dbo",
                table: "Employees");

            migrationBuilder.DropColumn(
                name: "DepartmentDescription",
                schema: "dbo",
                table: "Employees");

            migrationBuilder.DropColumn(
                name: "EstablishmentCnpj",
                schema: "dbo",
                table: "Employees");

            migrationBuilder.DropColumn(
                name: "EstablishmentCode",
                schema: "dbo",
                table: "Employees");

            migrationBuilder.DropColumn(
                name: "Manager",
                schema: "dbo",
                table: "Employees");

            migrationBuilder.DropColumn(
                name: "PayrollStatus",
                schema: "dbo",
                table: "Employees");

            migrationBuilder.DropColumn(
                name: "PositionCode",
                schema: "dbo",
                table: "Employees");

            migrationBuilder.DropColumn(
                name: "PositionDescription",
                schema: "dbo",
                table: "Employees");

            migrationBuilder.DropColumn(
                name: "PositionType",
                schema: "dbo",
                table: "Employees");

            migrationBuilder.DropColumn(
                name: "RhStatus",
                schema: "dbo",
                table: "Employees");

            migrationBuilder.DropColumn(
                name: "WorkplaceCity",
                schema: "dbo",
                table: "Employees");

            migrationBuilder.DropColumn(
                name: "WorkplaceDescription",
                schema: "dbo",
                table: "Employees");

            migrationBuilder.DropColumn(
                name: "WorkplaceState",
                schema: "dbo",
                table: "Employees");

            migrationBuilder.RenameColumn(
                name: "WorkplaceCode",
                schema: "dbo",
                table: "Employees",
                newName: "Registration");

            migrationBuilder.RenameColumn(
                name: "ReferenceTime",
                schema: "dbo",
                table: "Employees",
                newName: "AdmissionDate");

            migrationBuilder.RenameColumn(
                name: "Code",
                schema: "dbo",
                table: "Employees",
                newName: "EmployeeCode");

            migrationBuilder.AlterColumn<string>(
                name: "Email",
                schema: "dbo",
                table: "Employees",
                type: "nvarchar(100)",
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "nvarchar(100)",
                oldNullable: true);

            migrationBuilder.AddColumn<string>(
                name: "EmploymentContract",
                schema: "dbo",
                table: "Employees",
                type: "nvarchar(150)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AlterColumn<DateTime>(
                name: "ContractExpirationDate",
                schema: "dbo",
                table: "Collaborators",
                type: "date",
                nullable: true,
                oldClrType: typeof(DateTime),
                oldType: "date");

            migrationBuilder.CreateTable(
                name: "EmployeeSituations",
                schema: "dbo",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    EmployeeCode = table.Column<long>(type: "bigint", nullable: false),
                    Name = table.Column<string>(type: "nvarchar(255)", nullable: false),
                    RhStatus = table.Column<string>(type: "nvarchar(100)", nullable: false),
                    PayrollStatus = table.Column<string>(type: "nvarchar(100)", nullable: false),
                    AdmissionDate = table.Column<DateTime>(type: "datetime", nullable: false),
                    PositionType = table.Column<string>(type: "nvarchar(100)", nullable: false),
                    PositionCode = table.Column<string>(type: "nvarchar(100)", nullable: false),
                    PositionDescription = table.Column<string>(type: "nvarchar(255)", nullable: false),
                    DepartmentCode = table.Column<string>(type: "nvarchar(100)", nullable: false),
                    DepartmentDescription = table.Column<string>(type: "nvarchar(200)", nullable: false),
                    CostCenter = table.Column<string>(type: "nvarchar(100)", nullable: false),
                    Manager = table.Column<string>(type: "nvarchar(100)", nullable: false),
                    EstablishmentCode = table.Column<string>(type: "nvarchar(100)", nullable: false),
                    EstablishmentCnpj = table.Column<string>(type: "nvarchar(100)", nullable: false),
                    WorkplaceCode = table.Column<string>(type: "nvarchar(100)", nullable: false),
                    WorkplaceDescription = table.Column<string>(type: "nvarchar(255)", nullable: false),
                    WorkplaceState = table.Column<string>(type: "nvarchar(2)", nullable: false),
                    WorkplaceCity = table.Column<string>(type: "nvarchar(100)", nullable: false),
                    Email = table.Column<string>(type: "nvarchar(100)", nullable: false),
                    ReferenceTime = table.Column<DateTime>(type: "datetime", nullable: false),
                    IsActive = table.Column<bool>(type: "bit", nullable: false),
                    CreationTime = table.Column<DateTime>(type: "datetime", nullable: false),
                    CreatorUserId = table.Column<long>(type: "bigint", nullable: false),
                    DeletionTime = table.Column<DateTime>(type: "datetime", nullable: true),
                    DeletionUserId = table.Column<long>(type: "bigint", nullable: true),
                    LastModificationTime = table.Column<DateTime>(type: "datetime", nullable: true),
                    LastModifierUserId = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_EmployeeSituations", x => x.Id);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "EmployeeSituations",
                schema: "dbo");

            migrationBuilder.DropColumn(
                name: "EmploymentContract",
                schema: "dbo",
                table: "Employees");

            migrationBuilder.RenameColumn(
                name: "Registration",
                schema: "dbo",
                table: "Employees",
                newName: "WorkplaceCode");

            migrationBuilder.RenameColumn(
                name: "EmployeeCode",
                schema: "dbo",
                table: "Employees",
                newName: "Code");

            migrationBuilder.RenameColumn(
                name: "AdmissionDate",
                schema: "dbo",
                table: "Employees",
                newName: "ReferenceTime");

            migrationBuilder.AlterColumn<string>(
                name: "Email",
                schema: "dbo",
                table: "Employees",
                type: "nvarchar(100)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(100)");

            migrationBuilder.AddColumn<string>(
                name: "CostCenter",
                schema: "dbo",
                table: "Employees",
                type: "nvarchar(100)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "DepartmentCode",
                schema: "dbo",
                table: "Employees",
                type: "nvarchar(100)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "DepartmentDescription",
                schema: "dbo",
                table: "Employees",
                type: "nvarchar(200)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "EstablishmentCnpj",
                schema: "dbo",
                table: "Employees",
                type: "nvarchar(100)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "EstablishmentCode",
                schema: "dbo",
                table: "Employees",
                type: "nvarchar(100)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "Manager",
                schema: "dbo",
                table: "Employees",
                type: "nvarchar(100)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "PayrollStatus",
                schema: "dbo",
                table: "Employees",
                type: "nvarchar(100)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "PositionCode",
                schema: "dbo",
                table: "Employees",
                type: "nvarchar(100)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "PositionDescription",
                schema: "dbo",
                table: "Employees",
                type: "nvarchar(255)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "PositionType",
                schema: "dbo",
                table: "Employees",
                type: "nvarchar(100)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "RhStatus",
                schema: "dbo",
                table: "Employees",
                type: "nvarchar(100)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "WorkplaceCity",
                schema: "dbo",
                table: "Employees",
                type: "nvarchar(100)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "WorkplaceDescription",
                schema: "dbo",
                table: "Employees",
                type: "nvarchar(255)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "WorkplaceState",
                schema: "dbo",
                table: "Employees",
                type: "nvarchar(2)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AlterColumn<DateTime>(
                name: "ContractExpirationDate",
                schema: "dbo",
                table: "Collaborators",
                type: "date",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified),
                oldClrType: typeof(DateTime),
                oldType: "date",
                oldNullable: true);
        }
    }
}
