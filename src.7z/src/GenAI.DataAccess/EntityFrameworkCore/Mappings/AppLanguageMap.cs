﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenAI.Repositories.EntityFrameworkCore.Mappings
{
    public class AppLanguageMap : IEntityTypeConfiguration<Domain.Entities.Langague.AppLanguage>
    {
        public void Configure(EntityTypeBuilder<Domain.Entities.Langague.AppLanguage> builder)
        {
            builder.HasKey(n => n.Id);

            builder.Property(n => n.Name).HasColumnType("nvarchar(10)");

            builder.Property(n => n.DisplayName).HasColumnType("nvarchar(64)");

            builder.Property(n => n.IsDisabledDocument).HasColumnType("bit");

            builder.ToTable("AbpLanguages", "dbo");
        }
    }
}
