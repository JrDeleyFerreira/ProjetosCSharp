﻿using GenAI.Domain.Entities.Layouts;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace GenAI.Repositories.EntityFrameworkCore.Mappings;

public class EntityTypeMap : IEntityTypeConfiguration<EntityType>
{
	public void Configure(EntityTypeBuilder<EntityType> builder)
	{
		builder.ToTable("EntityTypes", "dbo");

		builder.HasKey(x => x.Id);

		builder.Property(x => x.Description).HasColumnType("nvarchar(100)").IsRequired();
		builder.Property(x => x.Type).HasColumnType("tinyint").IsRequired();

		builder.Property(x => x.IsActive).HasColumnType("bit").IsRequired();
		builder.Property(x => x.CreationTime).HasColumnType("datetime").IsRequired();
		builder.Property(x => x.CreatorUserId).HasColumnType("bigint").IsRequired();
		builder.Property(x => x.DeletionTime).HasColumnType("datetime");
		builder.Property(x => x.DeletionUserId).HasColumnType("bigint");
		builder.Property(x => x.LastModificationTime).HasColumnType("datetime");
		builder.Property(x => x.LastModifierUserId).HasColumnType("bigint");
	}
}
