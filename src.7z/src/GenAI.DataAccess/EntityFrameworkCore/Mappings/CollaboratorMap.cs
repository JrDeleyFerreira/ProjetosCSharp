﻿using GenAI.Domain.Entities.Collaborators;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace GenAI.Repositories.EntityFrameworkCore.Mappings;

public class CollaboratorMap : IEntityTypeConfiguration<Collaborator>
{
	public void Configure(EntityTypeBuilder<Collaborator> builder)
	{
		builder.ToTable("Collaborators", "dbo");

		builder.HasKey(x => x.Id);

		builder.Property(x => x.Key).HasColumnType("nvarchar(50)").IsRequired();
		builder.Property(x => x.Name).HasColumnType("nvarchar(200)").IsRequired();
		builder.Property(x => x.Supplier).HasColumnType("nvarchar(150)").IsRequired();
		builder.Property(x => x.Responsible).HasColumnType("nvarchar(150)").IsRequired();
		builder.Property(x => x.ContractExpirationDate).HasColumnType("date");
		builder.Property(x => x.Email).HasColumnType("nvarchar(300)");

		builder.Property(x => x.IsActive).HasColumnType("bit").IsRequired();
		builder.Property(x => x.CreationTime).HasColumnType("datetime").IsRequired();
		builder.Property(x => x.CreatorUserId).HasColumnType("bigint").IsRequired();
		builder.Property(x => x.DeletionTime).HasColumnType("datetime");
		builder.Property(x => x.DeletionUserId).HasColumnType("bigint");
		builder.Property(x => x.LastModificationTime).HasColumnType("datetime");
		builder.Property(x => x.LastModifierUserId).HasColumnType("bigint");
	}
}
