﻿using GenAI.Domain.Entities.Employees;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace GenAI.Repositories.EntityFrameworkCore.Mappings;

public class EmployeeMap : IEntityTypeConfiguration<Employee>
{
	public void Configure(EntityTypeBuilder<Employee> builder)
	{
		builder.ToTable("Employees", "dbo");

		builder.HasKey(x => x.Id);

		builder.Property(x => x.EmployeeCode).HasColumnType("bigint").IsRequired();
		builder.Property(x => x.Registration).HasColumnType("nvarchar(100)").IsRequired();
		builder.Property(x => x.Name).HasColumnType("nvarchar(255)").IsRequired();
		builder.Property(x => x.AdmissionDate).HasColumnType("datetime").IsRequired();
		builder.Property(x => x.EmploymentContract).HasColumnType("nvarchar(150)").IsRequired();
		builder.Property(x => x.Email).HasColumnType("nvarchar(100)").IsRequired();

		builder.Property(x => x.IsActive).HasColumnType("bit").IsRequired();
		builder.Property(x => x.CreationTime).HasColumnType("datetime").IsRequired();
		builder.Property(x => x.CreatorUserId).HasColumnType("bigint").IsRequired();
		builder.Property(x => x.DeletionTime).HasColumnType("datetime");
		builder.Property(x => x.DeletionUserId).HasColumnType("bigint");
		builder.Property(x => x.LastModificationTime).HasColumnType("datetime");
		builder.Property(x => x.LastModifierUserId).HasColumnType("bigint");
	}
}
