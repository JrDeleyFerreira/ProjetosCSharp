﻿using GenAI.Domain.Entities.Layouts;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace GenAI.Repositories.EntityFrameworkCore.Mappings;

public class FileLayoutMap : IEntityTypeConfiguration<FileLayout>
{
	public void Configure(EntityTypeBuilder<FileLayout> builder)
	{
		builder.ToTable("FileLayouts", "dbo");

		builder.HasKey(x => x.Id);

		builder.Property(x => x.SystemId).HasColumnType("uniqueidentifier");
		builder.Property(x => x.EntityTypeId).HasColumnType("uniqueidentifier").IsRequired();

		builder.HasOne(e => e.System)
			.WithMany()
			.HasForeignKey(e => e.SystemId)
			.OnDelete(DeleteBehavior.NoAction);

		builder.HasOne(e => e.EntityType)
			.WithMany()
			.HasForeignKey(e => e.EntityTypeId)
			.OnDelete(DeleteBehavior.NoAction);

		builder.Property(x => x.IsActive).HasColumnType("bit").IsRequired();
		builder.Property(x => x.CreationTime).HasColumnType("datetime").IsRequired();
		builder.Property(x => x.CreatorUserId).HasColumnType("bigint").IsRequired();
		builder.Property(x => x.DeletionTime).HasColumnType("datetime");
		builder.Property(x => x.DeletionUserId).HasColumnType("bigint");
		builder.Property(x => x.LastModificationTime).HasColumnType("datetime");
		builder.Property(x => x.LastModifierUserId).HasColumnType("bigint");
	}
}
