﻿using GenAI.Domain.Entities.Layouts;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace GenAI.Repositories.EntityFrameworkCore.Mappings;

public class EntityTypeCorrespondingInformationMap : IEntityTypeConfiguration<EntityTypeCorrespondingInformation>
{
	public void Configure(EntityTypeBuilder<EntityTypeCorrespondingInformation> builder)
	{
		builder.ToTable("EntityTypeCorrespondingInformations", "dbo");

		builder.HasKey(x => x.Id);

		builder.Property(x => x.EntityTypeId).HasColumnType("uniqueidentifier").IsRequired();
		builder.Property(x => x.CorrespondingInformationId).HasColumnType("uniqueidentifier").IsRequired();

		builder.HasOne(e => e.EntityType)
			.WithMany()
			.HasForeignKey(e => e.EntityTypeId)
			.OnDelete(DeleteBehavior.NoAction);

		builder.HasOne(e => e.CorrespondingInformation)
			.WithMany()
			.HasForeignKey(e => e.CorrespondingInformationId)
			.OnDelete(DeleteBehavior.NoAction);
	}
}
