﻿using GenAI.Domain.Entities.Layouts;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace GenAI.Repositories.EntityFrameworkCore.Mappings;

public class CorrespondingInformationMap : IEntityTypeConfiguration<CorrespondingInformation>
{
	public void Configure(EntityTypeBuilder<CorrespondingInformation> builder)
	{
		builder.ToTable("CorrespondingInformations", "dbo");

		builder.HasKey(x => x.Id);

		builder.Property(x => x.Description).HasColumnType("nvarchar(100)").IsRequired();
		builder.Property(x => x.EntityProperties).HasColumnType("tinyint").IsRequired();

		builder.Property(x => x.IsActive).HasColumnType("bit").IsRequired();
		builder.Property(x => x.CreationTime).HasColumnType("datetime").IsRequired();
		builder.Property(x => x.CreatorUserId).HasColumnType("bigint").IsRequired();
		builder.Property(x => x.DeletionTime).HasColumnType("datetime");
		builder.Property(x => x.DeletionUserId).HasColumnType("bigint");
		builder.Property(x => x.LastModificationTime).HasColumnType("datetime");
		builder.Property(x => x.LastModifierUserId).HasColumnType("bigint");
	}
}
