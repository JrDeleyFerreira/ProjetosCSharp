﻿using GenAI.Domain.Entities.Systems;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace GenAI.Repositories.EntityFrameworkCore.Mappings
{
    public class SystemGroupMap : IEntityTypeConfiguration<SystemGroup>
    {
        public void Configure(EntityTypeBuilder<SystemGroup> builder)
        {
            builder.HasKey(n => n.Id);

            builder.Property(n => n.Description).HasColumnType("nvarchar(150)").IsRequired();
            builder.Property(n => n.SystemId).HasColumnType("uniqueidentifier").IsRequired();

            builder.Property(n => n.IsActive).HasColumnType("bit").IsRequired();
            builder.Property(n => n.CreationTime).HasColumnType("datetime").IsRequired();
            builder.Property(n => n.CreatorUserId).HasColumnType("bigint").IsRequired();
            builder.Property(n => n.DeletionTime).HasColumnType("datetime");
            builder.Property(n => n.DeletionUserId).HasColumnType("bigint");
            builder.Property(n => n.LastModificationTime).HasColumnType("datetime");
            builder.Property(n => n.LastModifierUserId).HasColumnType("bigint");

            builder.HasOne(x => x.System)
                .WithMany(x => x.Groups)
                .HasForeignKey(x => x.SystemId);

            builder.ToTable("Groups", "dbo");
        }
    }
}
