﻿using GenAI.Domain.Entities.ApiKey;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.EntityFrameworkCore;

namespace GenAI.Repositories.EntityFrameworkCore.Mappings;

public class UserApiKeyMap : IEntityTypeConfiguration<UserApiKey>
{
    public void Configure(EntityTypeBuilder<UserApiKey> builder)
    {
        builder.HasKey(n => n.Id);
        builder.Property(n => n.Key).HasColumnType("varchar(255)").IsRequired();
        builder.Property(n => n.Expiration).HasColumnType("date").IsRequired();

        builder.HasOne(n => n.User).WithMany(n => n.UserApiKeys).HasForeignKey(n => n.UserId).IsRequired();

        builder.ToTable("UserApiKeys", GenAIDbContextConfigurer.GENAI_SCHEMA);

    }
}