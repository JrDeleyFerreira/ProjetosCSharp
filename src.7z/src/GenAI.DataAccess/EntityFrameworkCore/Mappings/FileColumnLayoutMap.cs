﻿using GenAI.Domain.Entities.Layouts;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace GenAI.Repositories.EntityFrameworkCore.Mappings;

public class FileColumnLayoutMap : IEntityTypeConfiguration<FileColumnLayout>
{
	public void Configure(EntityTypeBuilder<FileColumnLayout> builder)
	{
		builder.ToTable("FileColumnLayouts", "dbo");

		builder.HasKey(x => x.Id);

		builder.Property(x => x.FileLayoutId).HasColumnType("uniqueidentifier").IsRequired();
		builder.Property(x => x.CorrespondingInformationId).HasColumnType("uniqueidentifier").IsRequired();
		builder.Property(x => x.Name).HasColumnType("nvarchar(255)").IsRequired();
		builder.Property(x => x.Position).HasColumnType("int").IsRequired();

		builder.HasOne(e => e.FileLayout)
			.WithMany(e => e.FileColumns)
			.HasForeignKey(e => e.FileLayoutId)
			.OnDelete(DeleteBehavior.NoAction);

		builder.HasOne(e => e.CorrespondingInformation)
			.WithMany()
			.HasForeignKey(e => e.CorrespondingInformationId)
			.OnDelete(DeleteBehavior.NoAction);

		builder.Property(x => x.IsActive).HasColumnType("bit").IsRequired();
		builder.Property(x => x.CreationTime).HasColumnType("datetime").IsRequired();
		builder.Property(x => x.CreatorUserId).HasColumnType("bigint").IsRequired();
		builder.Property(x => x.DeletionTime).HasColumnType("datetime");
		builder.Property(x => x.DeletionUserId).HasColumnType("bigint");
		builder.Property(x => x.LastModificationTime).HasColumnType("datetime");
		builder.Property(x => x.LastModifierUserId).HasColumnType("bigint");
	}
}
