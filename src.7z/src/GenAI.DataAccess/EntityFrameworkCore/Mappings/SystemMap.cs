﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace GenAI.Repositories.EntityFrameworkCore.Mappings
{
    public class SystemMap : IEntityTypeConfiguration<Domain.Entities.Systems.BusinessSystem>
    {
        public void Configure(EntityTypeBuilder<Domain.Entities.Systems.BusinessSystem> builder)
        {
            builder.HasKey(n => n.Id);

            builder.Property(n => n.Description).HasColumnType("nvarchar(150)").IsRequired();

            builder.Property(n => n.IsActive).HasColumnType("bit").IsRequired();
            builder.Property(n => n.CreationTime).HasColumnType("datetime").IsRequired();
            builder.Property(n => n.CreatorUserId).HasColumnType("bigint").IsRequired();
            builder.Property(n => n.DeletionTime).HasColumnType("datetime");
            builder.Property(n => n.DeletionUserId).HasColumnType("bigint");
            builder.Property(n => n.LastModificationTime).HasColumnType("datetime");
            builder.Property(n => n.LastModifierUserId).HasColumnType("bigint");

            builder.ToTable("Systems", "dbo");
        }
    }
}
