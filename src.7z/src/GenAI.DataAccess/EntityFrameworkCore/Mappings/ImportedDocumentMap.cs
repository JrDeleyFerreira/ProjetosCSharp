﻿using GenAI.Domain.Entities.ImportedDocuments;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace GenAI.Repositories.EntityFrameworkCore.Mappings;

public class ImportedDocumentMap : IEntityTypeConfiguration<ImportedDocument>
{
	public void Configure(EntityTypeBuilder<ImportedDocument> builder)
	{
		builder.ToTable("ImportedDocuments", "dbo");

		builder.HasKey(x => x.Id);

		builder.Property(x => x.EntityType).HasColumnType("nvarchar(50)").IsRequired();
		builder.Property(x => x.FileName).HasColumnType("nvarchar(255)").IsRequired();
		builder.Property(x => x.FileExtension).HasColumnType("nvarchar(10)").IsRequired();
		builder.Property(x => x.CreationTime).HasColumnType("datetime").IsRequired();
		builder.Property(x => x.CreatorUserId).HasColumnType("bigint").IsRequired();
	}
}
