﻿using GenAI.Domain.Entities.EmployeeSituations;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace GenAI.Repositories.EntityFrameworkCore.Mappings;

public class EmployeeSituationMap : IEntityTypeConfiguration<EmployeeSituation>
{
	public void Configure(EntityTypeBuilder<EmployeeSituation> builder)
	{
		builder.ToTable("EmployeeSituations", "dbo");

		builder.HasKey(x => x.Id);

		builder.Property(x => x.EmployeeCode).HasColumnType("bigint").IsRequired();
		builder.Property(x => x.Name).HasColumnType("nvarchar(255)").IsRequired();
		builder.Property(x => x.RhStatus).HasColumnType("nvarchar(100)").IsRequired();
		builder.Property(x => x.PayrollStatus).HasColumnType("nvarchar(100)").IsRequired();
		builder.Property(x => x.AdmissionDate).HasColumnType("datetime").IsRequired();
		builder.Property(x => x.EmploymentContract).HasColumnType("nvarchar(100)").IsRequired();
		builder.Property(x => x.PositionCode).HasColumnType("nvarchar(100)").IsRequired();
		builder.Property(x => x.PositionDescription).HasColumnType("nvarchar(255)").IsRequired();
		builder.Property(x => x.DepartmentCode).HasColumnType("nvarchar(100)").IsRequired();
		builder.Property(x => x.DepartmentDescription).HasColumnType("nvarchar(200)").IsRequired();
		builder.Property(x => x.CostCenter).HasColumnType("nvarchar(100)").IsRequired();
		builder.Property(x => x.Manager).HasColumnType("nvarchar(100)").IsRequired();
		builder.Property(x => x.EstablishmentCode).HasColumnType("nvarchar(100)").IsRequired();
		builder.Property(x => x.EstablishmentCnpj).HasColumnType("nvarchar(100)").IsRequired();
		builder.Property(x => x.WorkplaceCode).HasColumnType("nvarchar(100)").IsRequired();
		builder.Property(x => x.WorkplaceDescription).HasColumnType("nvarchar(255)").IsRequired();
		builder.Property(x => x.WorkplaceState).HasColumnType("nvarchar(2)").IsRequired();
		builder.Property(x => x.WorkplaceCity).HasColumnType("nvarchar(100)").IsRequired();
		builder.Property(x => x.Email).HasColumnType("nvarchar(100)").IsRequired();
		builder.Property(x => x.ReferenceTime).HasColumnType("datetime").IsRequired();

		builder.Property(x => x.IsActive).HasColumnType("bit").IsRequired();
		builder.Property(x => x.CreationTime).HasColumnType("datetime").IsRequired();
		builder.Property(x => x.CreatorUserId).HasColumnType("bigint").IsRequired();
		builder.Property(x => x.DeletionTime).HasColumnType("datetime");
		builder.Property(x => x.DeletionUserId).HasColumnType("bigint");
		builder.Property(x => x.LastModificationTime).HasColumnType("datetime");
		builder.Property(x => x.LastModifierUserId).HasColumnType("bigint");
	}
}
