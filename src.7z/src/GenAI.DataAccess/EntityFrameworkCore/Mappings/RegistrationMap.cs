﻿using GenAI.Domain.Entities.Registrations;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace GenAI.Repositories.EntityFrameworkCore.Mappings;

public class RegistrationMap : IEntityTypeConfiguration<Registration>
{
	public void Configure(EntityTypeBuilder<Registration> builder)
	{
		builder.ToTable("Registrations", "dbo");

		builder.HasKey(n => n.Id);

		builder.Property(n => n.ValiaRegistration).HasColumnType("nvarchar(100)").IsRequired();
		builder.Property(n => n.OfficialRegistration).HasColumnType("nvarchar(100)").IsRequired();
		builder.Property(n => n.IsActive).HasColumnType("bit").IsRequired();
		builder.Property(n => n.CreationTime).HasColumnType("datetime").IsRequired();
		builder.Property(n => n.CreatorUserId).HasColumnType("bigint").IsRequired();
		builder.Property(n => n.DeletionTime).HasColumnType("datetime");
		builder.Property(n => n.DeletionUserId).HasColumnType("bigint");
		builder.Property(n => n.LastModificationTime).HasColumnType("datetime");
		builder.Property(n => n.LastModifierUserId).HasColumnType("bigint");
	}
}
