﻿using GenAI.Domain.Entities.Tokens;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace GenAI.Repositories.EntityFrameworkCore.Mappings
{
    public class TokenMap : IEntityTypeConfiguration<Token>
    {
        public void Configure(EntityTypeBuilder<Token> builder)
        {
            builder.Property(n => n.TokenId).HasColumnType("varchar(max)").IsRequired();
            builder.Property(n => n.Created).HasColumnType("datetime").IsRequired();

            builder.HasOne(n => n.User).WithMany(n => n.Tokens).HasForeignKey(n => n.UserId);

            builder.HasKey(n => n.Id);

            builder.ToTable("Tokens", "dbo");
        }
    }
}