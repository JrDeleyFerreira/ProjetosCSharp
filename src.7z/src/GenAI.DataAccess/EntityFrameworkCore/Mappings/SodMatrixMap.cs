﻿using GenAI.Domain.Entities.Systems;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace GenAI.Repositories.EntityFrameworkCore.Mappings
{
    public class SodMatrixMap : IEntityTypeConfiguration<SodMatrix>
    {
        public void Configure(EntityTypeBuilder<SodMatrix> builder)
        {
            builder.HasKey(n => n.Id);

            builder.Property(n => n.FirstGroupId).HasColumnType("uniqueidentifier").IsRequired();
            builder.Property(n => n.SecondGroupId).HasColumnType("uniqueidentifier").IsRequired();
            builder.Property(n => n.Comment).HasColumnType("nvarchar(250)").IsRequired();

            builder.Property(n => n.IsActive).HasColumnType("bit").IsRequired();
            builder.Property(n => n.CreationTime).HasColumnType("datetime").IsRequired();
            builder.Property(n => n.CreatorUserId).HasColumnType("bigint").IsRequired();
            builder.Property(n => n.DeletionTime).HasColumnType("datetime");
            builder.Property(n => n.DeletionUserId).HasColumnType("bigint");
            builder.Property(n => n.LastModificationTime).HasColumnType("datetime");
            builder.Property(n => n.LastModifierUserId).HasColumnType("bigint");

            builder.HasOne(e => e.FirstGroup)
               .WithMany()
               .HasForeignKey(e => e.FirstGroupId)
               .OnDelete(DeleteBehavior.NoAction);

            builder.HasOne(e => e.SecondGroup)
               .WithMany()
               .HasForeignKey(e => e.SecondGroupId)
               .OnDelete(DeleteBehavior.NoAction);

            builder.ToTable("SodMatrices", "dbo");
        }
    }
}
