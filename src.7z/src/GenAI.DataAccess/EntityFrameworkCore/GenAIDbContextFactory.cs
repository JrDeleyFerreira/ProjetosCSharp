﻿using GenAI.Crosscutting.Infra.Settings;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;

namespace GenAI.Repositories.EntityFrameworkCore
{
    /* This class is needed to run "dotnet ef ..." commands from command line on development. Not used anywhere else */
    public class GenAIDbContextFactory : IDesignTimeDbContextFactory<GenAIDbContext>
    {
        public GenAIDbContext CreateDbContext(string[] args)
        {
            var builder = new DbContextOptionsBuilder<GenAIDbContext>();

            GenAIDbContextConfigurer.Configure(builder, GenAISettings.ConnectionStringsDefault);

            return new GenAIDbContext(builder.Options);
        }
    }
}


