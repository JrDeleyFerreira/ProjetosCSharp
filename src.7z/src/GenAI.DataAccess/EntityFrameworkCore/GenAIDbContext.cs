﻿using Abp.Zero.EntityFrameworkCore;
using GenAI.Domain.Entities;
using GenAI.Domain.Entities.ApiKey;
using GenAI.Domain.Entities.Collaborators;
using GenAI.Domain.Entities.Employees;
using GenAI.Domain.Entities.EmployeeSituations;
using GenAI.Domain.Entities.ImportedDocuments;
using GenAI.Domain.Entities.Langague;
using GenAI.Domain.Entities.Layouts;
using GenAI.Domain.Entities.Registrations;
using GenAI.Domain.Entities.Systems;
using GenAI.Domain.Entities.Tenants;
using GenAI.Domain.Entities.Tokens;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;
using System.Reflection;

namespace GenAI.Repositories.EntityFrameworkCore
{
    public class GenAIDbContext : AbpZeroDbContext<Tenant, Role, User, GenAIDbContext>
    {
        public DbSet<Token> Tokens { get; set; }
        public DbSet<TenantUser> TenantUsers { get; set; }
        public DbSet<AppLanguage> AppLanguages { get; set; }        
        public DbSet<UserApiKey> UserApiKeys { get; set; }
        public DbSet<BusinessSystem> Systems { get; set; }
        public DbSet<SystemGroup> Groups { get; set; }
        public DbSet<SodMatrix> Conflicts { get; set; }
        public DbSet<Registration> Registrations { get; set; }
        public DbSet<Collaborator> Collaborators { get; set; }
		public DbSet<ImportedDocument> ImportedDocuments { get; set; }
		public DbSet<EmployeeSituation> EmployeeSituations { get; set; }
		public DbSet<Employee> Employees { get; set; }
		public DbSet<EntityType> EntityTypes { get; set; }
		public DbSet<CorrespondingInformation> CorrespondingInformation { get; set; }
		public DbSet<FileLayout> FileLayouts { get; set; }
		public DbSet<FileColumnLayout> FileColumnLayouts { get; set; }
		public DbSet<EntityTypeCorrespondingInformation> EntityTypeCorrespondingInformations { get; set; }


        public GenAIDbContext(DbContextOptions<GenAIDbContext> options) : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            RegisterEntityMaps(modelBuilder);
            base.OnModelCreating(modelBuilder);
        }

        private static void RegisterEntityMaps(ModelBuilder modelBuilder)
        {
            var typesToRegister =
                from type in Assembly.GetExecutingAssembly().GetTypes()
                where type.IsClass && !type.IsAbstract && !type.ContainsGenericParameters
                      && type.GetInterfaces().Any(i => i.IsConstructedGenericType && i.GetGenericTypeDefinition() == typeof(IEntityTypeConfiguration<>))
                select type;
            foreach (Type type in typesToRegister)
            {
                dynamic configInstance = Activator.CreateInstance(type);
                modelBuilder.ApplyConfiguration(configInstance);
            }
        }
    }
}