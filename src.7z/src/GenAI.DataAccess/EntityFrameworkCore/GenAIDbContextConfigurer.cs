﻿using Microsoft.EntityFrameworkCore;
using System.Data.Common;

namespace GenAI.Repositories.EntityFrameworkCore
{
    public static class GenAIDbContextConfigurer
    {
        public const string DBO_SCHEMA = "dbo";
        public const string GENAI_SCHEMA = "genai";
        public const string RPA_SCHEMA = "genai";
        public const string MATURITY_SCHEMA = "maturity";

        public static void Configure(DbContextOptionsBuilder<GenAIDbContext> builder, string connectionString)
        {
#if DEBUG
            builder.UseSqlServer(connectionString);
            //builder.UseSqlServer("Server=AVAPC-752189113\\SQLEXPRESS;Initial Catalog=MatrizSoD;Persist Security Info=False;User ID=matrizsod;Password=matrizsodavengers;MultipleActiveResultSets=False;Encrypt=False;TrustServerCertificate=False;Connection Timeout=30;");
#else
            builder.UseSqlServer(connectionString);
#endif
        }

        public static void Configure(DbContextOptionsBuilder<GenAIDbContext> builder, DbConnection connection)
        {
            builder.UseSqlServer(connection);
        }
    }
}


