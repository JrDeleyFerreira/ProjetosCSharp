﻿using ImportarPlanilhaExcelProjeto.Data;
using ImportarPlanilhaExcelProjeto.Models;
using IronXL;

namespace ImportarPlanilhaExcelProjeto.Services;

public class PlanilhaService : IPlanilhaService
{
	private readonly AppDbContext _context;

	public PlanilhaService(AppDbContext context) => _context = context;

	public List<ProdutoViewModel>? LerPlanilha(MemoryStream stream, string fileExtension)
	{
		try
		{
			var resposta = new List<ProdutoViewModel>();

			var workBook = new WorkBook(stream);
			var workSheet = workBook.WorkSheets[0];
			var rowCount = workSheet.RowCount;

			for (int row = 1; row < rowCount; row++)
			{
				var recoveredLine = workSheet.GetRow(row).Select(c => c.Text).ToList();

				if (recoveredLine[0].Equals(string.Empty) || recoveredLine[3].Equals(string.Empty))
					continue;

				var produto = new ProdutoViewModel
				{
					Id = 0,
					Nome = recoveredLine[0],
					Valor = float.Parse(recoveredLine[1]),
					Quantidade = int.Parse(recoveredLine[2]),
					Marca = recoveredLine[3]
				};

				resposta.Add(produto);
			}

			return resposta;
		}
		catch (Exception ex)
		{
			throw new Exception(ex.Message);
		}
	}

	public MemoryStream LerSttream(IFormFile formImport)
	{
		using var stream = new MemoryStream();
		formImport?.CopyTo(stream);
		var listaBytes = stream.ToArray();
		return new MemoryStream(listaBytes);
	}

	public void SalvarProdutos(List<ProdutoViewModel> produtos)
	{
		try
		{
			foreach (var produto in produtos)
			{
				_context.Add(produto);
				_context.SaveChanges();
			}
		}
		catch (Exception ex)
		{
			throw new Exception(ex.Message);
		}
	}
}
