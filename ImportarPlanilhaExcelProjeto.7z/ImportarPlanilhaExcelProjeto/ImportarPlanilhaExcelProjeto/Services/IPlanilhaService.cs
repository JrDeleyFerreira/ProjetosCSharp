﻿using ImportarPlanilhaExcelProjeto.Models;

namespace ImportarPlanilhaExcelProjeto.Services;

public interface IPlanilhaService
{
	MemoryStream LerSttream(IFormFile formImport);
	List<ProdutoViewModel>? LerPlanilha(MemoryStream stream, string fileExtension);
	void SalvarProdutos(List<ProdutoViewModel> produtos);
}
