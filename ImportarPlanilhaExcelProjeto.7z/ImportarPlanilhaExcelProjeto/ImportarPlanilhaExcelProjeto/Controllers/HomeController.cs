using ImportarPlanilhaExcelProjeto.Data;
using ImportarPlanilhaExcelProjeto.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ImportarPlanilhaExcelProjeto.Controllers;

public class HomeController : Controller
{
	private readonly AppDbContext _context;
	private readonly IPlanilhaService _planilhaService;

	public HomeController(AppDbContext context, IPlanilhaService planilhaService)
	{
		_context = context;
		_planilhaService = planilhaService;
	}

	public async Task<IActionResult> Index()
	{
		var produtos = await _context.Produtos.ToListAsync();
		return View(produtos);
	}

	[HttpPost]
	public IActionResult ImportExcel(IFormFile formImport)
	{
		if (ModelState.IsValid)
		{
			var fileExtension = Path.GetExtension(formImport.FileName);

			var streamFile = _planilhaService.LerSttream(formImport);
			var produtos = _planilhaService.LerPlanilha(streamFile, fileExtension);
			_planilhaService.SalvarProdutos(produtos!);

			return RedirectToAction(nameof(Index));
		}
		else
		{
			return RedirectToAction(nameof(Index));
		}
	}

}
