﻿namespace ImportarPlanilhaExcelProjeto.Helpers;

public static class Constantes
{
	public const string XlsxContentType = ".xlsx";
	public const string XlsContentType = ".xls";
	public const string OdsContentType = ".ods";
	public const string CsvContentType = ".csv";
	public const string XlsmContentType = ".xlsm";
}
